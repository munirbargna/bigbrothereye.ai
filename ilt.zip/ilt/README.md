# ILT Market Intelligence

Real-time market intelligence platform: prezzi live, whale signals, vessel tracking, macro data.

## Stack

| Layer | Tech |
|---|---|
| Backend API | Python 3.12 · FastAPI · SQLAlchemy 2.0 async |
| Task queue | Celery 5.4 + Beat · Redis Streams |
| Time-series DB | TimescaleDB (PostgreSQL 16) |
| App DB | PostgreSQL 16 |
| Cache / Bus | Redis 7 |
| Whale Engine | Isolation Forest · Z-score · VWAP deviation |
| Frontend | Next.js 14 · React 18 · TailwindCSS · TradingView Charts |
| Logging | structlog → Loki → Grafana |
| Tracing | OpenTelemetry → Grafana Tempo |
| Metrics | Prometheus → Grafana |
| Container | Docker Compose (dev) |

---

## Quickstart (Linux / macOS)

```bash
# 1. Clona / estrai il progetto
cd ilt

# 2. Crea .env e imposta la SECRET_KEY
cp .env.example .env
python3 -c "import secrets; print(secrets.token_hex(32))"
# copia l'output nel campo SECRET_KEY del .env

# 3. Avvia tutto
make dev

# 4. Migrazioni DB
make migrate-all

# 5. Seed dati di test (opzionale)
make seed
```

## Quickstart (Windows)

Vedi `START_WINDOWS.md` per i comandi PowerShell equivalenti.

---

## URL in dev

| Servizio | URL | Credenziali |
|---|---|---|
| Frontend | http://localhost:3000 | — |
| API Docs | http://localhost:8000/api/v1/docs | — |
| Grafana | http://localhost:3001 | admin / admin |
| Prometheus | http://localhost:9090 | — |
| Mailhog | http://localhost:8025 | — |
| pgAdmin | http://localhost:5050 | admin@ilt.dev / admin |

> pgAdmin richiede: `make tools`

---

## Utenti seed

| Email | Password | Ruolo |
|---|---|---|
| admin@ilt.dev | Admin1234 | Superuser |
| demo@ilt.dev | Demo1234 | Utente normale |

---

## Struttura

```
ilt/
├── backend/               Python FastAPI
│   ├── app/
│   │   ├── api/v1/        Endpoint REST + WebSocket
│   │   ├── core/          Config, logging, security, redis
│   │   ├── db/            SQLAlchemy engines, migrations seed
│   │   ├── models/        ORM: user, market (TimescaleDB)
│   │   ├── schemas/       Pydantic v2 request/response
│   │   ├── services/      price_service, ws_manager
│   │   └── workers/       Celery: price, vessel, macro, alert
│   ├── alembic/           Migrations (app + timescale)
│   └── tests/             pytest async
├── services/
│   └── whale_engine/      Microservizio Python autonomo
│       ├── detector.py    Z-score + VWAP + Isolation Forest
│       └── main.py        Redis Stream consumer
├── frontend/              Next.js 14
│   ├── app/               App Router (layout, pages)
│   ├── components/        PriceBoard, PriceChart, WhaleAlertFeed…
│   ├── hooks/             useLivePrices (WS), useAuth (Zustand)
│   └── lib/               api.ts (axios + tipi)
└── infra/
    ├── prometheus/        prometheus.yml + alert.rules.yml
    ├── grafana/           datasources + dashboard market.json
    ├── loki/              loki-config.yml
    ├── promtail/          promtail-config.yml
    ├── tempo/             tempo.yaml
    ├── nginx/             nginx.conf (reverse proxy prod)
    └── sql/               timescale_init.sql
```

---

## Flusso dati

```
Polygon.io / EIA / FRED / MarineTraffic
        ↓  (Celery Beat ogni 10s/5m/1h)
   price_worker / vessel_worker / macro_worker
        ↓  INSERT batch
   TimescaleDB (price_ticks, vessel_positions, macro_data_points)
        ↓  cache_set
   Redis "live:prices"
        ↓  PUBLISH "prices:broadcast"
   ws_manager → WebSocket → Frontend
        ↓  XADD "stream:prices"
   whale_engine (XREADGROUP)
        ↓  Z-score + VWAP + IsolationForest
   TimescaleDB "whale_signals"
        ↓  PUBLISH "whale:broadcast"
   ws_manager → WebSocket → Frontend
```

---

## API principale

```
POST /api/v1/auth/register
POST /api/v1/auth/login
POST /api/v1/auth/refresh
POST /api/v1/auth/logout
GET  /api/v1/auth/me

GET  /api/v1/prices/live
GET  /api/v1/prices/{asset}
GET  /api/v1/prices/{asset}/ohlcv?timeframe=1h&limit=200
GET  /api/v1/prices/{asset}/ticks
GET  /api/v1/prices/vessels/latest
GET  /api/v1/prices/whale-signals/recent
WS   /api/v1/prices/ws/live

GET  /api/v1/watchlists
POST /api/v1/watchlists
PUT  /api/v1/watchlists/{id}
GET  /api/v1/alerts
POST /api/v1/alerts

GET  /api/v1/admin/stats          (superuser)
GET  /api/v1/admin/workers/status (superuser)
```

---

## Sviluppo

```bash
make test        # pytest con coverage
make lint        # ruff + mypy
make format      # ruff format
make shell       # bash nel container backend
make whale-logs  # log whale engine in real-time
```

---

## Configurazione API keys (opzionale)

Il sistema funziona **senza API keys** in mock mode. Per dati reali:

| Servizio | Variabile | Link |
|---|---|---|
| Polygon.io | `POLYGON_API_KEY` | https://polygon.io/dashboard |
| MarineTraffic | `MARINE_TRAFFIC_KEY` | https://www.marinetraffic.com |
| EIA | `EIA_API_KEY` | https://www.eia.gov/opendata |
| FRED | `FRED_API_KEY` | https://fred.stlouisfed.org/docs/api |

---

⚠️ **Solo uso informativo — non è consulenza finanziaria.**
