# ILT Market Intelligence — Avvio su Windows

## Prerequisiti
- [Docker Desktop per Windows](https://www.docker.com/products/docker-desktop/) (con WSL2 backend)
- Git Bash oppure PowerShell

---

## 1. Estrai lo zip e apri il terminale

```powershell
# PowerShell o Git Bash
cd ilt
```

---

## 2. Crea il file .env

```powershell
copy .env.example .env
```

Apri `.env` con Notepad e imposta `SECRET_KEY`.
Generane uno sicuro con:
```powershell
python -c "import secrets; print(secrets.token_hex(32))"
```
(oppure usa qualsiasi stringa di 32+ caratteri per il dev locale)

---

## 3. Avvia tutti i container

```powershell
docker compose up --build -d
```

Prima volta: scarica le immagini (~5 min). Le volte successive: ~30 secondi.

---

## 4. Esegui le migrazioni DB

```powershell
# PostgreSQL (app DB)
docker compose exec backend alembic -x db=app upgrade head

# TimescaleDB (time-series)
docker compose exec backend alembic -x db=timescale upgrade head
```

---

## 5. Verifica che tutto funzioni

Apri nel browser:
- **API Docs:**     http://localhost:8000/api/v1/docs
- **Grafana:**      http://localhost:3001   (admin / admin)
- **Prometheus:**   http://localhost:9090

---

## Comandi utili (equivalenti al Makefile)

| Makefile         | Windows PowerShell / Git Bash                                              |
|------------------|---------------------------------------------------------------------------|
| `make dev`       | `docker compose up --build -d`                                            |
| `make down`      | `docker compose down`                                                     |
| `make clean`     | `docker compose down -v --remove-orphans`                                 |
| `make logs`      | `docker compose logs -f`                                                  |
| `make migrate`   | `docker compose exec backend alembic -x db=app upgrade head`             |
| `make migrate-ts`| `docker compose exec backend alembic -x db=timescale upgrade head`       |
| `make test`      | `docker compose exec backend pytest -v --tb=short`                       |
| `make lint`      | `docker compose exec backend ruff check app`                              |
| `make shell`     | `docker compose exec backend bash`                                        |
| `make psql`      | `docker compose exec postgres psql -U ilt -d ilt_app`                    |
| `make redis-cli` | `docker compose exec redis redis-cli`                                     |

---

## Troubleshooting Windows

**"docker: command not found"**
→ Installa Docker Desktop e assicurati che sia avviato (icona nella tray)

**Porte già in uso (5432, 6379, 8000...)**
→ Modifica le porte nel `docker-compose.yml`, es: `"15432:5432"`

**Permessi sui volumi**
→ In Docker Desktop → Settings → Resources → File Sharing:
  aggiungi la cartella del progetto

**Hot reload non funziona**
→ In Docker Desktop → Settings → General:
  abilita "Use the WSL 2 based engine"

**Errore `\r\n` negli script bash dentro container**
→ In Git: `git config --global core.autocrlf false`
  poi ri-estrai lo zip
