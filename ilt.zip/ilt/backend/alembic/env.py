"""
alembic/env.py

Configurazione Alembic per migrazioni async su due database:
- PostgreSQL (app DB) → python manage_db.py migrate --db app
- TimescaleDB         → python manage_db.py migrate --db timescale

Usa asyncpg per connettersi, rileva automaticamente i modelli.
"""

import asyncio
import os
import sys
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

# Aggiungi il path del backend
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.core.config import settings
from app.db.base import Base

# Importa tutti i modelli in modo che Alembic li veda per autogenerate
from app.models import market, user  # noqa: F401

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata

# Determina quale DB stia migrando (passato come x-arg)
# Uso: alembic -x db=timescale upgrade head
CURRENT_DB = context.get_x_argument(as_dictionary=True).get("db", "app")

DB_URLS = {
    "app": settings.database_url_str,
    "timescale": settings.timescale_url_str,
}


def get_url() -> str:
    url = DB_URLS.get(CURRENT_DB)
    if not url:
        raise ValueError(f"Database '{CURRENT_DB}' non riconosciuto. Usa 'app' o 'timescale'.")
    return url


def run_migrations_offline() -> None:
    """Genera SQL senza connessione diretta."""
    url = get_url()
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
        compare_server_default=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=True,
        compare_server_default=True,
        # Include solo le tabelle del DB corretto
        include_schemas=True,
    )
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    url = get_url()
    configuration = config.get_section(config.config_ini_section, {})
    configuration["sqlalchemy.url"] = url

    connectable = async_engine_from_config(
        configuration,
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
