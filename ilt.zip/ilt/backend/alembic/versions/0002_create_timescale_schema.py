"""create_timescale_schema

Revision ID: 0002
Revises:
Create Date: 2026-03-14 00:00:01.000000

Schema TimescaleDB:
- price_ticks         → hypertable (chunk 1 giorno)
- ohlcv_bars          → hypertable (chunk 1 giorno)
- vessel_positions    → hypertable (chunk 1 giorno)
- whale_signals       → hypertable (chunk 1 giorno)
- macro_data_points   → hypertable (chunk 1 settimana)
- Continuous aggregates per OHLCV (1m, 5m, 1h)
- Retention policies
- Compression policies
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0002"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = ("timescale",)
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ── EXTENSIONS ────────────────────────────────────────────────────────
    op.execute("CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE")
    op.execute("CREATE EXTENSION IF NOT EXISTS postgis")  # vessel positioning

    # ── PRICE TICKS ───────────────────────────────────────────────────────
    op.create_table(
        "price_ticks",
        sa.Column("time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("asset", sa.String(20), nullable=False),
        sa.Column("price", sa.Numeric(precision=18, scale=6), nullable=False),
        sa.Column("bid", sa.Numeric(precision=18, scale=6), nullable=True),
        sa.Column("ask", sa.Numeric(precision=18, scale=6), nullable=True),
        sa.Column("volume", sa.Float(), nullable=True),
        sa.Column("source", sa.String(30), nullable=False),
        sa.PrimaryKeyConstraint("time", "asset"),
    )
    # Converti in hypertable — partiziona per giorno
    op.execute("""
        SELECT create_hypertable(
            'price_ticks', 'time',
            chunk_time_interval => INTERVAL '1 day',
            if_not_exists => TRUE
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS ix_price_ticks_asset_time
        ON price_ticks USING brin (asset, time)
    """)

    # Compression: comprimi chunk più vecchi di 7 giorni
    op.execute("""
        ALTER TABLE price_ticks SET (
            timescaledb.compress,
            timescaledb.compress_segmentby = 'asset',
            timescaledb.compress_orderby = 'time DESC'
        )
    """)
    op.execute("""
        SELECT add_compression_policy('price_ticks', INTERVAL '7 days')
    """)

    # Retention: elimina dati più vecchi di 2 anni
    op.execute("""
        SELECT add_retention_policy('price_ticks', INTERVAL '2 years')
    """)

    # ── OHLCV BARS ────────────────────────────────────────────────────────
    op.create_table(
        "ohlcv_bars",
        sa.Column("time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("asset", sa.String(20), nullable=False),
        sa.Column("timeframe", sa.String(5), nullable=False),
        sa.Column("open", sa.Numeric(precision=18, scale=6), nullable=False),
        sa.Column("high", sa.Numeric(precision=18, scale=6), nullable=False),
        sa.Column("low", sa.Numeric(precision=18, scale=6), nullable=False),
        sa.Column("close", sa.Numeric(precision=18, scale=6), nullable=False),
        sa.Column("volume", sa.Float(), nullable=True),
        sa.Column("vwap", sa.Numeric(precision=18, scale=6), nullable=True),
        sa.Column("trade_count", sa.Integer(), nullable=True),
        sa.PrimaryKeyConstraint("time", "asset", "timeframe"),
    )
    op.execute("""
        SELECT create_hypertable(
            'ohlcv_bars', 'time',
            chunk_time_interval => INTERVAL '1 day',
            if_not_exists => TRUE
        )
    """)

    # Continuous Aggregate: candele 1 minuto da price_ticks
    op.execute("""
        CREATE MATERIALIZED VIEW ohlcv_1m
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 minute', time) AS bucket,
            asset,
            first(price, time)  AS open,
            max(price)          AS high,
            min(price)          AS low,
            last(price, time)   AS close,
            sum(volume)         AS volume,
            count(*)            AS trade_count
        FROM price_ticks
        GROUP BY bucket, asset
        WITH NO DATA
    """)
    op.execute("""
        SELECT add_continuous_aggregate_policy('ohlcv_1m',
            start_offset => INTERVAL '1 hour',
            end_offset   => INTERVAL '1 minute',
            schedule_interval => INTERVAL '1 minute'
        )
    """)

    # Continuous Aggregate: candele 1 ora
    op.execute("""
        CREATE MATERIALIZED VIEW ohlcv_1h
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 hour', time) AS bucket,
            asset,
            first(price, time)  AS open,
            max(price)          AS high,
            min(price)          AS low,
            last(price, time)   AS close,
            sum(volume)         AS volume
        FROM price_ticks
        GROUP BY bucket, asset
        WITH NO DATA
    """)
    op.execute("""
        SELECT add_continuous_aggregate_policy('ohlcv_1h',
            start_offset => INTERVAL '1 day',
            end_offset   => INTERVAL '1 hour',
            schedule_interval => INTERVAL '30 minutes'
        )
    """)

    # ── VESSEL POSITIONS ──────────────────────────────────────────────────
    op.create_table(
        "vessel_positions",
        sa.Column("time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("mmsi", sa.String(9), nullable=False),
        sa.Column("vessel_name", sa.String(100), nullable=True),
        sa.Column("vessel_type", sa.String(20), nullable=True),
        sa.Column("flag", sa.String(3), nullable=True),
        sa.Column("imo", sa.String(10), nullable=True),
        sa.Column("latitude", sa.Float(), nullable=False),
        sa.Column("longitude", sa.Float(), nullable=False),
        sa.Column("speed", sa.Float(), nullable=True),
        sa.Column("heading", sa.Float(), nullable=True),
        sa.Column("nav_status", sa.String(50), nullable=True),
        sa.Column("destination", sa.String(100), nullable=True),
        sa.Column("eta", sa.DateTime(timezone=True), nullable=True),
        sa.Column("draught", sa.Float(), nullable=True),
        sa.Column("cargo_type", sa.String(50), nullable=True),
        sa.Column("commodity", sa.String(20), nullable=True),
        sa.Column("deadweight_tonnage", sa.Integer(), nullable=True),
        sa.Column("near_chokepoint", sa.String(50), nullable=True),
        sa.Column("is_at_risk", sa.Boolean(), server_default="false", nullable=False),
        sa.PrimaryKeyConstraint("time", "mmsi"),
    )
    op.execute("""
        SELECT create_hypertable(
            'vessel_positions', 'time',
            chunk_time_interval => INTERVAL '1 day',
            if_not_exists => TRUE
        )
    """)
    op.execute("""
        CREATE INDEX ix_vessel_commodity_time ON vessel_positions (commodity, time DESC)
    """)
    op.execute("""
        CREATE INDEX ix_vessel_chokepoint ON vessel_positions (near_chokepoint, time DESC)
        WHERE near_chokepoint IS NOT NULL
    """)

    # ── WHALE SIGNALS ─────────────────────────────────────────────────────
    op.create_table(
        "whale_signals",
        sa.Column("time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("signal_id", sa.String(36), nullable=False),
        sa.Column("asset", sa.String(20), nullable=False),
        sa.Column("direction", sa.String(10), nullable=False),
        sa.Column("strength", sa.Float(), nullable=False),
        sa.Column("signal_type", sa.String(30), nullable=False),
        sa.Column("z_score", sa.Float(), nullable=True),
        sa.Column("notional_usd", sa.Float(), nullable=True),
        sa.Column("vwap_deviation_pct", sa.Float(), nullable=True),
        sa.Column("metadata", postgresql.JSONB(), nullable=False, server_default="{}"),
        sa.Column("whale_profile_id", sa.String(20), nullable=True),
        sa.PrimaryKeyConstraint("time", "signal_id"),
    )
    op.execute("""
        SELECT create_hypertable(
            'whale_signals', 'time',
            chunk_time_interval => INTERVAL '1 day',
            if_not_exists => TRUE
        )
    """)
    op.execute("""
        SELECT add_retention_policy('whale_signals', INTERVAL '1 year')
    """)

    # ── MACRO DATA POINTS ─────────────────────────────────────────────────
    op.create_table(
        "macro_data_points",
        sa.Column("time", sa.DateTime(timezone=True), nullable=False),
        sa.Column("series_id", sa.String(50), nullable=False),
        sa.Column("value", sa.Float(), nullable=False),
        sa.Column("unit", sa.String(30), nullable=True),
        sa.Column("source", sa.String(20), nullable=False),
        sa.Column("frequency", sa.String(10), nullable=True),
        sa.Column("revision_number", sa.SmallInteger(), nullable=False, server_default="0"),
        sa.PrimaryKeyConstraint("time", "series_id"),
    )
    op.execute("""
        SELECT create_hypertable(
            'macro_data_points', 'time',
            chunk_time_interval => INTERVAL '7 days',
            if_not_exists => TRUE
        )
    """)
    op.execute("""
        SELECT add_retention_policy('macro_data_points', INTERVAL '10 years')
    """)


def downgrade() -> None:
    # Rimuove nell'ordine inverso
    for view in ["ohlcv_1h", "ohlcv_1m"]:
        op.execute(f"DROP MATERIALIZED VIEW IF EXISTS {view} CASCADE")

    for table in [
        "macro_data_points",
        "whale_signals",
        "vessel_positions",
        "ohlcv_bars",
        "price_ticks",
    ]:
        op.execute(f"DROP TABLE IF EXISTS {table} CASCADE")
