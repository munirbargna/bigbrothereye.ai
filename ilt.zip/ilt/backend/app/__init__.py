"""
app/api/v1/__init__.py
Router principale v1 — aggrega tutti i sub-router.
"""
from fastapi import APIRouter

from app.api.v1.endpoints.auth       import router as auth_router
from app.api.v1.endpoints.prices     import router as prices_router
from app.api.v1.endpoints.watchlists import router as watchlists_router
from app.api.v1.endpoints.admin      import router as admin_router

router = APIRouter()
router.include_router(auth_router)
router.include_router(prices_router)
router.include_router(watchlists_router)
router.include_router(admin_router)
