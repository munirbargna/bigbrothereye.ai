"""
app/api/v1/deps.py

FastAPI dependencies riusabili.
Iniettate via Depends() negli endpoint.

Uso:
    @router.get("/me")
    async def me(user: CurrentUser):
        return user

    @router.delete("/admin/thing")
    async def delete(user: CurrentSuperuser):
        ...
"""

from typing import Annotated

import structlog
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import decode_access_token, is_token_blacklisted
from app.db.session import AppSession, TimescaleSession
from app.models.user import User

log = structlog.get_logger(__name__)

# Re-export delle DB sessions come alias comodi
__all__ = [
    "AppSession",
    "TimescaleSession",
    "CurrentUser",
    "CurrentActiveUser",
    "CurrentSuperuser",
    "OptionalUser",
]

# ── Bearer token extractor ────────────────────────────────────────────────────

_bearer = HTTPBearer(auto_error=False)


async def _get_token(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)],
) -> str | None:
    if credentials is None:
        return None
    return credentials.credentials


# ── Core auth dependency ──────────────────────────────────────────────────────

async def _get_current_user(
    db: AppSession,
    token: Annotated[str | None, Depends(_get_token)],
) -> User | None:
    """
    Valida il JWT e restituisce l'utente.
    Controlla: firma, scadenza, blacklist, utente esistente.
    """
    if token is None:
        return None

    try:
        payload = decode_access_token(token)
    except JWTError as e:
        log.warning("auth.invalid_token", error=str(e))
        return None

    # Verifica tipo token
    if payload.get("type") != "access":
        return None

    # Controlla blacklist
    jti = payload.get("jti", "")
    if jti and await is_token_blacklisted(jti):
        log.warning("auth.blacklisted_token", jti=jti)
        return None

    user_id = payload.get("sub")
    if not user_id:
        return None

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if user:
        import structlog
        structlog.contextvars.bind_contextvars(user_id=str(user.id))

    return user


# ── Public dependencies ───────────────────────────────────────────────────────

async def get_current_user(
    user: Annotated[User | None, Depends(_get_current_user)],
) -> User:
    """Richiede un utente autenticato. 401 se assente."""
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Autenticazione richiesta",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


async def get_current_active_user(
    user: Annotated[User, Depends(get_current_user)],
) -> User:
    """Richiede utente autenticato e attivo. 403 se disabilitato."""
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account disabilitato",
        )
    return user


async def get_current_superuser(
    user: Annotated[User, Depends(get_current_active_user)],
) -> User:
    """Richiede superuser. 403 altrimenti."""
    if not user.is_superuser:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Permessi insufficienti",
        )
    return user


async def get_optional_user(
    user: Annotated[User | None, Depends(_get_current_user)],
) -> User | None:
    """Utente opzionale — endpoint pubblici che mostrano dati extra se auth."""
    return user


# ── Type aliases (syntactic sugar per gli endpoint) ───────────────────────────

CurrentUser = Annotated[User, Depends(get_current_user)]
CurrentActiveUser = Annotated[User, Depends(get_current_active_user)]
CurrentSuperuser = Annotated[User, Depends(get_current_superuser)]
OptionalUser = Annotated[User | None, Depends(get_optional_user)]
