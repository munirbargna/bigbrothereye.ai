"""
app/api/v1/endpoints/admin.py

Endpoint riservati ai superuser:
    GET  /admin/users              Lista tutti gli utenti
    GET  /admin/users/{id}         Dettaglio utente
    PUT  /admin/users/{id}/toggle  Abilita/disabilita utente
    GET  /admin/stats              Statistiche sistema live
    POST /admin/seed               Esegue il seeder (solo dev)
    GET  /admin/workers/status     Stato worker Celery
"""

import uuid
from datetime import datetime, timezone

import structlog
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel
from sqlalchemy import func, select

from app.api.v1.deps import AppSession, CurrentSuperuser, TimescaleSession
from app.models.user import User
from app.models.market import PriceTick, WhaleSignal, VesselPosition

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/admin", tags=["admin"])


# ── Schemas ───────────────────────────────────────────────────────────────────

class UserAdminResponse(BaseModel):
    model_config = {"from_attributes": True}
    id: uuid.UUID
    email: str
    full_name: str | None
    is_active: bool
    is_superuser: bool
    created_at: datetime


class SystemStatsResponse(BaseModel):
    price_ticks_24h:    int
    whale_signals_24h:  int
    vessels_tracked:    int
    ws_connections:     int
    redis_ping_ok:      bool
    db_ping_ok:         bool
    ts_ping_ok:         bool
    uptime_seconds:     float


# ── Users ─────────────────────────────────────────────────────────────────────

@router.get("/users", response_model=list[UserAdminResponse])
async def list_users(
    _: CurrentSuperuser,
    db: AppSession,
    skip: int = 0,
    limit: int = 100,
) -> list[User]:
    result = await db.execute(
        select(User).order_by(User.created_at.desc()).offset(skip).limit(limit)
    )
    return list(result.scalars().all())


@router.get("/users/{user_id}", response_model=UserAdminResponse)
async def get_user(user_id: uuid.UUID, _: CurrentSuperuser, db: AppSession) -> User:
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Utente non trovato")
    return user


@router.put("/users/{user_id}/toggle", response_model=UserAdminResponse)
async def toggle_user(
    user_id: uuid.UUID, current: CurrentSuperuser, db: AppSession
) -> User:
    if user_id == current.id:
        raise HTTPException(status_code=400, detail="Non puoi disabilitare te stesso")
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Utente non trovato")
    user.is_active = not user.is_active
    await db.commit()
    await db.refresh(user)
    log.info("admin.user_toggled", target_id=str(user_id), is_active=user.is_active,
             by=str(current.id))
    return user


# ── System stats ──────────────────────────────────────────────────────────────

_start_time = datetime.now(timezone.utc)


@router.get("/stats", response_model=SystemStatsResponse)
async def system_stats(_: CurrentSuperuser, db: AppSession, ts: TimescaleSession) -> SystemStatsResponse:
    from datetime import timedelta
    from sqlalchemy import text

    since_24h = datetime.now(timezone.utc) - timedelta(hours=24)

    # Count price ticks
    ticks_res = await ts.execute(
        select(func.count()).select_from(PriceTick).where(PriceTick.time >= since_24h)
    )
    ticks_24h = ticks_res.scalar() or 0

    # Count whale signals
    signals_res = await ts.execute(
        select(func.count()).select_from(WhaleSignal).where(WhaleSignal.time >= since_24h)
    )
    signals_24h = signals_res.scalar() or 0

    # Count distinct vessels last 6h
    vessels_res = await ts.execute(
        select(func.count(func.distinct(VesselPosition.mmsi))).where(
            VesselPosition.time >= datetime.now(timezone.utc) - timedelta(hours=6)
        )
    )
    vessels = vessels_res.scalar() or 0

    # WebSocket connections
    from app.services.ws_manager import manager
    ws_count = manager.connection_count

    # Redis ping
    redis_ok = False
    try:
        from app.core.redis import get_redis
        await get_redis().ping()
        redis_ok = True
    except Exception:
        pass

    # DB pings
    db_ok = False
    ts_ok = False
    try:
        await db.execute(text("SELECT 1"))
        db_ok = True
    except Exception:
        pass
    try:
        await ts.execute(text("SELECT 1"))
        ts_ok = True
    except Exception:
        pass

    uptime = (datetime.now(timezone.utc) - _start_time).total_seconds()

    return SystemStatsResponse(
        price_ticks_24h=ticks_24h,
        whale_signals_24h=signals_24h,
        vessels_tracked=vessels,
        ws_connections=ws_count,
        redis_ping_ok=redis_ok,
        db_ping_ok=db_ok,
        ts_ping_ok=ts_ok,
        uptime_seconds=round(uptime, 1),
    )


# ── Workers status ────────────────────────────────────────────────────────────

@router.get("/workers/status", summary="Stato worker Celery (inspect active)")
async def workers_status(_: CurrentSuperuser) -> dict:
    try:
        from app.workers.celery_app import celery_app
        inspect = celery_app.control.inspect(timeout=3.0)
        active  = inspect.active()  or {}
        stats   = inspect.stats()   or {}
        return {
            "workers":      list(stats.keys()),
            "active_tasks": {w: len(tasks) for w, tasks in active.items()},
            "stats":        {
                w: {
                    "pool":      s.get("pool", {}).get("implementation"),
                    "processed": s.get("total", {}).get("tasks.accepted", 0),
                }
                for w, s in stats.items()
            },
        }
    except Exception as e:
        return {"error": str(e), "hint": "Celery worker non raggiungibile"}


# ── Seed (solo development) ───────────────────────────────────────────────────

@router.post("/seed", status_code=202, summary="Esegue seeder dati di test (solo dev)")
async def run_seed(_: CurrentSuperuser) -> dict:
    from app.core.config import settings
    if settings.is_production:
        raise HTTPException(status_code=403, detail="Seed non permesso in production")
    import asyncio
    from app.db.seed import seed_app_db, seed_timescale_db
    asyncio.create_task(seed_app_db())
    asyncio.create_task(seed_timescale_db())
    return {"status": "seeding_started", "hint": "Controlla i log per il completamento"}
