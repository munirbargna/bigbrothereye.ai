"""
app/api/v1/endpoints/auth.py

Endpoint di autenticazione:
    POST /auth/register       Registrazione nuovo utente
    POST /auth/login          Login → access token + refresh cookie
    POST /auth/refresh        Rinnova access token via refresh cookie
    POST /auth/logout         Revoca refresh token + blacklist access
    GET  /auth/me             Profilo utente corrente
    PUT  /auth/me             Aggiorna profilo
    PUT  /auth/me/password    Cambia password
"""

from datetime import datetime, timedelta, timezone

import structlog
from fastapi import APIRouter, Cookie, HTTPException, Request, Response, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError

from app.api.v1.deps import AppSession, CurrentActiveUser
from app.core.security import (
    blacklist_token,
    create_access_token,
    generate_refresh_token,
    hash_password,
    hash_refresh_token,
    verify_password,
)
from app.core.config import settings
from app.models.user import RefreshToken, User, Watchlist
from app.schemas.auth import (
    PasswordChangeRequest,
    TokenResponse,
    UserLoginRequest,
    UserRegisterRequest,
    UserResponse,
    UserUpdateRequest,
)

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/auth", tags=["auth"])

# ── Cookie config ─────────────────────────────────────────────────────────────
_REFRESH_COOKIE = "ilt_refresh"
_COOKIE_OPTS: dict = dict(
    key=_REFRESH_COOKIE,
    httponly=True,
    secure=settings.is_production,    # HTTPS solo in prod
    samesite="lax",
    path="/api/v1/auth",              # cookie inviato solo a questo path
    max_age=settings.REFRESH_TOKEN_EXPIRE_DAYS * 86400,
)


def _set_refresh_cookie(response: Response, raw_token: str) -> None:
    response.set_cookie(value=raw_token, **_COOKIE_OPTS)


def _clear_refresh_cookie(response: Response) -> None:
    response.delete_cookie(key=_REFRESH_COOKIE, path="/api/v1/auth")


# ── Register ──────────────────────────────────────────────────────────────────

@router.post(
    "/register",
    response_model=UserResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Registrazione nuovo utente",
)
async def register(body: UserRegisterRequest, db: AppSession) -> User:
    user = User(
        email=body.email.lower().strip(),
        hashed_password=hash_password(body.password),
        full_name=body.full_name,
    )
    db.add(user)

    try:
        await db.flush()  # ottieni l'id prima del commit
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Email già registrata",
        )

    # Crea watchlist default
    db.add(Watchlist(user_id=user.id, name="Default", is_default=True))
    await db.commit()
    await db.refresh(user)

    log.info("user.registered", user_id=str(user.id), email=user.email)
    return user


# ── Login ─────────────────────────────────────────────────────────────────────

@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Login — restituisce access token e imposta refresh cookie",
)
async def login(
    body: UserLoginRequest,
    request: Request,
    response: Response,
    db: AppSession,
) -> TokenResponse:
    # Lookup utente
    result = await db.execute(
        select(User).where(User.email == body.email.lower().strip())
    )
    user = result.scalar_one_or_none()

    # Timing-safe: verifica password anche se utente non esiste (evita user enumeration)
    if not user or not verify_password(body.password, user.hashed_password):
        log.warning("auth.login_failed", email=body.email)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credenziali non valide",
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account disabilitato",
        )

    # Genera tokens
    access_token = create_access_token(subject=user.id)
    raw_refresh, hashed_refresh = generate_refresh_token()

    # Salva refresh token nel DB
    rt = RefreshToken(
        user_id=user.id,
        token_hash=hashed_refresh,
        expires_at=datetime.now(timezone.utc)
        + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
        user_agent=request.headers.get("user-agent"),
        ip_address=request.client.host if request.client else None,
    )
    db.add(rt)
    await db.commit()

    # Imposta cookie HttpOnly
    _set_refresh_cookie(response, raw_refresh)

    log.info("user.logged_in", user_id=str(user.id))
    return TokenResponse(
        access_token=access_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


# ── Refresh ───────────────────────────────────────────────────────────────────

@router.post(
    "/refresh",
    response_model=TokenResponse,
    summary="Rinnova access token tramite refresh cookie",
)
async def refresh(
    response: Response,
    db: AppSession,
    refresh_cookie: str | None = Cookie(default=None, alias=_REFRESH_COOKIE),
) -> TokenResponse:
    if not refresh_cookie:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token mancante",
        )

    token_hash = hash_refresh_token(refresh_cookie)
    result = await db.execute(
        select(RefreshToken).where(RefreshToken.token_hash == token_hash)
    )
    rt = result.scalar_one_or_none()

    if not rt or not rt.is_valid:
        _clear_refresh_cookie(response)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Refresh token non valido o scaduto",
        )

    # Token rotation: revoca vecchio, crea nuovo
    rt.revoked_at = datetime.now(timezone.utc)

    raw_new, hashed_new = generate_refresh_token()
    new_rt = RefreshToken(
        user_id=rt.user_id,
        token_hash=hashed_new,
        expires_at=datetime.now(timezone.utc)
        + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )
    db.add(new_rt)
    await db.commit()

    access_token = create_access_token(subject=rt.user_id)
    _set_refresh_cookie(response, raw_new)

    log.info("token.refreshed", user_id=str(rt.user_id))
    return TokenResponse(
        access_token=access_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


# ── Logout ────────────────────────────────────────────────────────────────────

@router.post(
    "/logout",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Logout — revoca refresh token e blacklista access token",
)
async def logout(
    request: Request,
    response: Response,
    user: CurrentActiveUser,
    db: AppSession,
    refresh_cookie: str | None = Cookie(default=None, alias=_REFRESH_COOKIE),
) -> None:
    # Revoca refresh token se presente
    if refresh_cookie:
        token_hash = hash_refresh_token(refresh_cookie)
        result = await db.execute(
            select(RefreshToken).where(RefreshToken.token_hash == token_hash)
        )
        rt = result.scalar_one_or_none()
        if rt:
            rt.revoked_at = datetime.now(timezone.utc)
            await db.commit()

    # Blacklista access token corrente
    auth_header = request.headers.get("authorization", "")
    if auth_header.startswith("Bearer "):
        from app.core.security import decode_access_token
        from jose import JWTError
        try:
            payload = decode_access_token(auth_header[7:])
            jti = payload.get("jti")
            exp = payload.get("exp")
            if jti and exp:
                expires_at = datetime.fromtimestamp(exp, tz=timezone.utc)
                await blacklist_token(jti, expires_at)
        except JWTError:
            pass  # token già scaduto — non importa

    _clear_refresh_cookie(response)
    log.info("user.logged_out", user_id=str(user.id))


# ── Me ────────────────────────────────────────────────────────────────────────

@router.get("/me", response_model=UserResponse, summary="Profilo utente corrente")
async def me(user: CurrentActiveUser) -> User:
    return user


@router.put("/me", response_model=UserResponse, summary="Aggiorna profilo")
async def update_me(
    body: UserUpdateRequest,
    user: CurrentActiveUser,
    db: AppSession,
) -> User:
    if body.full_name is not None:
        user.full_name = body.full_name
    if body.preferences is not None:
        user.preferences = {**user.preferences, **body.preferences}
    await db.commit()
    await db.refresh(user)
    return user


@router.put(
    "/me/password",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Cambia password",
)
async def change_password(
    body: PasswordChangeRequest,
    user: CurrentActiveUser,
    db: AppSession,
) -> None:
    if not verify_password(body.current_password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Password corrente non corretta",
        )
    user.hashed_password = hash_password(body.new_password)
    await db.commit()
    log.info("user.password_changed", user_id=str(user.id))
