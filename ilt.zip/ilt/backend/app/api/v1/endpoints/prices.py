"""
app/api/v1/endpoints/prices.py

Endpoint dati di mercato:
    GET  /prices/live               Prezzi live tutti gli asset (da Redis)
    GET  /prices/{asset}            Snapshot completo di un asset
    GET  /prices/{asset}/ohlcv      Candele OHLCV con timeframe e range
    GET  /prices/{asset}/ticks      Tick raw ultimi N minuti
    GET  /prices/vessels            Posizioni navi cargo
    GET  /prices/whale-signals      Segnali whale recenti
    WS   /prices/ws/live            WebSocket feed live (10s push)
"""

import json
from datetime import datetime, timedelta, timezone

import structlog
from fastapi import APIRouter, HTTPException, Query, WebSocket, WebSocketDisconnect, status
from sqlalchemy import select

from app.api.v1.deps import AppSession, OptionalUser, TimescaleSession
from app.models.market import VesselPosition, WhaleSignal
from app.schemas.market import (
    AssetSnapshotResponse,
    OHLCVBarResponse,
    PriceTickResponse,
    VesselPositionResponse,
    WhaleSignalResponse,
)
from app.services.price_service import (
    TRACKED_ASSETS,
    get_asset_snapshot,
    get_live_prices,
    get_ohlcv,
    get_recent_ticks,
)
from app.services.ws_manager import manager

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/prices", tags=["prices"])


# ── Live prices ───────────────────────────────────────────────────────────────

@router.get(
    "/live",
    summary="Prezzi live di tutti gli asset tracciati (Redis cache, max 30s stale)",
)
async def live_prices() -> dict[str, float]:
    return await get_live_prices()


# ── Asset snapshot ────────────────────────────────────────────────────────────

@router.get(
    "/{asset}",
    response_model=AssetSnapshotResponse,
    summary="Snapshot completo: prezzo + OHLCV + whale signals",
)
async def asset_snapshot(
    asset: str,
    db: AppSession,
    ts: TimescaleSession,
) -> AssetSnapshotResponse:
    if asset.upper() not in TRACKED_ASSETS:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Asset '{asset}' non tracciato. Asset disponibili: {TRACKED_ASSETS}",
        )
    return await get_asset_snapshot(db, ts, asset)


# ── OHLCV ─────────────────────────────────────────────────────────────────────

@router.get(
    "/{asset}/ohlcv",
    response_model=list[OHLCVBarResponse],
    summary="Candele OHLCV — timeframe 1m | 1h | 1d",
)
async def ohlcv(
    asset: str,
    ts: TimescaleSession,
    timeframe: str = Query(default="1h", pattern="^(1m|1h|1d)$"),
    limit: int = Query(default=200, ge=1, le=1000),
    since: datetime | None = Query(default=None),
) -> list[OHLCVBarResponse]:
    return await get_ohlcv(ts, asset, timeframe=timeframe, limit=limit, since=since)


# ── Ticks ─────────────────────────────────────────────────────────────────────

@router.get(
    "/{asset}/ticks",
    response_model=list[PriceTickResponse],
    summary="Tick raw, ultimi N (default 100, max 1000)",
)
async def ticks(
    asset: str,
    ts: TimescaleSession,
    limit: int = Query(default=100, ge=1, le=1000),
    since: datetime | None = Query(default=None),
) -> list[PriceTickResponse]:
    return await get_recent_ticks(ts, asset, limit=limit, since=since)


# ── Vessels ───────────────────────────────────────────────────────────────────

@router.get(
    "/vessels/latest",
    response_model=list[VesselPositionResponse],
    summary="Posizione più recente di ogni nave cargo tracciata",
)
async def vessels_latest(
    ts: TimescaleSession,
    commodity: str | None = Query(default=None, description="Filtra per: oil | gold | silver"),
) -> list[VesselPositionResponse]:
    # Usa DISTINCT ON per ottenere l'ultima posizione di ogni nave
    sql = """
        SELECT DISTINCT ON (mmsi)
            time, mmsi, vessel_name, vessel_type, latitude, longitude,
            speed, commodity, destination, near_chokepoint, is_at_risk
        FROM vessel_positions
        WHERE time >= NOW() - INTERVAL '6 hours'
        {where_commodity}
        ORDER BY mmsi, time DESC
        LIMIT 200
    """
    where = "AND commodity = :commodity" if commodity else ""
    from sqlalchemy import text
    result = await ts.execute(
        text(sql.format(where_commodity=where)),
        {"commodity": commodity} if commodity else {},
    )
    rows = result.mappings().all()
    return [VesselPositionResponse(**dict(r)) for r in rows]


# ── Whale signals ─────────────────────────────────────────────────────────────

@router.get(
    "/whale-signals/recent",
    response_model=list[WhaleSignalResponse],
    summary="Segnali whale ultimi N giorni",
)
async def whale_signals(
    ts: TimescaleSession,
    days: int = Query(default=2, ge=1, le=30),
    asset: str | None = Query(default=None),
    min_strength: float = Query(default=0.5, ge=0.0, le=1.0),
) -> list[WhaleSignalResponse]:
    q = (
        select(WhaleSignal)
        .where(
            WhaleSignal.time >= datetime.now(timezone.utc) - timedelta(days=days),
            WhaleSignal.strength >= min_strength,
        )
        .order_by(WhaleSignal.time.desc())
        .limit(100)
    )
    if asset:
        q = q.where(WhaleSignal.asset == asset.upper())

    result = await ts.execute(q)
    return [
        WhaleSignalResponse.model_validate(s, from_attributes=True)
        for s in result.scalars().all()
    ]


# ── WebSocket live feed ───────────────────────────────────────────────────────

@router.websocket("/ws/live")
async def websocket_live(
    ws: WebSocket,
    token: str | None = Query(default=None),
) -> None:
    """
    WebSocket per il feed live.

    Autenticazione opzionale:
        ws://api/v1/prices/ws/live?token=<access_token>

    Messaggi ricevuti (push automatico ogni 10s):
        {"type": "price_update", "ts": "...", "prices": {...}, "changes": {...}}
        {"type": "whale_alert", "signal": {...}}

    Il client può inviare {"type": "ping"} per keepalive.

    Connessione chiusa automaticamente dopo 24h di idle.
    """
    user_id: str | None = None

    # Auth opzionale via query param
    if token:
        try:
            from app.core.security import decode_access_token, is_token_blacklisted
            from jose import JWTError
            payload = decode_access_token(token)
            jti = payload.get("jti", "")
            if not await is_token_blacklisted(jti):
                user_id = payload.get("sub")
        except Exception:
            pass  # connessione anonima

    await manager.connect(ws, user_id=user_id)
    log.info("ws.client_connected", user_id=user_id, total=manager.connection_count)

    try:
        # Invia snapshot iniziale prezzi
        prices = await get_live_prices()
        await ws.send_text(json.dumps({
            "type": "snapshot",
            "ts": datetime.now(timezone.utc).isoformat(),
            "prices": prices,
        }))

        # Loop keepalive — il broadcast reale arriva da Redis pub/sub
        while True:
            try:
                data = await ws.receive_text()
                msg = json.loads(data)
                if msg.get("type") == "ping":
                    await ws.send_text(json.dumps({"type": "pong"}))
            except (json.JSONDecodeError, KeyError):
                pass

    except WebSocketDisconnect:
        log.info("ws.client_disconnected", user_id=user_id)
    except Exception as e:
        log.warning("ws.error", user_id=user_id, error=str(e))
    finally:
        await manager.disconnect(ws, user_id=user_id)
