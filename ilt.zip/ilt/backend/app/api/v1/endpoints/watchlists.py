"""
app/api/v1/endpoints/watchlists.py

CRUD watchlists e price alerts per l'utente autenticato.
    GET    /watchlists              Lista watchlist utente
    POST   /watchlists              Crea watchlist
    PUT    /watchlists/{id}         Aggiorna watchlist
    DELETE /watchlists/{id}         Elimina watchlist
    GET    /alerts                  Lista alert attivi
    POST   /alerts                  Crea alert
    DELETE /alerts/{id}             Elimina alert
    GET    /macro/latest            Ultimi dati macro da Redis
"""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy import select

from app.api.v1.deps import AppSession, CurrentActiveUser
from app.models.user import PriceAlert, Watchlist

router = APIRouter(tags=["watchlists & alerts"])


# ── Schemas inline ────────────────────────────────────────────────────────────

class WatchlistCreate(BaseModel):
    name: str = Field(max_length=100)
    assets: list[str] = Field(default_factory=list, max_length=50)

class WatchlistUpdate(BaseModel):
    name: str | None = Field(default=None, max_length=100)
    assets: list[str] | None = None

class WatchlistResponse(BaseModel):
    model_config = {"from_attributes": True}
    id: uuid.UUID
    name: str
    assets: list
    is_default: bool
    created_at: datetime

class AlertCreate(BaseModel):
    asset: str = Field(max_length=20)
    condition: str = Field(pattern="^(above|below|pct_change)$")
    threshold: float
    notification_channels: dict = Field(
        default_factory=lambda: {"websocket": True, "email": False}
    )

class AlertResponse(BaseModel):
    model_config = {"from_attributes": True}
    id: uuid.UUID
    asset: str
    condition: str
    threshold: float
    is_active: bool
    triggered_at: datetime | None
    created_at: datetime


# ── Watchlists ────────────────────────────────────────────────────────────────

@router.get("/watchlists", response_model=list[WatchlistResponse])
async def list_watchlists(user: CurrentActiveUser, db: AppSession) -> list[Watchlist]:
    result = await db.execute(
        select(Watchlist).where(Watchlist.user_id == user.id).order_by(Watchlist.created_at)
    )
    return list(result.scalars().all())


@router.post("/watchlists", response_model=WatchlistResponse, status_code=201)
async def create_watchlist(
    body: WatchlistCreate, user: CurrentActiveUser, db: AppSession
) -> Watchlist:
    # Max 10 watchlist per utente
    count_res = await db.execute(
        select(Watchlist).where(Watchlist.user_id == user.id)
    )
    if len(list(count_res.scalars().all())) >= 10:
        raise HTTPException(status_code=400, detail="Limite 10 watchlist per utente")
    wl = Watchlist(
        user_id=user.id,
        name=body.name,
        assets=[a.upper() for a in body.assets],
    )
    db.add(wl)
    await db.commit()
    await db.refresh(wl)
    return wl


@router.put("/watchlists/{wl_id}", response_model=WatchlistResponse)
async def update_watchlist(
    wl_id: uuid.UUID, body: WatchlistUpdate, user: CurrentActiveUser, db: AppSession
) -> Watchlist:
    res = await db.execute(
        select(Watchlist).where(Watchlist.id == wl_id, Watchlist.user_id == user.id)
    )
    wl = res.scalar_one_or_none()
    if not wl:
        raise HTTPException(status_code=404, detail="Watchlist non trovata")
    if body.name is not None:
        wl.name = body.name
    if body.assets is not None:
        wl.assets = [a.upper() for a in body.assets]
    await db.commit()
    await db.refresh(wl)
    return wl


@router.delete("/watchlists/{wl_id}", status_code=204)
async def delete_watchlist(
    wl_id: uuid.UUID, user: CurrentActiveUser, db: AppSession
) -> None:
    res = await db.execute(
        select(Watchlist).where(Watchlist.id == wl_id, Watchlist.user_id == user.id)
    )
    wl = res.scalar_one_or_none()
    if not wl:
        raise HTTPException(status_code=404, detail="Watchlist non trovata")
    if wl.is_default:
        raise HTTPException(status_code=400, detail="Non puoi eliminare la watchlist default")
    await db.delete(wl)
    await db.commit()


# ── Price alerts ──────────────────────────────────────────────────────────────

@router.get("/alerts", response_model=list[AlertResponse])
async def list_alerts(user: CurrentActiveUser, db: AppSession) -> list[PriceAlert]:
    result = await db.execute(
        select(PriceAlert)
        .where(PriceAlert.user_id == user.id, PriceAlert.is_active == True)  # noqa: E712
        .order_by(PriceAlert.created_at.desc())
    )
    return list(result.scalars().all())


@router.post("/alerts", response_model=AlertResponse, status_code=201)
async def create_alert(
    body: AlertCreate, user: CurrentActiveUser, db: AppSession
) -> PriceAlert:
    alert = PriceAlert(
        user_id=user.id,
        asset=body.asset.upper(),
        condition=body.condition,
        threshold=body.threshold,
        notification_channels=body.notification_channels,
    )
    db.add(alert)
    await db.commit()
    await db.refresh(alert)
    return alert


@router.delete("/alerts/{alert_id}", status_code=204)
async def delete_alert(
    alert_id: uuid.UUID, user: CurrentActiveUser, db: AppSession
) -> None:
    res = await db.execute(
        select(PriceAlert).where(
            PriceAlert.id == alert_id, PriceAlert.user_id == user.id
        )
    )
    alert = res.scalar_one_or_none()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert non trovato")
    alert.is_active = False  # soft delete
    await db.commit()


# ── Macro data ────────────────────────────────────────────────────────────────

@router.get("/macro/latest", summary="Ultimi valori macro da Redis cache")
async def macro_latest() -> dict:
    from app.core.redis import cache_get
    data = await cache_get("macro:latest")
    if not data:
        return {"status": "no_data", "hint": "Il macro worker non ha ancora girato"}
    return data
