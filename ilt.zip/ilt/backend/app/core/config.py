"""
app/core/config.py

Configurazione centralizzata via Pydantic Settings.
Legge da variabili d'ambiente e/o file .env.

Uso:
    from app.core.config import settings
    print(settings.DATABASE_URL)
"""

from enum import StrEnum
from functools import lru_cache
from typing import Annotated

from pydantic import (
    AnyUrl,
    BeforeValidator,
    Field,
    PostgresDsn,
    RedisDsn,
    field_validator,
    model_validator,
)
from pydantic_settings import BaseSettings, SettingsConfigDict


class Environment(StrEnum):
    DEVELOPMENT = "development"
    STAGING = "staging"
    PRODUCTION = "production"


class LogLevel(StrEnum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


def _parse_cors_origins(v: str | list[str]) -> list[str]:
    """Accetta sia una stringa CSV che una lista."""
    if isinstance(v, str):
        return [origin.strip() for origin in v.split(",") if origin.strip()]
    return v


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",  # ignora variabili d'env non dichiarate
    )

    # ── App ───────────────────────────────────
    ENVIRONMENT: Environment = Environment.DEVELOPMENT
    SECRET_KEY: str = Field(min_length=32)
    LOG_LEVEL: LogLevel = LogLevel.INFO
    API_V1_PREFIX: str = "/api/v1"
    PROJECT_NAME: str = "ILT Market Intelligence"
    VERSION: str = "0.1.0"

    # CORS: in dev permetti tutto, in prod specifica i domini
    CORS_ORIGINS: Annotated[list[str], BeforeValidator(_parse_cors_origins)] = [
        "http://localhost:3000",
        "http://localhost:3001",
    ]

    # ── Databases ────────────────────────────
    DATABASE_URL: PostgresDsn
    TIMESCALE_URL: PostgresDsn

    # Pool settings
    DB_POOL_SIZE: int = Field(default=10, ge=2, le=50)
    DB_MAX_OVERFLOW: int = Field(default=20, ge=0, le=100)
    DB_POOL_TIMEOUT: int = Field(default=30, ge=5)
    DB_POOL_RECYCLE: int = Field(default=3600)  # ricrea connessioni ogni ora

    # ── Redis ─────────────────────────────────
    REDIS_URL: RedisDsn
    REDIS_CACHE_TTL: int = Field(default=15, description="TTL cache prezzi in secondi")
    REDIS_SESSION_TTL: int = Field(default=86400, description="TTL sessioni in secondi (24h)")

    # ── Auth ─────────────────────────────────
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(default=30)
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(default=7)

    # ── Rate limiting ─────────────────────────
    RATE_LIMIT_PER_MINUTE: int = Field(default=60)
    RATE_LIMIT_BURST: int = Field(default=20)

    # ── Feed API Keys ─────────────────────────
    POLYGON_API_KEY: str = ""
    MARINE_TRAFFIC_KEY: str = ""
    EIA_API_KEY: str = ""
    FRED_API_KEY: str = ""

    # ── Workers / Celery ─────────────────────
    CELERY_BROKER_URL: str = ""          # default = REDIS_URL
    CELERY_RESULT_BACKEND: str = ""      # default = REDIS_URL

    # Frequenze di polling (secondi)
    PRICES_POLL_INTERVAL: int = Field(default=10)
    VESSELS_POLL_INTERVAL: int = Field(default=300)   # 5 minuti
    MACRO_POLL_INTERVAL: int = Field(default=3600)    # 1 ora

    # ── Monitoring ────────────────────────────
    SENTRY_DSN: str = ""
    OTEL_EXPORTER_OTLP_ENDPOINT: str = ""
    OTEL_SERVICE_NAME: str = "ilt-backend"

    # ── Computed (post-init) ──────────────────
    @model_validator(mode="after")
    def _set_celery_urls(self) -> "Settings":
        """Se non specificati, Celery usa Redis di default."""
        redis_str = str(self.REDIS_URL)
        if not self.CELERY_BROKER_URL:
            self.CELERY_BROKER_URL = redis_str
        if not self.CELERY_RESULT_BACKEND:
            self.CELERY_RESULT_BACKEND = redis_str
        return self

    @field_validator("SECRET_KEY")
    @classmethod
    def _validate_secret_key_in_production(cls, v: str, info: any) -> str:  # type: ignore[override]
        """Blocca chiavi deboli in produzione."""
        if "production" in str(info.data.get("ENVIRONMENT", "")):
            weak_keys = {"dev-insecure-change-in-production", "secret", "changeme"}
            if v.lower() in weak_keys:
                raise ValueError("SECRET_KEY non sicuro: usa 'openssl rand -hex 32'")
        return v

    # ── Properties di utilità ─────────────────
    @property
    def is_development(self) -> bool:
        return self.ENVIRONMENT == Environment.DEVELOPMENT

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == Environment.PRODUCTION

    @property
    def database_url_str(self) -> str:
        return str(self.DATABASE_URL)

    @property
    def timescale_url_str(self) -> str:
        return str(self.TIMESCALE_URL)

    @property
    def redis_url_str(self) -> str:
        return str(self.REDIS_URL)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """
    Singleton delle settings — cachato dopo il primo accesso.
    In test usa: app.dependency_overrides[get_settings] = lambda: Settings(...)
    """
    return Settings()  # type: ignore[call-arg]


# Shortcut per import diretto
settings: Settings = get_settings()
