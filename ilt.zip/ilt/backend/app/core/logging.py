"""
app/core/logging.py

Logging strutturato con structlog.
In dev: output colorato e leggibile.
In prod: JSON puro, pronto per Loki/Promtail.

Ogni log include automaticamente:
- timestamp ISO 8601
- level
- service name
- trace_id / span_id (se presente contesto OTel)
- logger name

Uso:
    import structlog
    log = structlog.get_logger(__name__)
    log.info("price.tick", asset="NVDA", price=820.5, source="polygon")
"""

import logging
import sys
from typing import Any

import structlog
from opentelemetry import trace

from app.core.config import settings


def _add_otel_context(
    logger: Any,  # noqa: ANN401
    method: str,
    event_dict: structlog.types.EventDict,
) -> structlog.types.EventDict:
    """
    Inietta trace_id e span_id dal contesto OpenTelemetry corrente.
    Permette la correlazione log ↔ trace in Grafana.
    """
    span = trace.get_current_span()
    if span and span.is_recording():
        ctx = span.get_span_context()
        event_dict["trace_id"] = format(ctx.trace_id, "032x")
        event_dict["span_id"] = format(ctx.span_id, "016x")
    return event_dict


def _add_service_context(
    logger: Any,  # noqa: ANN401
    method: str,
    event_dict: structlog.types.EventDict,
) -> structlog.types.EventDict:
    """Aggiunge il nome del servizio e l'ambiente ad ogni log."""
    event_dict["service"] = settings.OTEL_SERVICE_NAME
    event_dict["env"] = settings.ENVIRONMENT.value
    return event_dict


def setup_logging() -> None:
    """
    Configura structlog e il logging standard di Python.
    Da chiamare UNA SOLA VOLTA all'avvio dell'applicazione (in main.py).
    """

    # ── Shared processors (applicati sempre) ──────────────────────────────
    shared_processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,    # contesto request (request_id, user_id)
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        _add_otel_context,
        _add_service_context,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
    ]

    # ── Renderer: JSON in prod, colored in dev ─────────────────────────────
    if settings.is_development:
        renderer: structlog.types.Processor = structlog.dev.ConsoleRenderer(
            colors=True,
            exception_formatter=structlog.dev.plain_traceback,
        )
    else:
        renderer = structlog.processors.JSONRenderer()

    # ── Configure structlog ────────────────────────────────────────────────
    structlog.configure(
        processors=[
            *shared_processors,
            # ExceptionInfo deve stare prima del renderer
            structlog.processors.ExceptionRenderer(),
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.getLevelName(settings.LOG_LEVEL)
        ),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    # ── Configure stdlib logging (per librerie che usano logging.getLogger) ──
    formatter = structlog.stdlib.ProcessorFormatter(
        processors=[
            structlog.stdlib.ExtraAdder(),
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            *shared_processors,
            structlog.processors.ExceptionRenderer(),
            renderer,
        ],
        foreign_pre_chain=shared_processors,
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.handlers = [handler]
    root_logger.setLevel(settings.LOG_LEVEL)

    # Silenzia i logger rumorosi
    for noisy in ("uvicorn.access", "httpx", "httpcore", "asyncio"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    # uvicorn usa il suo handler: lo sostituiamo col nostro
    for uvicorn_logger in ("uvicorn", "uvicorn.error"):
        uv_log = logging.getLogger(uvicorn_logger)
        uv_log.handlers = [handler]
        uv_log.propagate = False


def get_logger(name: str = __name__) -> structlog.BoundLogger:
    """
    Factory function per ottenere un logger pre-configurato.

    Esempio:
        log = get_logger(__name__)
        log.info("user.login", user_id=42, ip="1.2.3.4")
    """
    return structlog.get_logger(name)


# ── Context helpers ────────────────────────────────────────────────────────────
# Da usare nei middleware per iniettare contesto request-scoped in ogni log

def bind_request_context(
    request_id: str,
    path: str,
    method: str,
    user_id: int | None = None,
) -> None:
    """
    Lega contesto HTTP al logger corrente (per tutta la durata della request).
    Usa structlog.contextvars — thread-safe e asyncio-safe.
    """
    structlog.contextvars.clear_contextvars()
    structlog.contextvars.bind_contextvars(
        request_id=request_id,
        http_path=path,
        http_method=method,
        **({"user_id": user_id} if user_id else {}),
    )


def clear_request_context() -> None:
    structlog.contextvars.clear_contextvars()
