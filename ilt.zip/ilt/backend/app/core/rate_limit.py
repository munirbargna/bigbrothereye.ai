"""
app/core/rate_limit.py

Rate limiting via slowapi (wrapper di limits su Redis).
Integrato come middleware FastAPI nel main.py.

Regole applicate:
    /api/v1/auth/login    → 10 req/min per IP  (anti brute-force)
    /api/v1/auth/register → 5 req/min per IP
    /api/v1/*             → 120 req/min per IP (default)
    /api/v1/prices/ws/*   → nessun rate limit   (WebSocket — long-lived)

Uso negli endpoint:
    @router.post("/login")
    @limiter.limit("10/minute")
    async def login(request: Request, ...):
        ...
"""

from slowapi import Limiter
from slowapi.util import get_remote_address

# ── Limiter singleton ─────────────────────────────────────────────────────────
# key_func: usa l'IP del client come chiave di rate limiting.
# Dietro Nginx/proxy, assicurarsi che X-Forwarded-For sia trusted.

limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["120/minute"],
    storage_uri=None,   # impostato dinamicamente in setup_rate_limiter()
    headers_enabled=True,  # aggiunge X-RateLimit-* headers alle risposte
)


def setup_rate_limiter(redis_url: str) -> None:
    """
    Configura il backend Redis per lo storage dei contatori.
    Da chiamare nel lifespan di FastAPI dopo init_redis().
    """
    from slowapi import Limiter
    from slowapi.util import get_remote_address
    import importlib
    import sys

    global limiter
    limiter = Limiter(
        key_func=get_remote_address,
        default_limits=["120/minute"],
        storage_uri=redis_url.replace("redis://", "redis://"),
        headers_enabled=True,
        strategy="fixed-window",
    )


# ── Decoratori pronti per gli endpoint ────────────────────────────────────────

def rate_limit_auth(limit: str = "10/minute"):
    """Decoratore per endpoint di autenticazione (più restrittivo)."""
    return limiter.limit(limit)


def rate_limit_api(limit: str = "120/minute"):
    """Decoratore standard per endpoint API."""
    return limiter.limit(limit)
