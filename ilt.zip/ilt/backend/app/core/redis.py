"""
app/core/redis.py

Client Redis singleton con connessione lazy.
Usato per cache, pub/sub e sessioni.
"""

from typing import Any

import redis.asyncio as aioredis
import structlog

from app.core.config import settings

log = structlog.get_logger(__name__)

_redis_client: aioredis.Redis | None = None


async def init_redis() -> None:
    global _redis_client
    _redis_client = aioredis.from_url(
        settings.redis_url_str,
        encoding="utf-8",
        decode_responses=True,
        socket_connect_timeout=5,
        socket_timeout=5,
        retry_on_timeout=True,
        health_check_interval=30,
    )
    await _redis_client.ping()
    log.info("redis.connected", url=settings.redis_url_str)


async def close_redis() -> None:
    global _redis_client
    if _redis_client:
        await _redis_client.aclose()
        _redis_client = None
        log.info("redis.closed")


def get_redis() -> aioredis.Redis:
    if _redis_client is None:
        raise RuntimeError("Redis non inizializzato — chiama init_redis() prima")
    return _redis_client


# ── Helpers ───────────────────────────────────────────────────────────────────

async def cache_set(key: str, value: Any, ttl: int = settings.REDIS_CACHE_TTL) -> None:
    import orjson
    client = get_redis()
    await client.setex(key, ttl, orjson.dumps(value).decode())


async def cache_get(key: str) -> Any | None:
    import orjson
    client = get_redis()
    raw = await client.get(key)
    return orjson.loads(raw) if raw else None


async def cache_delete(key: str) -> None:
    await get_redis().delete(key)
