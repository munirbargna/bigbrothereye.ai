"""
app/core/security.py

Tutto ciò che riguarda autenticazione e autorizzazione:
- Password hashing con bcrypt
- JWT access token (30 min) + refresh token (7 giorni)
- Rotazione refresh token (ogni uso ne genera uno nuovo)
- Token blacklist su Redis (per logout immediato)
"""

import hashlib
import secrets
import uuid
from datetime import datetime, timedelta, timezone

import structlog
from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings
from app.core.redis import get_redis

log = structlog.get_logger(__name__)

# ── Password hashing ──────────────────────────────────────────────────────────

_pwd_context = CryptContext(
    schemes=["bcrypt"],
    deprecated="auto",
    bcrypt__rounds=12,          # cost factor — aumenta se l'hardware scala
)


def hash_password(plain: str) -> str:
    return _pwd_context.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    return _pwd_context.verify(plain, hashed)


# ── JWT Access Token ──────────────────────────────────────────────────────────

def create_access_token(subject: str | uuid.UUID, extra: dict | None = None) -> str:
    """
    Genera un JWT access token HS256.

    Args:
        subject: user_id (UUID come stringa)
        extra:   campi aggiuntivi nel payload (es: {"role": "admin"})

    Returns:
        Token JWT firmato
    """
    now = datetime.now(timezone.utc)
    expire = now + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)

    payload = {
        "sub": str(subject),
        "iat": now,
        "exp": expire,
        "jti": str(uuid.uuid4()),   # JWT ID univoco — usato per blacklist
        "type": "access",
        **(extra or {}),
    }

    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def decode_access_token(token: str) -> dict:
    """
    Decodifica e valida un access token.

    Raises:
        JWTError: token malformato, scaduto o firma non valida
    """
    return jwt.decode(
        token,
        settings.SECRET_KEY,
        algorithms=[settings.JWT_ALGORITHM],
        options={"verify_exp": True},
    )


# ── Refresh Token ─────────────────────────────────────────────────────────────

def generate_refresh_token() -> tuple[str, str]:
    """
    Genera un refresh token opaco (random bytes).

    Returns:
        (raw_token, hashed_token)
        - raw_token: inviato al client in cookie HttpOnly
        - hashed_token: salvato nel DB (mai salvare il raw)
    """
    raw = secrets.token_urlsafe(64)
    hashed = _hash_refresh_token(raw)
    return raw, hashed


def _hash_refresh_token(token: str) -> str:
    """SHA-256 del token raw — da salvare nel DB."""
    return hashlib.sha256(token.encode()).hexdigest()


def hash_refresh_token(token: str) -> str:
    return _hash_refresh_token(token)


# ── JWT Blacklist (Redis) ─────────────────────────────────────────────────────

_BLACKLIST_PREFIX = "jwt:blacklist:"


async def blacklist_token(jti: str, expires_at: datetime) -> None:
    """
    Inserisce un JTI nella blacklist Redis.
    TTL = remaining lifetime del token (non vale la pena tenerlo oltre).
    """
    redis = get_redis()
    ttl = max(1, int((expires_at - datetime.now(timezone.utc)).total_seconds()))
    await redis.setex(f"{_BLACKLIST_PREFIX}{jti}", ttl, "1")
    log.debug("jwt.blacklisted", jti=jti, ttl_seconds=ttl)


async def is_token_blacklisted(jti: str) -> bool:
    redis = get_redis()
    return await redis.exists(f"{_BLACKLIST_PREFIX}{jti}") == 1
