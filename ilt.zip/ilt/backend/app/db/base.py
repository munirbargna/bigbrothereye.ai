"""
app/db/base.py

Base SQLAlchemy e mixin condivisi da tutti i modelli.
"""

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, func, text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """Base per tutti i modelli SQLAlchemy."""
    pass


class TimestampMixin:
    """
    Aggiunge created_at / updated_at a qualsiasi modello.
    updated_at viene aggiornato automaticamente da PostgreSQL via trigger.
    """

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class UUIDPrimaryKeyMixin:
    """
    Primary key UUID v4 generata lato DB.
    Preferita a integer per evitare enumerazione e per compatibilità
    con sistemi distribuiti.
    """

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=text("gen_random_uuid()"),
        nullable=False,
    )
