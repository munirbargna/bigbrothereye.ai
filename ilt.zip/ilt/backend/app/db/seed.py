"""
app/db/seed.py

Inserisce dati di sviluppo in entrambi i database.
Eseguire con: docker compose exec backend python -m app.db.seed

Crea:
- 2 utenti (admin + demo)
- watchlists di default con asset
- 50 price ticks storici (ultimi 5 minuti)
- 5 whale signals di esempio
- 10 dati macro di esempio
"""

import asyncio
import random
from datetime import datetime, timedelta, timezone

import structlog

log = structlog.get_logger("seed")


async def seed_app_db() -> None:
    """Seed PostgreSQL: utenti, watchlists, alerts."""
    from app.core.security import hash_password
    from app.db.session import AppSessionMaker
    from app.models.user import PriceAlert, User, Watchlist
    from sqlalchemy import select

    async with AppSessionMaker() as session:
        # Controlla se già seeded
        res = await session.execute(select(User).where(User.email == "admin@ilt.dev"))
        if res.scalar_one_or_none():
            log.info("seed.app_db_already_seeded")
            return

        # Admin
        admin = User(
            email="admin@ilt.dev",
            hashed_password=hash_password("Admin1234"),
            full_name="ILT Administrator",
            is_active=True,
            is_superuser=True,
        )
        session.add(admin)
        await session.flush()

        session.add(Watchlist(
            user_id=admin.id, name="Default",
            assets=["NVDA", "GLD", "BRENT", "SPY", "QQQ"],
            is_default=True,
        ))
        session.add(Watchlist(
            user_id=admin.id, name="Commodities",
            assets=["GLD", "SLV", "BRENT", "WTI", "GDX", "OIH"],
        ))
        session.add(PriceAlert(
            user_id=admin.id, asset="GLD",
            condition="above", threshold=5200.0,
        ))

        # Demo user
        demo = User(
            email="demo@ilt.dev",
            hashed_password=hash_password("Demo1234"),
            full_name="Demo User",
            is_active=True,
        )
        session.add(demo)
        await session.flush()
        session.add(Watchlist(
            user_id=demo.id, name="Default",
            assets=["NVDA", "AAPL", "MSFT"],
            is_default=True,
        ))

        await session.commit()
        log.info("seed.app_db_done", users=2)


async def seed_timescale_db() -> None:
    """Seed TimescaleDB: tick storici, whale signals, macro."""
    from app.db.session import TimescaleSessionMaker
    from app.models.market import MacroDataPoint, PriceTick, WhaleSignal
    from sqlalchemy import insert

    now = datetime.now(timezone.utc)

    assets = {
        "NVDA": 820.0, "AAPL": 192.0, "MSFT": 388.0,
        "SPY": 663.0, "QQQ": 456.0,
        "GLD": 510.7, "SLV": 83.1, "BRENT": 101.2, "WTI": 95.4,
    }

    # ── Price ticks: 100 tick per asset, ultimi 10 minuti ─────────────────
    tick_rows = []
    prices = dict(assets)
    for i in range(100):
        t = now - timedelta(seconds=(100 - i) * 6)
        for asset, base in assets.items():
            prices[asset] *= (1 + random.gauss(0, 0.003))
            tick_rows.append({
                "time":   t,
                "asset":  asset,
                "price":  round(prices[asset], 4),
                "volume": round(random.uniform(500_000, 5_000_000), 0),
                "source": "seed",
            })

    # ── Whale signals ──────────────────────────────────────────────────────
    signal_rows = [
        {"time": now - timedelta(hours=1), "signal_id": "seed-001",
         "asset": "NVDA", "direction": "LONG", "strength": 0.87,
         "signal_type": "dark_pool_block", "z_score": 4.2,
         "notional_usd": 42_000_000, "metadata": {"seed": True}},
        {"time": now - timedelta(hours=3), "signal_id": "seed-002",
         "asset": "GLD", "direction": "LONG", "strength": 0.72,
         "signal_type": "vwap_deviation", "vwap_deviation_pct": 0.95,
         "metadata": {"seed": True}},
        {"time": now - timedelta(hours=6), "signal_id": "seed-003",
         "asset": "SPY", "direction": "SHORT", "strength": 0.65,
         "signal_type": "isolation_forest", "z_score": -0.62,
         "metadata": {"seed": True}},
        {"time": now - timedelta(hours=12), "signal_id": "seed-004",
         "asset": "BRENT", "direction": "LONG", "strength": 0.91,
         "signal_type": "dark_pool_block", "z_score": 5.1,
         "notional_usd": 85_000_000, "metadata": {"seed": True}},
        {"time": now - timedelta(hours=18), "signal_id": "seed-005",
         "asset": "AAPL", "direction": "SHORT", "strength": 0.58,
         "signal_type": "vwap_deviation", "vwap_deviation_pct": -0.71,
         "metadata": {"seed": True}},
    ]

    # ── Macro ─────────────────────────────────────────────────────────────
    macro_rows = [
        {"time": now, "series_id": "FRED.DGS10",    "value": 4.42,  "source": "fred", "frequency": "daily", "revision_number": 0},
        {"time": now, "series_id": "FRED.VIXCLS",   "value": 27.38, "source": "fred", "frequency": "daily", "revision_number": 0},
        {"time": now, "series_id": "FRED.FEDFUNDS", "value": 5.33,  "source": "fred", "frequency": "daily", "revision_number": 0},
        {"time": now, "series_id": "FRED.DTWEXBGS", "value": 99.42, "source": "fred", "frequency": "daily", "revision_number": 0},
        {"time": now, "series_id": "EIA.PET.RWTC.D","value": 95.40, "source": "eia",  "frequency": "daily", "revision_number": 0},
    ]

    async with TimescaleSessionMaker() as session:
        await session.execute(
            insert(PriceTick).values(tick_rows).on_conflict_do_nothing()
        )
        await session.execute(
            insert(WhaleSignal).values(signal_rows).on_conflict_do_nothing()
        )
        await session.execute(
            insert(MacroDataPoint).values(macro_rows).on_conflict_do_nothing()
        )
        await session.commit()

    log.info("seed.timescale_done", ticks=len(tick_rows), signals=len(signal_rows))


async def main() -> None:
    from app.core.logging import setup_logging
    from app.core.redis import init_redis, close_redis
    from app.db.session import init_db_connections, close_db_connections

    setup_logging()
    await init_db_connections()
    await init_redis()

    log.info("seed.starting")
    await seed_app_db()
    await seed_timescale_db()
    log.info("seed.complete", hint="Login: admin@ilt.dev / Admin1234  |  demo@ilt.dev / Demo1234")

    await close_db_connections()
    await close_redis()


if __name__ == "__main__":
    asyncio.run(main())
