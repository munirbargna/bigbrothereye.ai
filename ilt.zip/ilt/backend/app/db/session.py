"""
app/db/session.py

Gestione connessioni async per i due database:
- app_engine      → PostgreSQL (entità OLTP: users, alerts, watchlists)
- timescale_engine → TimescaleDB (time-series: price_ticks, vessel_positions)

Uso nei servizi:
    async with get_app_db() as session:
        result = await session.execute(select(User).where(User.id == user_id))

Uso in FastAPI (Depends):
    @router.get("/me")
    async def me(db: AppSession):
        ...
"""

from collections.abc import AsyncGenerator
from typing import Annotated

import structlog
from fastapi import Depends
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from app.core.config import settings

log = structlog.get_logger(__name__)

# ── Engine factory ─────────────────────────────────────────────────────────────

def _create_engine(url: str, pool_size: int = 5, label: str = "db") -> AsyncEngine:
    """
    Crea un AsyncEngine con configurazione pool ottimizzata.

    - pool_pre_ping: verifica la connessione prima di usarla (evita stale connections)
    - pool_recycle: ricrea le connessioni ogni ora (evita timeout lato PostgreSQL)
    - echo: logga SQL solo in dev
    """
    return create_async_engine(
        url,
        pool_size=pool_size,
        max_overflow=settings.DB_MAX_OVERFLOW,
        pool_timeout=settings.DB_POOL_TIMEOUT,
        pool_recycle=settings.DB_POOL_RECYCLE,
        pool_pre_ping=True,
        echo=settings.is_development,  # SQL logging solo in dev
        json_serializer=lambda obj: __import__("orjson").dumps(obj).decode(),
        json_deserializer=lambda s: __import__("orjson").loads(s),
        connect_args={
            "server_settings": {
                "application_name": f"ilt-{label}",
                "jit": "off",  # JIT off per query veloci (<100ms)
            }
        },
    )


# ── Engines ────────────────────────────────────────────────────────────────────

# PostgreSQL — entità applicative
app_engine: AsyncEngine = _create_engine(
    settings.database_url_str,
    pool_size=settings.DB_POOL_SIZE,
    label="app",
)

# TimescaleDB — time-series (pool più grande per query parallele)
timescale_engine: AsyncEngine = _create_engine(
    settings.timescale_url_str,
    pool_size=settings.DB_POOL_SIZE * 2,
    label="timescale",
)

# ── Session factories ──────────────────────────────────────────────────────────

AppSessionMaker = async_sessionmaker(
    bind=app_engine,
    class_=AsyncSession,
    expire_on_commit=False,  # evita lazy load post-commit
    autoflush=False,
    autocommit=False,
)

TimescaleSessionMaker = async_sessionmaker(
    bind=timescale_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
    autocommit=False,
)

# ── Context managers ───────────────────────────────────────────────────────────

async def get_app_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Context manager / FastAPI dependency per sessione PostgreSQL.
    Fa rollback automatico su eccezione, chiude la sessione alla fine.
    """
    async with AppSessionMaker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_timescale_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Context manager / FastAPI dependency per sessione TimescaleDB.
    """
    async with TimescaleSessionMaker() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


# ── FastAPI type aliases (per Depends) ────────────────────────────────────────
# Uso: async def endpoint(db: AppSession, ts: TimescaleSession): ...

AppSession = Annotated[AsyncSession, Depends(get_app_db)]
TimescaleSession = Annotated[AsyncSession, Depends(get_timescale_db)]


# ── Lifecycle helpers (chiamati da main.py lifespan) ──────────────────────────

async def init_db_connections() -> None:
    """Verifica le connessioni all'avvio dell'applicazione."""
    for engine, name in [(app_engine, "PostgreSQL"), (timescale_engine, "TimescaleDB")]:
        try:
            async with engine.connect() as conn:
                await conn.execute(__import__("sqlalchemy").text("SELECT 1"))
            log.info("db.connected", database=name)
        except Exception as e:
            log.error("db.connection_failed", database=name, error=str(e))
            raise


async def close_db_connections() -> None:
    """Chiude tutti i pool di connessioni allo shutdown."""
    await app_engine.dispose()
    await timescale_engine.dispose()
    log.info("db.connections_closed")
