"""
app/main.py

Entry point FastAPI.
Gestisce il lifecycle dell'applicazione (startup/shutdown),
middleware, router e health check.
"""

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import ORJSONResponse
from prometheus_fastapi_instrumentator import Instrumentator

from app.core.config import settings
from app.core.logging import bind_request_context, clear_request_context, setup_logging
from app.db.session import close_db_connections, init_db_connections

# Setup logging PRIMA di qualsiasi import che usi structlog
setup_logging()
log = structlog.get_logger(__name__)


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Codice eseguito all'avvio e allo shutdown dell'applicazione.
    Pattern consigliato da FastAPI per sostituire on_event deprecated.
    """
    # ── STARTUP ───────────────────────────────────────────────────────────
    log.info("app.starting", version=settings.VERSION, env=settings.ENVIRONMENT)

    await init_db_connections()

    # Connessione Redis
    from app.core.redis import init_redis, close_redis
    await init_redis()

    # WebSocket pub/sub listener (fan-out prezzi + whale alerts)
    from app.services.ws_manager import start_pubsub_listener
    await start_pubsub_listener()

    # OpenTelemetry (solo in non-dev o se configurato)
    if settings.OTEL_EXPORTER_OTLP_ENDPOINT:
        _setup_otel(app)

    # Sentry (solo se configurato)
    if settings.SENTRY_DSN:
        import sentry_sdk
        sentry_sdk.init(
            dsn=settings.SENTRY_DSN,
            environment=settings.ENVIRONMENT,
            traces_sample_rate=0.1,
        )

    log.info("app.ready", host="0.0.0.0", port=8000)

    yield  # L'app è in esecuzione

    # ── SHUTDOWN ──────────────────────────────────────────────────────────
    log.info("app.shutting_down")
    from app.services.ws_manager import stop_pubsub_listener
    await stop_pubsub_listener()
    await close_db_connections()
    await close_redis()
    log.info("app.stopped")


def _setup_otel(app: FastAPI) -> None:
    from opentelemetry import trace
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
    from opentelemetry.instrumentation.sqlalchemy import SQLAlchemyInstrumentor
    from opentelemetry.instrumentation.redis import RedisInstrumentor
    from opentelemetry.sdk.resources import SERVICE_NAME, Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    resource = Resource(attributes={SERVICE_NAME: settings.OTEL_SERVICE_NAME})
    provider = TracerProvider(resource=resource)
    provider.add_span_processor(
        BatchSpanProcessor(OTLPSpanExporter(endpoint=settings.OTEL_EXPORTER_OTLP_ENDPOINT))
    )
    trace.set_tracer_provider(provider)
    FastAPIInstrumentor.instrument_app(app)
    SQLAlchemyInstrumentor().instrument()
    RedisInstrumentor().instrument()
    log.info("otel.configured", endpoint=settings.OTEL_EXPORTER_OTLP_ENDPOINT)


# ── App factory ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.PROJECT_NAME,
        version=settings.VERSION,
        docs_url=f"{settings.API_V1_PREFIX}/docs",
        redoc_url=f"{settings.API_V1_PREFIX}/redoc",
        openapi_url=f"{settings.API_V1_PREFIX}/openapi.json",
        default_response_class=ORJSONResponse,  # orjson: più veloce del json stdlib
        lifespan=lifespan,
    )

    # ── Middleware (ordine = LIFO: l'ultimo aggiunto è il primo eseguito) ──
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Request logging middleware
    @app.middleware("http")
    async def logging_middleware(request: Request, call_next: any) -> Response:
        import uuid
        request_id = str(uuid.uuid4())[:8]
        bind_request_context(
            request_id=request_id,
            path=request.url.path,
            method=request.method,
        )
        try:
            response = await call_next(request)
            log.info(
                "http.request",
                status=response.status_code,
                request_id=request_id,
            )
            response.headers["X-Request-ID"] = request_id
            return response
        finally:
            clear_request_context()

    # ── Prometheus metrics endpoint ────────────────────────────────────────
    Instrumentator(
        should_group_status_codes=True,
        should_ignore_untemplated=True,
        excluded_handlers=["/health", "/metrics"],
    ).instrument(app).expose(app, endpoint="/metrics")

    # ── Routers ───────────────────────────────────────────────────────────
    from app.api.v1 import router as api_router
    app.include_router(api_router, prefix=settings.API_V1_PREFIX)

    # ── Health check ──────────────────────────────────────────────────────
    @app.get("/health", tags=["infra"], include_in_schema=False)
    async def health() -> dict:
        return {"status": "ok", "version": settings.VERSION, "env": settings.ENVIRONMENT}

    return app


app = create_app()
