"""
app/models/market.py

Modelli time-series per TimescaleDB.
Questi modelli vengono mappati su hypertable — NON usare come normali tabelle PG.

TimescaleDB converte automaticamente le tabelle con una colonna `time`
in hypertable partizionate per tempo.
Vedi migration: alembic/versions/0002_create_hypertables.py
"""

from datetime import datetime

from sqlalchemy import (
    BigInteger,
    Float,
    Index,
    Integer,
    Numeric,
    SmallInteger,
    String,
    Text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base


class PriceTick(Base):
    """
    Tick di prezzo raw da Polygon.io e altri feed.

    Hypertable partizionata per giorno su `time`.
    Compressione automatica dopo 7 giorni.
    Retention policy: 2 anni.

    Nota: niente primary key UUID — TimescaleDB preferisce (time, asset)
    come chiave naturale per performance ottimali.
    """

    __tablename__ = "price_ticks"

    # TimescaleDB richiede `time` come prima colonna dell'hypertable
    time: Mapped[datetime] = mapped_column(
        primary_key=True,
        nullable=False,
    )
    asset: Mapped[str] = mapped_column(
        String(20),
        primary_key=True,
        nullable=False,
        comment="Simbolo: NVDA, GLD, BRENT, AAPL, ..."
    )
    price: Mapped[float] = mapped_column(
        Numeric(precision=18, scale=6),
        nullable=False,
    )
    bid: Mapped[float | None] = mapped_column(Numeric(precision=18, scale=6))
    ask: Mapped[float | None] = mapped_column(Numeric(precision=18, scale=6))
    volume: Mapped[float | None] = mapped_column(Float)
    source: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
        comment="polygon | marinetraffic | eia | mock"
    )

    __table_args__ = (
        # Indice composito ottimizzato per query tipo "ultimi N tick di asset X"
        Index("ix_price_ticks_asset_time", "asset", "time", postgresql_using="brin"),
    )


class OHLCVBar(Base):
    """
    Candele OHLCV pre-aggregate.
    Popolate da TimescaleDB Continuous Aggregates (non scrittura diretta).

    Timeframe: 1m, 5m, 1h, 1d
    """

    __tablename__ = "ohlcv_bars"

    time: Mapped[datetime] = mapped_column(primary_key=True, nullable=False)
    asset: Mapped[str] = mapped_column(String(20), primary_key=True, nullable=False)
    timeframe: Mapped[str] = mapped_column(
        String(5),
        primary_key=True,
        nullable=False,
        comment="1m | 5m | 1h | 1d"
    )
    open: Mapped[float] = mapped_column(Numeric(precision=18, scale=6), nullable=False)
    high: Mapped[float] = mapped_column(Numeric(precision=18, scale=6), nullable=False)
    low: Mapped[float] = mapped_column(Numeric(precision=18, scale=6), nullable=False)
    close: Mapped[float] = mapped_column(Numeric(precision=18, scale=6), nullable=False)
    volume: Mapped[float | None] = mapped_column(Float)
    vwap: Mapped[float | None] = mapped_column(Numeric(precision=18, scale=6))
    trade_count: Mapped[int | None] = mapped_column(Integer)

    __table_args__ = (
        Index("ix_ohlcv_asset_timeframe_time", "asset", "timeframe", "time"),
    )


class VesselPosition(Base):
    """
    Posizione AIS di navi cargo che trasportano materie prime.
    Aggiornato ogni 5 minuti da MarineTraffic API.
    """

    __tablename__ = "vessel_positions"

    time: Mapped[datetime] = mapped_column(primary_key=True, nullable=False)
    mmsi: Mapped[str] = mapped_column(
        String(9),
        primary_key=True,
        nullable=False,
        comment="Maritime Mobile Service Identity — identificatore univoco nave"
    )

    # Identificazione
    vessel_name: Mapped[str | None] = mapped_column(String(100))
    vessel_type: Mapped[str | None] = mapped_column(
        String(20),
        comment="oil_tanker | bulk_carrier | container | lng_tanker | gold_cargo"
    )
    flag: Mapped[str | None] = mapped_column(String(3))  # ISO 3166-1 alpha-3
    imo: Mapped[str | None] = mapped_column(String(10))

    # Posizione e navigazione
    latitude: Mapped[float] = mapped_column(Float, nullable=False)
    longitude: Mapped[float] = mapped_column(Float, nullable=False)
    speed: Mapped[float | None] = mapped_column(Float, comment="Nodi")
    heading: Mapped[float | None] = mapped_column(Float, comment="Gradi 0-360")
    nav_status: Mapped[str | None] = mapped_column(String(50))

    # Route
    destination: Mapped[str | None] = mapped_column(String(100))
    eta: Mapped[datetime | None] = mapped_column()
    draught: Mapped[float | None] = mapped_column(Float, comment="Pescaggio in metri")

    # Payload
    cargo_type: Mapped[str | None] = mapped_column(String(50))
    commodity: Mapped[str | None] = mapped_column(
        String(20),
        comment="oil | gold | silver | grain | lng"
    )
    deadweight_tonnage: Mapped[int | None] = mapped_column(Integer)

    # Chokepoint e alert
    near_chokepoint: Mapped[str | None] = mapped_column(
        String(50),
        comment="hormuz | suez | malacca | panama | cape_good_hope"
    )
    is_at_risk: Mapped[bool] = mapped_column(default=False, nullable=False)

    __table_args__ = (
        Index("ix_vessel_mmsi_time", "mmsi", "time"),
        Index("ix_vessel_commodity_time", "commodity", "time"),
        Index("ix_vessel_chokepoint", "near_chokepoint", "time"),
    )


class WhaleSignal(Base):
    """
    Segnale istituzionale rilevato dal Whale Engine.
    Contiene asset, direzione, forza del segnale e metadati del rilevamento.
    """

    __tablename__ = "whale_signals"

    time: Mapped[datetime] = mapped_column(primary_key=True, nullable=False)
    signal_id: Mapped[str] = mapped_column(
        String(36), primary_key=True, nullable=False
    )

    asset: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    direction: Mapped[str] = mapped_column(
        String(10), nullable=False, comment="LONG | SHORT | NEUTRAL"
    )
    strength: Mapped[float] = mapped_column(
        Float, nullable=False, comment="0.0 – 1.0"
    )

    # Tipo di segnale rilevato
    signal_type: Mapped[str] = mapped_column(
        String(30),
        nullable=False,
        comment="options_flow | dark_pool_block | vwap_deviation | isolation_forest"
    )

    # Valori raw che hanno triggerato il segnale
    z_score: Mapped[float | None] = mapped_column(Float)
    notional_usd: Mapped[float | None] = mapped_column(
        Float, comment="Nozionale in USD del block order"
    )
    vwap_deviation_pct: Mapped[float | None] = mapped_column(Float)

    # Metadati liberi (strike, expiry, ecc.)
    metadata: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

    # Attributzione whale (se identificabile)
    whale_profile_id: Mapped[str | None] = mapped_column(String(20))

    __table_args__ = (
        Index("ix_whale_signals_asset_time", "asset", "time"),
        Index("ix_whale_signals_strength", "strength", "time"),
    )


class MacroDataPoint(Base):
    """
    Dati macroeconomici da FRED, EIA, IEA.
    Frequenza variabile: giornaliera, settimanale, mensile.
    """

    __tablename__ = "macro_data_points"

    time: Mapped[datetime] = mapped_column(primary_key=True, nullable=False)
    series_id: Mapped[str] = mapped_column(
        String(50),
        primary_key=True,
        nullable=False,
        comment="es: FRED.DGS10, EIA.PET.WCRSTUS1.W, IEA.OPEC_PROD"
    )

    value: Mapped[float] = mapped_column(Float, nullable=False)
    unit: Mapped[str | None] = mapped_column(String(30))
    source: Mapped[str] = mapped_column(
        String(20), nullable=False, comment="fred | eia | iea | opec"
    )
    frequency: Mapped[str | None] = mapped_column(
        String(10), comment="daily | weekly | monthly | quarterly"
    )
    revision_number: Mapped[int] = mapped_column(
        SmallInteger, default=0, nullable=False,
        comment="Counter revisioni (dati macro vengono spesso rivisti)"
    )

    __table_args__ = (
        Index("ix_macro_series_time", "series_id", "time"),
    )
