"""
app/schemas/market.py

Schema Pydantic v2 per i dati di mercato:
- PriceTick / OHLCV
- WhaleSignal
- VesselPosition
- MacroDataPoint
"""

from datetime import datetime

from pydantic import BaseModel, Field


class PriceTickResponse(BaseModel):
    time: datetime
    asset: str
    price: float
    bid: float | None = None
    ask: float | None = None
    volume: float | None = None
    source: str


class OHLCVBarResponse(BaseModel):
    time: datetime
    asset: str
    timeframe: str
    open: float
    high: float
    low: float
    close: float
    volume: float | None = None
    vwap: float | None = None
    trade_count: int | None = None


class LivePriceMessage(BaseModel):
    """Messaggio WS inviato ogni 10 secondi ai client connessi."""
    type: str = "price_update"
    ts: datetime
    prices: dict[str, float]    # {"NVDA": 820.5, "GLD": 5107.0, ...}
    changes: dict[str, float]   # {"NVDA": +1.2, ...}  variazione % vs tick prec.


class WhaleSignalResponse(BaseModel):
    time: datetime
    signal_id: str
    asset: str
    direction: str
    strength: float
    signal_type: str
    z_score: float | None = None
    notional_usd: float | None = None
    vwap_deviation_pct: float | None = None
    whale_profile_id: str | None = None
    metadata: dict = Field(default_factory=dict)


class WhaleAlertMessage(BaseModel):
    """Messaggio WS per alert whale in real-time."""
    type: str = "whale_alert"
    signal: WhaleSignalResponse


class VesselPositionResponse(BaseModel):
    time: datetime
    mmsi: str
    vessel_name: str | None
    vessel_type: str | None
    latitude: float
    longitude: float
    speed: float | None
    commodity: str | None
    destination: str | None
    near_chokepoint: str | None
    is_at_risk: bool


class MacroDataResponse(BaseModel):
    time: datetime
    series_id: str
    value: float
    unit: str | None
    source: str
    frequency: str | None


class AssetSnapshotResponse(BaseModel):
    """Snapshot completo di un asset: prezzo live + OHLCV + ultimi segnali."""
    asset: str
    price: float
    change_pct_24h: float | None = None
    change_pct_7d: float | None = None
    ohlcv_1h: list[OHLCVBarResponse] = Field(default_factory=list)
    whale_signals: list[WhaleSignalResponse] = Field(default_factory=list)
    last_updated: datetime
