"""
app/services/alert_service.py

Service layer per la gestione degli alert di prezzo.
Usato sia dall'alert_worker (Celery) che dall'endpoint REST.

Separare la logica dal worker permette:
- Testing unitario senza Celery
- Riuso dall'API (es: "simula alert" in UI)
- Futura estensione a canali di notifica (email, push, Slack)
"""

import json
from datetime import datetime, timezone

import structlog
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.user import PriceAlert

log = structlog.get_logger(__name__)


def evaluate_condition(condition: str, current_price: float, threshold: float) -> bool:
    """
    Valuta se la condizione dell'alert è soddisfatta.

    Args:
        condition:     "above" | "below" | "pct_change"
        current_price: prezzo corrente dell'asset
        threshold:     soglia configurata dall'utente

    Returns:
        True se l'alert deve essere triggerato
    """
    match condition:
        case "above":
            return current_price >= threshold
        case "below":
            return current_price <= threshold
        case "pct_change":
            # threshold = soglia assoluta come proxy
            # (variazione % richiede prezzo di riferimento storico)
            return abs(current_price) >= abs(threshold)
        case _:
            log.warning("alert_service.unknown_condition", condition=condition)
            return False


async def process_alert(
    alert: PriceAlert,
    current_price: float,
    session: AsyncSession,
    redis_client: any,
) -> bool:
    """
    Processa un singolo alert: valuta la condizione, marca come triggerato
    e invia la notifica via WebSocket.

    Returns:
        True se l'alert è stato triggerato, False altrimenti.
    """
    if not evaluate_condition(alert.condition, current_price, alert.threshold):
        return False

    now = datetime.now(timezone.utc)
    alert.triggered_at = now

    log.info(
        "alert.triggered",
        alert_id=str(alert.id),
        user_id=str(alert.user_id),
        asset=alert.asset,
        condition=alert.condition,
        threshold=alert.threshold,
        current_price=current_price,
    )

    # ── Notifica WebSocket ────────────────────────────────────────────────
    channels = alert.notification_channels or {}

    if channels.get("websocket", True):
        payload = json.dumps({
            "type":          "price_alert",
            "alert_id":      str(alert.id),
            "asset":         alert.asset,
            "condition":     alert.condition,
            "threshold":     alert.threshold,
            "current_price": current_price,
            "ts":            now.isoformat(),
        })
        await redis_client.publish(f"alert:{alert.user_id}", payload)
        log.debug("alert.ws_notified", user_id=str(alert.user_id))

    # ── Email (placeholder — implementare con FastAPI-Mail) ────────────────
    if channels.get("email", False):
        log.info(
            "alert.email_queued",
            user_id=str(alert.user_id),
            asset=alert.asset,
            hint="Implementare con FastAPI-Mail o SendGrid",
        )

    return True


async def bulk_evaluate(
    alerts: list[PriceAlert],
    prices: dict[str, float],
    session: AsyncSession,
    redis_client: any,
) -> dict[str, int]:
    """
    Valuta un batch di alert contro i prezzi correnti.

    Returns:
        {"evaluated": N, "triggered": M}
    """
    triggered = 0

    for alert in alerts:
        price = prices.get(alert.asset.upper())
        if price is None:
            continue

        was_triggered = await process_alert(alert, price, session, redis_client)
        if was_triggered:
            triggered += 1

    if triggered > 0:
        await session.commit()

    return {"evaluated": len(alerts), "triggered": triggered}
