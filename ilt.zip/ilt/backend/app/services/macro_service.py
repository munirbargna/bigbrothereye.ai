"""
app/services/macro_service.py

Service per accesso ai dati macroeconomici.
Legge da Redis cache (scritto dal macro_worker) e da TimescaleDB
per serie storiche.
"""

from datetime import datetime, timedelta, timezone
from typing import Any

import structlog
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.redis import cache_get
from app.models.market import MacroDataPoint

log = structlog.get_logger(__name__)

# ── Series metadata ────────────────────────────────────────────────────────────

SERIES_META: dict[str, dict[str, str]] = {
    "FRED.DGS10":       {"label": "US 10Y Yield",     "unit": "%",   "category": "rates"},
    "FRED.DGS2":        {"label": "US 2Y Yield",      "unit": "%",   "category": "rates"},
    "FRED.FEDFUNDS":    {"label": "Fed Funds Rate",   "unit": "%",   "category": "rates"},
    "FRED.T10YIE":      {"label": "10Y Breakeven",    "unit": "%",   "category": "inflation"},
    "FRED.CPIAUCSL":    {"label": "CPI (Urban)",      "unit": "idx", "category": "inflation"},
    "FRED.VIXCLS":      {"label": "VIX",              "unit": "pts", "category": "volatility"},
    "FRED.DTWEXBGS":    {"label": "DXY (proxy)",      "unit": "idx", "category": "fx"},
    "FRED.DEXUSEU":     {"label": "EUR/USD",          "unit": "rate","category": "fx"},
    "FRED.UNRATE":      {"label": "Unemployment",     "unit": "%",   "category": "labor"},
    "EIA.PET.WCRSTUS1.W": {"label": "US Crude Stocks","unit": "kbbl","category": "energy"},
    "EIA.PET.RWTC.D":   {"label": "WTI Spot",         "unit": "$",   "category": "energy"},
    "EIA.NG.RNGWHHD.D": {"label": "Henry Hub Gas",   "unit": "$/mmbtu","category": "energy"},
    "EIA.STEO.COPRPUS.M": {"label": "US Production", "unit": "kbbl/d","category": "energy"},
}


# ── Live snapshot ─────────────────────────────────────────────────────────────

async def get_macro_snapshot() -> dict[str, Any]:
    """
    Restituisce l'ultimo snapshot macro dalla cache Redis.
    Formato: {series_id: value, ...}
    """
    cached = await cache_get("macro:latest")
    if cached:
        return cached
    log.warning("macro_service.cache_miss")
    return {}


async def get_macro_enriched() -> list[dict]:
    """
    Snapshot macro arricchito con metadati (label, unit, category).
    Usato dalla dashboard per il MacroBar.
    """
    raw = await get_macro_snapshot()
    result = []
    for series_id, value in raw.items():
        meta = SERIES_META.get(series_id, {})
        result.append({
            "series_id": series_id,
            "value":     round(value, 4),
            "label":     meta.get("label", series_id),
            "unit":      meta.get("unit", ""),
            "category":  meta.get("category", "other"),
        })
    # Ordina per categoria
    result.sort(key=lambda x: (x["category"], x["label"]))
    return result


# ── Historical series ─────────────────────────────────────────────────────────

async def get_series_history(
    db: AsyncSession,
    series_id: str,
    days: int = 90,
) -> list[dict]:
    """
    Storico di una serie macro da TimescaleDB.
    Restituisce [{time, value}, ...] ordinato per data.
    """
    since = datetime.now(timezone.utc) - timedelta(days=days)

    result = await db.execute(
        select(MacroDataPoint)
        .where(
            MacroDataPoint.series_id == series_id,
            MacroDataPoint.time >= since,
        )
        .order_by(MacroDataPoint.time.asc())
    )

    return [
        {"time": row.time.isoformat(), "value": float(row.value)}
        for row in result.scalars().all()
    ]


# ── Derived indicators ────────────────────────────────────────────────────────

async def get_yield_curve_spread() -> float | None:
    """
    Spread 10Y - 2Y (indicatore di inversione della curva).
    Negativo = curva invertita (segnale recessione).
    """
    snap = await get_macro_snapshot()
    t10 = snap.get("FRED.DGS10")
    t2  = snap.get("FRED.DGS2")
    if t10 is not None and t2 is not None:
        return round(t10 - t2, 3)
    return None


async def get_fear_greed_proxy() -> dict:
    """
    Proxy Fear & Greed basato su VIX + yield spread + momentum equity.
    Score 0–100: 0 = extreme fear, 100 = extreme greed.
    """
    snap = await get_macro_snapshot()
    vix      = snap.get("FRED.VIXCLS", 20.0)
    spread   = await get_yield_curve_spread() or 0.5

    # VIX component: VIX 10 = bullish (greed), VIX 40 = bearish (fear)
    vix_score = max(0, min(100, (40 - vix) / 30 * 100))

    # Spread component: spread positivo = sano, negativo = fear
    spread_score = max(0, min(100, (spread + 1.0) / 2.0 * 100))

    composite = round(vix_score * 0.6 + spread_score * 0.4, 1)

    label = (
        "Extreme Fear"  if composite < 25  else
        "Fear"          if composite < 45  else
        "Neutral"       if composite < 55  else
        "Greed"         if composite < 75  else
        "Extreme Greed"
    )

    return {
        "score":          composite,
        "label":          label,
        "vix":            round(vix, 2),
        "yield_spread":   spread,
        "components":     {"vix_score": round(vix_score, 1), "spread_score": round(spread_score, 1)},
    }
