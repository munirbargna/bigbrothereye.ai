"""
app/services/price_service.py

Service layer per accesso ai dati di prezzo da TimescaleDB.
Separato dagli endpoint: gli endpoint chiamano il service,
il service parla col DB. Testabile in isolamento.
"""

from datetime import datetime, timedelta, timezone

import structlog
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.redis import cache_get, cache_set
from app.models.market import OHLCVBar, PriceTick, WhaleSignal
from app.schemas.market import (
    AssetSnapshotResponse,
    OHLCVBarResponse,
    PriceTickResponse,
    WhaleSignalResponse,
)

log = structlog.get_logger(__name__)

# ── Asset universe ─────────────────────────────────────────────────────────────

TRACKED_ASSETS = [
    "NVDA", "AAPL", "MSFT", "TSLA", "META", "AMZN",
    "SPY", "QQQ", "GLD", "SLV", "GDX", "OIH",
    "BRENT", "WTI",
]


# ── Live prices (from Redis cache) ────────────────────────────────────────────

async def get_live_prices() -> dict[str, float]:
    """
    Recupera i prezzi live dalla cache Redis.
    Aggiornati dal worker ogni 10 secondi.
    Fallback a TimescaleDB se cache mancante.
    """
    cached = await cache_get("live:prices")
    if cached:
        return cached
    log.warning("price_service.cache_miss", key="live:prices")
    return {}


async def set_live_prices(prices: dict[str, float]) -> None:
    """Scrive i prezzi live in Redis. Chiamato dal worker dopo ogni poll."""
    await cache_set("live:prices", prices, ttl=30)


# ── TimescaleDB queries ───────────────────────────────────────────────────────

async def get_recent_ticks(
    db: AsyncSession,
    asset: str,
    limit: int = 100,
    since: datetime | None = None,
) -> list[PriceTickResponse]:
    """Ultimi N tick per un asset, opzionalmente da un timestamp specifico."""
    since = since or (datetime.now(timezone.utc) - timedelta(hours=1))

    result = await db.execute(
        select(PriceTick)
        .where(PriceTick.asset == asset.upper(), PriceTick.time >= since)
        .order_by(PriceTick.time.desc())
        .limit(limit)
    )
    ticks = result.scalars().all()
    return [PriceTickResponse.model_validate(t, from_attributes=True) for t in ticks]


async def get_ohlcv(
    db: AsyncSession,
    asset: str,
    timeframe: str = "1h",
    limit: int = 200,
    since: datetime | None = None,
) -> list[OHLCVBarResponse]:
    """
    Candele OHLCV da TimescaleDB.
    Usa le continuous aggregate views (ohlcv_1m, ohlcv_1h) per performance.
    """
    cache_key = f"ohlcv:{asset}:{timeframe}:{limit}"
    cached = await cache_get(cache_key)
    if cached:
        return [OHLCVBarResponse(**c) for c in cached]

    # Mappa timeframe → view TimescaleDB
    view_map = {"1m": "ohlcv_1m", "1h": "ohlcv_1h", "1d": "ohlcv_bars"}
    view = view_map.get(timeframe, "ohlcv_bars")
    since_ts = since or (datetime.now(timezone.utc) - timedelta(hours=limit))

    # Query raw su view materializzata — più veloce di ORM su hypertable
    sql = text(f"""
        SELECT
            bucket AS time,
            asset,
            :timeframe AS timeframe,
            open, high, low, close,
            volume,
            NULL AS vwap,
            trade_count
        FROM {view}
        WHERE asset = :asset
          AND bucket >= :since
        ORDER BY bucket DESC
        LIMIT :limit
    """)

    result = await db.execute(
        sql,
        {"asset": asset.upper(), "timeframe": timeframe, "since": since_ts, "limit": limit},
    )
    rows = result.mappings().all()
    bars = [OHLCVBarResponse(**dict(r)) for r in rows]

    # Cache per 60s (aggiornata dal worker)
    await cache_set(cache_key, [b.model_dump(mode="json") for b in bars], ttl=60)
    return bars


async def get_asset_snapshot(
    db: AsyncSession,
    ts_db: AsyncSession,
    asset: str,
) -> AssetSnapshotResponse:
    """
    Snapshot completo: prezzo live + OHLCV 1h (ultime 48 candele) + segnali whale recenti.
    """
    asset = asset.upper()
    prices = await get_live_prices()
    current_price = prices.get(asset, 0.0)

    # OHLCV ultime 48 ore
    ohlcv = await get_ohlcv(ts_db, asset, timeframe="1h", limit=48)

    # Calcola variazioni %
    change_24h = None
    change_7d = None
    if ohlcv and current_price:
        price_24h_ago = next(
            (b.close for b in ohlcv if b.time <= datetime.now(timezone.utc) - timedelta(hours=24)),
            None,
        )
        if price_24h_ago:
            change_24h = round((current_price - price_24h_ago) / price_24h_ago * 100, 2)

    # Whale signals ultimi 2 giorni
    result = await ts_db.execute(
        select(WhaleSignal)
        .where(
            WhaleSignal.asset == asset,
            WhaleSignal.time >= datetime.now(timezone.utc) - timedelta(days=2),
        )
        .order_by(WhaleSignal.time.desc())
        .limit(10)
    )
    signals = [
        WhaleSignalResponse.model_validate(s, from_attributes=True)
        for s in result.scalars().all()
    ]

    return AssetSnapshotResponse(
        asset=asset,
        price=current_price,
        change_pct_24h=change_24h,
        change_pct_7d=change_7d,
        ohlcv_1h=ohlcv,
        whale_signals=signals,
        last_updated=datetime.now(timezone.utc),
    )
