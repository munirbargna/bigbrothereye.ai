"""
app/services/ws_manager.py

WebSocket connection manager con fan-out via Redis pub/sub.

Architettura:
    Worker → XADD Redis Stream "prices"
    ws_manager → SUBSCRIBE canale "prices:broadcast"
    ws_manager → broadcast JSON a tutti i client WS connessi

Il pub/sub Redis garantisce che in un setup multi-process/multi-worker
tutti i processi Uvicorn possano inviare messaggi a tutti i client,
indipendentemente su quale processo è aperta la connessione WS.

Canali Redis:
    prices:broadcast    → aggiornamenti prezzi ogni 10s
    whale:broadcast     → alert whale in tempo reale
    alert:{user_id}     → alert personalizzati per utente
"""

import asyncio
import json
from collections import defaultdict
from typing import Any

import structlog
from fastapi import WebSocket, WebSocketDisconnect

from app.core.redis import get_redis

log = structlog.get_logger(__name__)

# ── Connection registry ────────────────────────────────────────────────────────

class ConnectionManager:
    """
    Mantiene le connessioni WS attive in memoria (per-process).
    Il fan-out cross-process avviene via Redis pub/sub.
    """

    def __init__(self) -> None:
        # Set di connessioni anonime (live feed pubblico)
        self._global: set[WebSocket] = set()
        # Map user_id → set di connessioni (per alert personalizzati)
        self._user: defaultdict[str, set[WebSocket]] = defaultdict(set)
        self._lock = asyncio.Lock()

    async def connect(self, ws: WebSocket, user_id: str | None = None) -> None:
        await ws.accept()
        async with self._lock:
            self._global.add(ws)
            if user_id:
                self._user[user_id].add(ws)
        log.debug("ws.connected", user_id=user_id, total=len(self._global))

    async def disconnect(self, ws: WebSocket, user_id: str | None = None) -> None:
        async with self._lock:
            self._global.discard(ws)
            if user_id:
                self._user[user_id].discard(ws)
                if not self._user[user_id]:
                    del self._user[user_id]
        log.debug("ws.disconnected", user_id=user_id, total=len(self._global))

    async def broadcast(self, message: Any) -> None:
        """Invia a tutti i client connessi su questo processo."""
        if not self._global:
            return
        raw = json.dumps(message) if not isinstance(message, str) else message
        dead: set[WebSocket] = set()
        for ws in list(self._global):
            try:
                await ws.send_text(raw)
            except Exception:
                dead.add(ws)
        # Rimuovi connessioni morte
        async with self._lock:
            for ws in dead:
                self._global.discard(ws)

    async def send_to_user(self, user_id: str, message: Any) -> None:
        """Invia a tutti i client di uno specifico utente."""
        conns = self._user.get(user_id, set())
        if not conns:
            return
        raw = json.dumps(message) if not isinstance(message, str) else message
        dead: set[WebSocket] = set()
        for ws in list(conns):
            try:
                await ws.send_text(raw)
            except Exception:
                dead.add(ws)
        async with self._lock:
            for ws in dead:
                self._user[user_id].discard(ws)

    @property
    def connection_count(self) -> int:
        return len(self._global)


# Singleton del manager (per-process)
manager = ConnectionManager()


# ── Redis pub/sub listener ─────────────────────────────────────────────────────

_CHANNELS = ["prices:broadcast", "whale:broadcast"]
_subscriber_task: asyncio.Task | None = None


async def start_pubsub_listener() -> None:
    """
    Avvia il loop di ascolto Redis pub/sub in background.
    Chiamato dal lifespan di FastAPI.
    """
    global _subscriber_task
    _subscriber_task = asyncio.create_task(_pubsub_loop(), name="ws-pubsub-listener")
    log.info("ws.pubsub_listener_started", channels=_CHANNELS)


async def stop_pubsub_listener() -> None:
    global _subscriber_task
    if _subscriber_task and not _subscriber_task.done():
        _subscriber_task.cancel()
        try:
            await _subscriber_task
        except asyncio.CancelledError:
            pass
    log.info("ws.pubsub_listener_stopped")


async def _pubsub_loop() -> None:
    """
    Loop principale: subscribe ai canali Redis e fa broadcast
    a tutti i WS connessi su questo processo.
    """
    redis = get_redis()
    pubsub = redis.pubsub()
    await pubsub.subscribe(*_CHANNELS)

    try:
        async for message in pubsub.listen():
            if message["type"] != "message":
                continue
            channel = message["channel"]
            data = message["data"]

            if channel == "prices:broadcast":
                await manager.broadcast(data)
            elif channel == "whale:broadcast":
                await manager.broadcast(data)
            elif channel.startswith("alert:"):
                user_id = channel.split(":", 1)[1]
                await manager.send_to_user(user_id, data)

    except asyncio.CancelledError:
        pass
    except Exception as e:
        log.error("ws.pubsub_error", error=str(e))
    finally:
        await pubsub.unsubscribe()
        await pubsub.aclose()


# ── Publisher helpers (usati dai worker) ─────────────────────────────────────

async def publish_prices(prices: dict) -> None:
    """Pubblica aggiornamento prezzi sul canale Redis."""
    redis = get_redis()
    await redis.publish("prices:broadcast", json.dumps(prices))


async def publish_whale_alert(signal: dict) -> None:
    """Pubblica whale alert sul canale Redis."""
    redis = get_redis()
    await redis.publish("whale:broadcast", json.dumps({"type": "whale_alert", **signal}))


async def publish_user_alert(user_id: str, alert: dict) -> None:
    """Pubblica alert personalizzato per un utente specifico."""
    redis = get_redis()
    await redis.publish(f"alert:{user_id}", json.dumps(alert))
