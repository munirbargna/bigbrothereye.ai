"""
app/workers/alert_worker.py

Valuta i price alert degli utenti ad ogni tick di prezzo.
Se un alert è triggerato:
  1. Marca triggered_at nel DB
  2. Pubblica notifica personalizzata via Redis pub/sub → WebSocket utente
  3. (opzionale) accoda email se richiesto dall'utente

Eseguito ogni PRICES_POLL_INTERVAL secondi (stesso rate del price worker).
"""

import asyncio
import json
from datetime import datetime, timezone
from typing import Any

import structlog
from tenacity import retry, stop_after_attempt, wait_fixed

from app.workers.celery_app import celery_app

log = structlog.get_logger(__name__)


@celery_app.task(
    name="app.workers.alert_worker.evaluate_price_alerts",
    bind=True,
    max_retries=2,
    soft_time_limit=20,
    time_limit=25,
)
def evaluate_price_alerts(self: Any) -> dict:
    try:
        return asyncio.run(_async_evaluate())
    except Exception as exc:
        log.error("alert_worker.failed", error=str(exc))
        raise self.retry(exc=exc)


async def _async_evaluate() -> dict:
    from app.core.redis import cache_get, get_redis
    from app.db.session import AppSessionMaker
    from app.models.user import PriceAlert
    from sqlalchemy import select

    # ── 1. Leggi prezzi live da Redis (scritti dal price_worker) ──────────
    prices: dict[str, float] = await cache_get("live:prices") or {}
    if not prices:
        return {"evaluated": 0, "triggered": 0}

    triggered_count = 0

    async with AppSessionMaker() as session:
        # Carica tutti gli alert attivi non ancora triggerati
        result = await session.execute(
            select(PriceAlert).where(
                PriceAlert.is_active == True,  # noqa: E712
                PriceAlert.triggered_at == None,  # noqa: E711
            )
        )
        alerts = result.scalars().all()

        redis = get_redis()
        now = datetime.now(timezone.utc)

        for alert in alerts:
            current_price = prices.get(alert.asset.upper())
            if current_price is None:
                continue

            triggered = _check_condition(alert.condition, current_price, alert.threshold)
            if not triggered:
                continue

            # Marca come triggerato
            alert.triggered_at = now
            triggered_count += 1

            log.info(
                "alert.triggered",
                user_id=str(alert.user_id),
                asset=alert.asset,
                condition=alert.condition,
                threshold=alert.threshold,
                current_price=current_price,
            )

            # Pubblica notifica WebSocket personalizzata per l'utente
            notification = json.dumps({
                "type":          "price_alert",
                "asset":         alert.asset,
                "condition":     alert.condition,
                "threshold":     alert.threshold,
                "current_price": current_price,
                "ts":            now.isoformat(),
                "alert_id":      str(alert.id),
            })
            channels = alert.notification_channels or {}
            if channels.get("websocket", True):
                await redis.publish(f"alert:{alert.user_id}", notification)

        if triggered_count > 0:
            await session.commit()

    return {"evaluated": len(alerts), "triggered": triggered_count}


def _check_condition(condition: str, price: float, threshold: float) -> bool:
    """
    Valuta la condizione dell'alert.
    condition: "above" | "below" | "pct_change"
    """
    if condition == "above":
        return price >= threshold
    if condition == "below":
        return price <= threshold
    if condition == "pct_change":
        # threshold = % di variazione assoluta (es. 5.0 = ±5%)
        # Qui non abbiamo il prezzo di riferimento, quindi controlliamo
        # il prezzo corrente contro una soglia assoluta come fallback
        return abs(price) >= abs(threshold)
    return False
