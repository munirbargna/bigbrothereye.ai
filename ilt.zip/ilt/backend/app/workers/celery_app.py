"""
app/workers/celery_app.py

Configurazione Celery + beat schedule ufficiale.

Queue layout:
    prices   → price_worker + alert_worker  (ogni 10s)
    vessels  → vessel_worker                (ogni 5 min)
    macro    → macro_worker                 (ogni 1 ora)
"""

from app.core.config import settings
from celery import Celery

celery_app = Celery(
    "ilt_workers",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
    include=[
        "app.workers.price_worker",
        "app.workers.vessel_worker",
        "app.workers.macro_worker",
        "app.workers.alert_worker",
    ],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    task_routes={
        "app.workers.price_worker.*":  {"queue": "prices"},
        "app.workers.vessel_worker.*": {"queue": "vessels"},
        "app.workers.macro_worker.*":  {"queue": "macro"},
        "app.workers.alert_worker.*":  {"queue": "prices"},
    },
    beat_schedule={
        "fetch-prices": {
            "task":     "app.workers.price_worker.fetch_and_store_prices",
            "schedule": settings.PRICES_POLL_INTERVAL,
            "options":  {"queue": "prices"},
        },
        "fetch-vessels": {
            "task":     "app.workers.vessel_worker.fetch_and_store_vessels",
            "schedule": settings.VESSELS_POLL_INTERVAL,
            "options":  {"queue": "vessels"},
        },
        "fetch-macro": {
            "task":     "app.workers.macro_worker.fetch_and_store_macro",
            "schedule": settings.MACRO_POLL_INTERVAL,
            "options":  {"queue": "macro"},
        },
        "evaluate-alerts": {
            "task":     "app.workers.alert_worker.evaluate_price_alerts",
            "schedule": settings.PRICES_POLL_INTERVAL,
            "options":  {"queue": "prices"},
        },
    },
)
