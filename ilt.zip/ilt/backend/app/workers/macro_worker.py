"""
app/workers/macro_worker.py

Ingestion dati macroeconomici da:
- FRED (Federal Reserve): tassi, CPI, DXY, spread
- EIA (Energy Information Administration): petrolio, gas, riserve SPR
- IEA / OPEC: produzione, domanda globale (scraping)

Frequenza: ogni ora (schedule in celery_app.py).
Tutti i dati finiscono in macro_data_points su TimescaleDB.
"""

import asyncio
from datetime import datetime, timezone
from typing import Any

import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from app.workers.celery_app import celery_app

log = structlog.get_logger(__name__)

# ── Series catalog ─────────────────────────────────────────────────────────────
# series_id → (source, url_path, description)

FRED_SERIES: dict[str, str] = {
    "FRED.DGS10":     "DGS10",       # US 10Y Treasury yield
    "FRED.DGS2":      "DGS2",        # US 2Y Treasury yield
    "FRED.DEXUSEU":   "DEXUSEU",     # EUR/USD exchange rate
    "FRED.DTWEXBGS":  "DTWEXBGS",    # USD Trade Weighted Index (DXY proxy)
    "FRED.CPIAUCSL":  "CPIAUCSL",    # CPI All Urban Consumers
    "FRED.FEDFUNDS":  "FEDFUNDS",    # Fed Funds Rate
    "FRED.UNRATE":    "UNRATE",      # Unemployment Rate
    "FRED.T10YIE":    "T10YIE",      # 10Y Breakeven Inflation Rate
    "FRED.VIXCLS":    "VIXCLS",      # CBOE Volatility Index
}

EIA_SERIES: dict[str, tuple[str, str]] = {
    "EIA.PET.WCRSTUS1.W":  ("PET",    "WCRSTUS1"),   # US crude oil inventories
    "EIA.PET.WTTSTUS1.W":  ("PET",    "WTTSTUS1"),   # Total crude + petroleum stocks
    "EIA.PET.RWTC.D":      ("PET",    "RWTC"),        # WTI spot price daily
    "EIA.NG.RNGWHHD.D":    ("NG",     "RNGWHHD"),    # Henry Hub natural gas
    "EIA.STEO.COPRPUS.M":  ("STEO",   "COPRPUS"),    # US crude production
    "EIA.STEO.PATC_WORLD.M": ("STEO", "PATC_WORLD"), # World petroleum consumption
}


# ── FRED fetch ────────────────────────────────────────────────────────────────

@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=2, max=15), reraise=True)
async def _fetch_fred_series(series_id: str, fred_id: str, api_key: str) -> list[dict]:
    import httpx

    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(
            "https://api.stlouisfed.org/fred/series/observations",
            params={
                "series_id":      fred_id,
                "api_key":        api_key,
                "file_type":      "json",
                "observation_start": "2020-01-01",
                "sort_order":     "desc",
                "limit":          30,  # ultimi 30 valori
            },
        )
        resp.raise_for_status()
        data = resp.json()

    rows = []
    for obs in data.get("observations", []):
        try:
            value = float(obs["value"])
        except (ValueError, TypeError):
            continue  # valore "." = dato non disponibile in FRED

        rows.append({
            "time":             datetime.fromisoformat(obs["date"]).replace(tzinfo=timezone.utc),
            "series_id":        series_id,
            "value":            value,
            "unit":             None,
            "source":           "fred",
            "frequency":        "daily",
            "revision_number":  0,
        })
    return rows


# ── EIA fetch ─────────────────────────────────────────────────────────────────

@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=2, max=15), reraise=True)
async def _fetch_eia_series(series_id: str, category: str, eia_id: str, api_key: str) -> list[dict]:
    import httpx

    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(
            f"https://api.eia.gov/v2/{category.lower()}/data/",
            params={
                "api_key":         api_key,
                "frequency":       "weekly",
                "data[0]":         "value",
                "facets[series][]": eia_id,
                "sort[0][column]": "period",
                "sort[0][direction]": "desc",
                "length":          20,
            },
        )
        resp.raise_for_status()
        data = resp.json()

    rows = []
    for item in data.get("response", {}).get("data", []):
        try:
            value = float(item["value"])
            period = item["period"]
            # EIA usa formati misti: "2026-03-14", "2026-03", "2026"
            if len(period) == 10:
                dt = datetime.fromisoformat(period).replace(tzinfo=timezone.utc)
            elif len(period) == 7:
                dt = datetime.fromisoformat(f"{period}-01").replace(tzinfo=timezone.utc)
            else:
                continue
        except (ValueError, TypeError, KeyError):
            continue

        rows.append({
            "time":             dt,
            "series_id":        series_id,
            "value":            value,
            "unit":             item.get("unit"),
            "source":           "eia",
            "frequency":        "weekly",
            "revision_number":  0,
        })
    return rows


# ── Mock data (usato senza API keys) ─────────────────────────────────────────

def _mock_macro_data() -> list[dict]:
    """Genera snapshot macro realistici per dev senza API keys."""
    import random
    now = datetime.now(timezone.utc)

    base_values = {
        "FRED.DGS10":       4.42,
        "FRED.DGS2":        4.71,
        "FRED.DEXUSEU":     1.085,
        "FRED.DTWEXBGS":    99.42,
        "FRED.CPIAUCSL":    314.2,
        "FRED.FEDFUNDS":    5.33,
        "FRED.UNRATE":      4.1,
        "FRED.T10YIE":      2.24,
        "FRED.VIXCLS":      27.38,
        "EIA.PET.WCRSTUS1.W":   432_000,  # migliaia di barili
        "EIA.PET.RWTC.D":        95.40,
        "EIA.NG.RNGWHHD.D":       2.18,
        "EIA.STEO.COPRPUS.M":     13_200,  # migliaia bbl/giorno
        "EIA.STEO.PATC_WORLD.M":  103_000, # migliaia bbl/giorno
    }

    rows = []
    for sid, base in base_values.items():
        noise = random.gauss(0, base * 0.003)
        source = "fred" if sid.startswith("FRED") else "eia"
        rows.append({
            "time":             now,
            "series_id":        sid,
            "value":            round(base + noise, 4),
            "unit":             None,
            "source":           source,
            "frequency":        "daily",
            "revision_number":  0,
        })
    return rows


# ── Celery task ───────────────────────────────────────────────────────────────

@celery_app.task(
    name="app.workers.macro_worker.fetch_and_store_macro",
    bind=True,
    max_retries=2,
    soft_time_limit=120,
    time_limit=150,
)
def fetch_and_store_macro(self: Any) -> dict:
    try:
        return asyncio.run(_async_fetch_macro())
    except Exception as exc:
        log.error("macro_worker.failed", error=str(exc))
        raise self.retry(exc=exc)


async def _async_fetch_macro() -> dict:
    from app.core.config import settings
    from app.db.session import TimescaleSessionMaker
    from sqlalchemy.dialects.postgresql import insert as pg_insert
    from app.models.market import MacroDataPoint

    all_rows: list[dict] = []

    if settings.FRED_API_KEY:
        tasks = [
            _fetch_fred_series(sid, fred_id, settings.FRED_API_KEY)
            for sid, fred_id in FRED_SERIES.items()
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for res in results:
            if isinstance(res, list):
                all_rows.extend(res)
            else:
                log.warning("macro_worker.fred_series_failed", error=str(res))
    else:
        log.debug("macro_worker.using_mock", reason="no FRED key")

    if settings.EIA_API_KEY:
        tasks_eia = [
            _fetch_eia_series(sid, cat, eia_id, settings.EIA_API_KEY)
            for sid, (cat, eia_id) in EIA_SERIES.items()
        ]
        results_eia = await asyncio.gather(*tasks_eia, return_exceptions=True)
        for res in results_eia:
            if isinstance(res, list):
                all_rows.extend(res)
            else:
                log.warning("macro_worker.eia_series_failed", error=str(res))
    else:
        log.debug("macro_worker.using_mock", reason="no EIA key")

    # Fallback mock se nessuna API key configurata
    if not all_rows:
        all_rows = _mock_macro_data()
        source_tag = "mock"
    else:
        source_tag = "live"

    if not all_rows:
        return {"series": 0, "source": source_tag}

    async with TimescaleSessionMaker() as session:
        # INSERT ... ON CONFLICT DO UPDATE per gestire revisioni
        stmt = (
            pg_insert(MacroDataPoint)
            .values(all_rows)
            .on_conflict_do_update(
                index_elements=["time", "series_id"],
                set_={
                    "value": pg_insert(MacroDataPoint).excluded.value,
                    "revision_number": MacroDataPoint.revision_number + 1,
                },
            )
        )
        await session.execute(stmt)
        await session.commit()

    # Cache valori correnti in Redis per accesso rapido
    import json
    from app.core.redis import get_redis

    latest: dict[str, float] = {}
    seen: set[str] = set()
    for row in all_rows:
        sid = row["series_id"]
        if sid not in seen:
            latest[sid] = row["value"]
            seen.add(sid)

    redis = get_redis()
    await redis.setex("macro:latest", 3600, json.dumps(latest))

    log.info("macro_worker.completed", series=len(seen), source=source_tag)
    return {"series": len(seen), "source": source_tag}
