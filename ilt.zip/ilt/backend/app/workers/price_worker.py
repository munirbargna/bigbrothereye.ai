"""
app/workers/price_worker.py

Worker Celery per ingestion prezzi.

Flusso:
    1. Fetch dati da Polygon.io (o mock se no API key)
    2. Salva tick su TimescaleDB via INSERT batch
    3. Aggiorna cache Redis "live:prices"
    4. Pubblica su canale Redis "prices:broadcast" → WebSocket fan-out
"""

import asyncio
import random
from datetime import datetime, timezone
from typing import Any

import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from app.workers.celery_app import celery_app

log = structlog.get_logger(__name__)

# ── Stato prezzi mock (simula random walk realistico) ─────────────────────────

_MOCK_STATE: dict[str, float] = {
    "NVDA":  820.0,
    "AAPL":  192.0,
    "MSFT":  388.0,
    "TSLA":  248.0,
    "META":  512.0,
    "AMZN":  195.0,
    "SPY":   663.0,
    "QQQ":   456.0,
    "GLD":   510.7,
    "SLV":    83.1,
    "GDX":    42.0,
    "OIH":   295.0,
    "BRENT": 101.2,
    "WTI":    95.4,
}

_VOLATILITY: dict[str, float] = {
    "NVDA": 0.015, "AAPL": 0.008, "MSFT": 0.007, "TSLA": 0.025,
    "META": 0.012, "AMZN": 0.010, "SPY": 0.006, "QQQ": 0.008,
    "GLD":  0.006, "SLV":  0.015, "GDX": 0.018, "OIH": 0.016,
    "BRENT": 0.012, "WTI": 0.013,
}


def _mock_tick() -> dict[str, float]:
    """Random walk con trend leggero per ogni asset."""
    for asset, vol in _VOLATILITY.items():
        change = random.gauss(0, vol)
        _MOCK_STATE[asset] *= (1 + change)
        # Price floors realistici
        floors = {"GLD": 4800, "SLV": 70, "BRENT": 80, "WTI": 75}
        _MOCK_STATE[asset] = max(_MOCK_STATE[asset], floors.get(asset, 1.0))
    return {k: round(v, 4) for k, v in _MOCK_STATE.items()}


# ── Polygon.io fetch ──────────────────────────────────────────────────────────

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    reraise=True,
)
async def _fetch_polygon_snapshot() -> dict[str, float]:
    """
    Recupera snapshot prezzi da Polygon.io REST API.
    Usa il batch endpoint /v2/snapshot/locale/us/markets/stocks/tickers.
    """
    import httpx
    from app.core.config import settings

    tickers = [t for t in _MOCK_STATE.keys() if t not in ("BRENT", "WTI")]
    url = "https://api.polygon.io/v2/snapshot/locale/us/markets/stocks/tickers"
    params = {
        "tickers": ",".join(tickers),
        "apiKey": settings.POLYGON_API_KEY,
    }

    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.get(url, params=params)
        resp.raise_for_status()
        data = resp.json()

    prices = {}
    for ticker_data in data.get("tickers", []):
        sym = ticker_data["ticker"]
        prices[sym] = ticker_data["day"]["c"]  # close price

    # Commodity — Polygon ha endpoint separati per forex/futures
    prices["GLD"] = await _fetch_polygon_commodity("GLD")
    prices["SLV"] = await _fetch_polygon_commodity("SLV")

    return prices


async def _fetch_polygon_commodity(symbol: str) -> float:
    """Fetch ETF commodity (GLD/SLV) come proxy per gold/silver spot."""
    import httpx
    from app.core.config import settings

    url = f"https://api.polygon.io/v2/last/trade/{symbol}"
    async with httpx.AsyncClient(timeout=5.0) as client:
        resp = await client.get(url, params={"apiKey": settings.POLYGON_API_KEY})
        resp.raise_for_status()
        return resp.json()["results"]["p"]


# ── Task principale ───────────────────────────────────────────────────────────

@celery_app.task(
    name="app.workers.price_worker.fetch_and_store_prices",
    bind=True,
    max_retries=3,
    default_retry_delay=5,
    soft_time_limit=25,   # 25s limit (task ogni 10s)
    time_limit=30,
)
def fetch_and_store_prices(self: Any) -> dict:
    """
    Task Celery sincrono che wrappa la logica asincrona.
    Celery non supporta nativamente async, quindi usiamo asyncio.run().
    """
    try:
        result = asyncio.run(_async_fetch_and_store())
        return result
    except Exception as exc:
        log.error("price_worker.failed", error=str(exc), task_id=self.request.id)
        raise self.retry(exc=exc)


async def _async_fetch_and_store() -> dict:
    from datetime import timezone

    from app.core.config import settings
    from app.core.redis import cache_set, get_redis
    from app.db.session import TimescaleSessionMaker

    start = datetime.now(timezone.utc)

    # ── 1. Fetch prezzi ───────────────────────────────────────────────────
    if settings.POLYGON_API_KEY:
        try:
            prices = await _fetch_polygon_snapshot()
            source = "polygon"
        except Exception as e:
            log.warning("price_worker.polygon_fallback", error=str(e))
            prices = _mock_tick()
            source = "mock_fallback"
    else:
        prices = _mock_tick()
        source = "mock"

    now = datetime.now(timezone.utc)

    # ── 2. Salva tick su TimescaleDB ──────────────────────────────────────
    from sqlalchemy import insert
    from app.models.market import PriceTick

    tick_rows = [
        {
            "time": now,
            "asset": asset,
            "price": price,
            "source": source,
        }
        for asset, price in prices.items()
    ]

    async with TimescaleSessionMaker() as session:
        # INSERT ... ON CONFLICT DO NOTHING per idempotenza
        await session.execute(
            insert(PriceTick)
            .values(tick_rows)
            .on_conflict_do_nothing(index_elements=["time", "asset"])
        )
        await session.commit()

    # ── 3. Aggiorna cache Redis ───────────────────────────────────────────
    await cache_set("live:prices", prices, ttl=30)

    # ── 4. Pubblica su canale WS broadcast ────────────────────────────────
    import json
    redis = get_redis()

    # Calcola variazioni % vs tick precedente (se disponibile in cache)
    prev_prices = await _get_prev_prices()
    changes = {}
    if prev_prices:
        for asset, price in prices.items():
            prev = prev_prices.get(asset)
            if prev and prev > 0:
                changes[asset] = round((price - prev) / prev * 100, 3)

    # Salva prezzi correnti come "precedente" per prossima iterazione
    await cache_set("live:prices:prev", prices, ttl=60)

    message = json.dumps({
        "type": "price_update",
        "ts": now.isoformat(),
        "prices": prices,
        "changes": changes,
    })
    await redis.publish("prices:broadcast", message)

    # ── 5. XADD su Redis Stream per il Whale Engine ───────────────────────
    # Il whale engine legge da questo stream via XREADGROUP (at-least-once).
    # Manteniamo max 10k entries nel stream (MAXLEN ~= 10 min di tick a 10s).
    stream_payload = {
        "type":    "price_update",
        "ts":      now.isoformat(),
        "prices":  json.dumps(prices),
        "changes": json.dumps(changes),
    }
    await redis.xadd("stream:prices", stream_payload, maxlen=10_000, approximate=True)

    elapsed = (datetime.now(timezone.utc) - start).total_seconds()
    log.info(
        "price_worker.completed",
        source=source,
        assets=len(prices),
        elapsed_ms=round(elapsed * 1000),
    )
    return {"assets": len(prices), "source": source, "elapsed_ms": round(elapsed * 1000)}


async def _get_prev_prices() -> dict[str, float] | None:
    from app.core.redis import cache_get
    return await cache_get("live:prices:prev")


# ── Stub tasks (implementati nei prossimi moduli) ──────────────────────────────

@celery_app.task(name="app.workers.price_worker.fetch_and_store_vessels")
def fetch_and_store_vessels() -> dict:
    """Placeholder — implementato in vessel_worker.py."""
    log.info("vessel_worker.stub_called")
    return {"status": "not_implemented_yet"}


@celery_app.task(name="app.workers.price_worker.fetch_and_store_macro")
def fetch_and_store_macro() -> dict:
    """Placeholder — implementato in macro_worker.py."""
    log.info("macro_worker.stub_called")
    return {"status": "not_implemented_yet"}


# Alias pubblico per i test
def _check_condition_alias(condition: str, price: float, threshold: float) -> bool:
    from app.workers.alert_worker import _check_condition
    return _check_condition(condition, price, threshold)
