"""
app/workers/vessel_worker.py

Ingestion posizioni navi da MarineTraffic API.
Aggiorna vessel_positions su TimescaleDB ogni 5 minuti.
Rileva automaticamente vicinanza ai chokepoint strategici.

Mock mode: se MARINE_TRAFFIC_KEY è vuoto, genera posizioni sintetiche
con moto realistico lungo le rotte commerciali principali.
"""

import asyncio
import math
import random
from datetime import datetime, timezone
from typing import Any

import structlog
from tenacity import retry, stop_after_attempt, wait_exponential

from app.workers.celery_app import celery_app

log = structlog.get_logger(__name__)

# ── Chokepoint definitions (lat, lon, radius_deg) ─────────────────────────────

CHOKEPOINTS: dict[str, tuple[float, float, float]] = {
    "hormuz":          (26.5,  56.5, 1.5),
    "suez":            (30.5,  32.3, 1.0),
    "malacca":         (1.2,  103.8, 1.2),
    "panama":          (9.1,  -79.9, 0.8),
    "cape_good_hope":  (-34.4, 18.5, 2.0),
    "gibraltar":       (35.9,  -5.4, 0.8),
    "bab_el_mandeb":   (12.5,  43.5, 1.0),
}

# ── Mock vessel fleet ──────────────────────────────────────────────────────────

_MOCK_VESSELS = [
    # VLCC Oil tankers
    {"mmsi": "477123456", "name": "Seaways Atlas",    "type": "oil_tanker",
     "commodity": "oil",    "dwt": 320000, "flag": "MHL",
     "lat": 20.0, "lon": 72.0,  "dlat":  0.012, "dlon": -0.018,
     "dest": "Rotterdam",  "cargo": "2.0M bbl Brent"},
    {"mmsi": "477234567", "name": "Nordic Hawk",      "type": "oil_tanker",
     "commodity": "oil",    "dwt": 260000, "flag": "NOR",
     "lat": 42.0, "lon": -38.0, "dlat": -0.008, "dlon":  0.022,
     "dest": "Rotterdam",  "cargo": "1.2M bbl WTI"},
    {"mmsi": "477345678", "name": "Pacific Winner",   "type": "oil_tanker",
     "commodity": "oil",    "dwt": 295000, "flag": "PAN",
     "lat":  8.0, "lon":  88.0, "dlat":  0.005, "dlon":  0.015,
     "dest": "Singapore",  "cargo": "1.9M bbl"},
    {"mmsi": "477456789", "name": "NITC Endeavor",    "type": "oil_tanker",
     "commodity": "oil",    "dwt": 310000, "flag": "IRN",
     "lat": 26.5, "lon":  57.0, "dlat":  0.001, "dlon":  0.001,
     "dest": "BLOCKED",    "cargo": "1.5M bbl"},
    {"mmsi": "477567890", "name": "Suez Carrier",     "type": "oil_tanker",
     "commodity": "oil",    "dwt": 280000, "flag": "SGP",
     "lat": 18.0, "lon":  40.0, "dlat": -0.010, "dlon": -0.012,
     "dest": "Suez->Med",  "cargo": "1.8M bbl"},
    # LNG tankers
    {"mmsi": "566111111", "name": "Arctic Spirit",    "type": "lng_tanker",
     "commodity": "lng",    "dwt": 90000,  "flag": "BHS",
     "lat": 55.0, "lon": -10.0, "dlat": -0.005, "dlon":  0.018,
     "dest": "Rotterdam",  "cargo": "LNG 150k m3"},
    # Gold cargo
    {"mmsi": "636012345", "name": "MV Safehaven",     "type": "gold_cargo",
     "commodity": "gold",   "dwt": 22000,  "flag": "LBR",
     "lat": 15.0, "lon":  68.0, "dlat":  0.015, "dlon":  0.020,
     "dest": "Hong Kong",  "cargo": "8t Au bars"},
    # Silver / bulk
    {"mmsi": "248123456", "name": "MS Silverline",    "type": "bulk_carrier",
     "commodity": "silver", "dwt": 22000,  "flag": "MLT",
     "lat": 38.0, "lon": -30.0, "dlat":  0.010, "dlon":  0.015,
     "dest": "Rotterdam",  "cargo": "420t Ag bullion"},
    {"mmsi": "345678901", "name": "Fresnillo Export", "type": "bulk_carrier",
     "commodity": "silver", "dwt": 18000,  "flag": "PAN",
     "lat": 18.0, "lon": -88.0, "dlat": -0.005, "dlon": -0.008,
     "dest": "Hamburg",    "cargo": "280t Ag conc."},
]

# Stato mutabile per il random walk
_vessel_state = {v["mmsi"]: {"lat": v["lat"], "lon": v["lon"]} for v in _MOCK_VESSELS}


def _nearest_chokepoint(lat: float, lon: float) -> str | None:
    """Restituisce il nome del chokepoint se la nave è nel raggio, altrimenti None."""
    for name, (clat, clon, radius) in CHOKEPOINTS.items():
        dist = math.sqrt((lat - clat) ** 2 + (lon - clon) ** 2)
        if dist <= radius:
            return name
    return None


def _mock_vessel_positions() -> list[dict]:
    """Aggiorna posizioni con random walk e restituisce lista dicts."""
    now = datetime.now(timezone.utc)
    rows = []

    for v in _MOCK_VESSELS:
        mmsi = v["mmsi"]
        state = _vessel_state[mmsi]

        # Trova il vettore base
        base_dlat = v["dlat"]
        base_dlon = v["dlon"]

        # NITC Endeavor è bloccata vicino a Hormuz — quasi immobile
        if mmsi == "477456789":
            state["lat"] += random.gauss(0, 0.001)
            state["lon"] += random.gauss(0, 0.001)
        else:
            state["lat"] += base_dlat * random.uniform(0.7, 1.3)
            state["lon"] += base_dlon * random.uniform(0.7, 1.3)

        # Clamp latitudine
        state["lat"] = max(-80.0, min(80.0, state["lat"]))
        # Wrap longitudine
        if state["lon"] > 180:
            state["lon"] -= 360
        if state["lon"] < -180:
            state["lon"] += 360

        lat, lon = state["lat"], state["lon"]
        chokepoint = _nearest_chokepoint(lat, lon)
        is_at_risk = (
            chokepoint in ("hormuz", "suez", "bab_el_mandeb")
            or v["dest"] == "BLOCKED"
        )

        speed = 0.2 if v["dest"] == "BLOCKED" else random.uniform(10.0, 16.0)

        rows.append({
            "time":              now,
            "mmsi":              mmsi,
            "vessel_name":       v["name"],
            "vessel_type":       v["type"],
            "flag":              v["flag"],
            "imo":               f"IMO{mmsi[:7]}",
            "latitude":          round(lat, 5),
            "longitude":         round(lon, 5),
            "speed":             round(speed, 1),
            "heading":           round(random.uniform(0, 360), 1),
            "nav_status":        "moored" if v["dest"] == "BLOCKED" else "underway",
            "destination":       v["dest"],
            "cargo_type":        v["cargo"],
            "commodity":         v["commodity"],
            "deadweight_tonnage": v["dwt"],
            "near_chokepoint":   chokepoint,
            "is_at_risk":        is_at_risk,
        })

    return rows


# ── MarineTraffic API fetch ───────────────────────────────────────────────────

@retry(stop=stop_after_attempt(3), wait=wait_exponential(min=5, max=30), reraise=True)
async def _fetch_marine_traffic() -> list[dict]:
    """
    Fetch posizioni da MarineTraffic Extended API v2.
    Endpoint: /getVesselsInArea con filtro per vessel_type VLCC/tanker/bulk.
    """
    import httpx
    from app.core.config import settings

    # Aree di interesse: Golfo Persico, Mar Rosso, Atlantico, Pacifico
    areas = [
        {"MINLAT": 20, "MAXLAT": 30, "MINLON": 50, "MAXLON": 65},  # Golfo Persico
        {"MINLAT": 10, "MAXLAT": 32, "MINLON": 30, "MAXLON": 45},  # Mar Rosso
        {"MINLAT": -40, "MAXLAT": 60, "MINLON": -30, "MAXLON": 20}, # Atlantico
    ]

    all_vessels = []
    async with httpx.AsyncClient(timeout=15.0) as client:
        for area in areas:
            params = {
                **area,
                "VESSEL_TYPE": "6,7,8,9",  # tanker + bulk carrier
                "PROTOCOL": "json",
                "v": "2",
            }
            resp = await client.get(
                "https://services.marinetraffic.com/api/getVesselsInArea/"
                f"{settings.MARINE_TRAFFIC_KEY}",
                params=params,
            )
            resp.raise_for_status()
            vessels = resp.json()
            all_vessels.extend(vessels)

    return _normalize_marine_traffic(all_vessels)


def _normalize_marine_traffic(raw: list[dict]) -> list[dict]:
    """Normalizza la risposta MarineTraffic nel formato interno."""
    now = datetime.now(timezone.utc)
    rows = []
    for v in raw:
        lat = float(v.get("LAT", 0))
        lon = float(v.get("LON", 0))
        rows.append({
            "time":         now,
            "mmsi":         str(v.get("MMSI", "")),
            "vessel_name":  v.get("SHIPNAME"),
            "vessel_type":  _map_vessel_type(int(v.get("SHIPTYPE", 0))),
            "flag":         v.get("FLAG"),
            "latitude":     lat,
            "longitude":    lon,
            "speed":        float(v.get("SPEED", 0)) / 10,
            "heading":      float(v.get("HEADING", 0)),
            "nav_status":   v.get("STATUS"),
            "destination":  v.get("DESTINATION"),
            "commodity":    _infer_commodity(int(v.get("SHIPTYPE", 0))),
            "deadweight_tonnage": int(v.get("DWT", 0)),
            "near_chokepoint": _nearest_chokepoint(lat, lon),
            "is_at_risk":   _nearest_chokepoint(lat, lon) in ("hormuz", "suez", "bab_el_mandeb"),
        })
    return rows


def _map_vessel_type(code: int) -> str:
    if code in range(80, 90):
        return "oil_tanker"
    if code in (70, 71, 72, 73, 74, 75):
        return "bulk_carrier"
    if code == 71:
        return "lng_tanker"
    return "other"


def _infer_commodity(ship_type: int) -> str | None:
    if ship_type in range(80, 90):
        return "oil"
    if ship_type in (70, 71, 72):
        return "grain"
    return None


# ── Celery task ───────────────────────────────────────────────────────────────

@celery_app.task(
    name="app.workers.vessel_worker.fetch_and_store_vessels",
    bind=True,
    max_retries=3,
    soft_time_limit=60,
    time_limit=90,
)
def fetch_and_store_vessels(self: Any) -> dict:
    try:
        return asyncio.run(_async_fetch_vessels())
    except Exception as exc:
        log.error("vessel_worker.failed", error=str(exc))
        raise self.retry(exc=exc)


async def _async_fetch_vessels() -> dict:
    from app.core.config import settings
    from app.db.session import TimescaleSessionMaker
    from sqlalchemy import insert
    from app.models.market import VesselPosition

    if settings.MARINE_TRAFFIC_KEY:
        try:
            rows = await _fetch_marine_traffic()
            source = "marinetraffic"
        except Exception as e:
            log.warning("vessel_worker.api_fallback", error=str(e))
            rows = _mock_vessel_positions()
            source = "mock_fallback"
    else:
        rows = _mock_vessel_positions()
        source = "mock"

    if not rows:
        return {"vessels": 0, "source": source}

    async with TimescaleSessionMaker() as session:
        await session.execute(
            insert(VesselPosition)
            .values(rows)
            .on_conflict_do_nothing(index_elements=["time", "mmsi"])
        )
        await session.commit()

    # Alert chokepoint via Redis pub/sub
    at_risk = [r for r in rows if r["is_at_risk"]]
    if at_risk:
        import json
        from app.core.redis import get_redis
        redis = get_redis()
        await redis.publish("whale:broadcast", json.dumps({
            "type": "chokepoint_alert",
            "vessels_at_risk": len(at_risk),
            "chokepoints": list({r["near_chokepoint"] for r in at_risk if r["near_chokepoint"]}),
            "ts": datetime.now(timezone.utc).isoformat(),
        }))

    log.info("vessel_worker.completed", vessels=len(rows), at_risk=len(at_risk), source=source)
    return {"vessels": len(rows), "at_risk": len(at_risk), "source": source}
