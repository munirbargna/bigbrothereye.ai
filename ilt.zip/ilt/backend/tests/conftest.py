"""
tests/conftest.py

Fixture condivise tra tutti i test.

Strategia:
- DB test usa SQLite in-memory (asyncio) — no Docker richiesto per i test
- Redis mockata con fakeredis
- Override delle Settings per isolare l'ambiente di test
"""

import asyncio
from collections.abc import AsyncGenerator
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import StaticPool

from app.core.config import Settings
from app.db.base import Base


# ── Settings di test ──────────────────────────────────────────────────────────

TEST_SETTINGS = Settings(
    ENVIRONMENT="development",
    SECRET_KEY="test-secret-key-must-be-32-chars!!",
    DATABASE_URL="sqlite+aiosqlite:///:memory:",
    TIMESCALE_URL="sqlite+aiosqlite:///:memory:",
    REDIS_URL="redis://localhost:6379/15",  # DB 15 = test isolation
    LOG_LEVEL="WARNING",
)


# ── In-memory SQLite engine ───────────────────────────────────────────────────

@pytest.fixture(scope="session")
def event_loop():
    """Event loop condiviso per tutta la sessione di test."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest_asyncio.fixture(scope="session")
async def test_engine():
    engine = create_async_engine(
        "sqlite+aiosqlite:///:memory:",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
        echo=False,
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield engine
    await engine.dispose()


@pytest_asyncio.fixture
async def db_session(test_engine) -> AsyncGenerator[AsyncSession, None]:
    """Sessione DB con rollback automatico dopo ogni test."""
    session_factory = async_sessionmaker(test_engine, expire_on_commit=False)
    async with session_factory() as session:
        yield session
        await session.rollback()


# ── Redis mock ────────────────────────────────────────────────────────────────

@pytest.fixture
def mock_redis():
    """Mocka Redis per evitare dipendenza da server Redis nei test."""
    redis = MagicMock()
    redis.ping = AsyncMock(return_value=True)
    redis.get = AsyncMock(return_value=None)
    redis.setex = AsyncMock(return_value=True)
    redis.set = AsyncMock(return_value=True)
    redis.delete = AsyncMock(return_value=1)
    redis.exists = AsyncMock(return_value=0)
    redis.publish = AsyncMock(return_value=1)
    redis.aclose = AsyncMock()
    return redis


# ── App con override ──────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def app(db_session, mock_redis, monkeypatch) -> FastAPI:
    """App FastAPI con DB e Redis sostituiti da mock."""
    from app import main as app_module
    from app.core import redis as redis_module
    from app.db import session as session_module

    # Override settings
    monkeypatch.setattr(app_module, "settings", TEST_SETTINGS)

    # Override Redis singleton
    redis_module._redis_client = mock_redis

    # Override DB session
    async def _get_test_db():
        yield db_session

    from app.db.session import get_app_db, get_timescale_db
    fastapi_app = app_module.create_app()
    fastapi_app.dependency_overrides[get_app_db] = _get_test_db
    fastapi_app.dependency_overrides[get_timescale_db] = _get_test_db

    yield fastapi_app
    fastapi_app.dependency_overrides.clear()


@pytest_asyncio.fixture
async def client(app) -> AsyncGenerator[AsyncClient, None]:
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as c:
        yield c


# ── Helper fixtures ───────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def registered_user(client) -> dict[str, Any]:
    """Registra e restituisce un utente di test."""
    payload = {"email": "test@ilt.dev", "password": "Test1234", "full_name": "Test User"}
    resp = await client.post("/api/v1/auth/register", json=payload)
    assert resp.status_code == 201
    return {**resp.json(), "password": payload["password"]}


@pytest_asyncio.fixture
async def auth_headers(client, registered_user) -> dict[str, str]:
    """Headers di autenticazione per un utente registrato."""
    resp = await client.post(
        "/api/v1/auth/login",
        json={"email": registered_user["email"], "password": registered_user["password"]},
    )
    assert resp.status_code == 200
    token = resp.json()["access_token"]
    return {"Authorization": f"Bearer {token}"}
