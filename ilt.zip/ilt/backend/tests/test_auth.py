"""
tests/test_auth.py

Test integrazione per gli endpoint di autenticazione.
Usa TestClient async di httpx e un DB di test in memoria.
"""

import pytest
from httpx import ASGITransport, AsyncClient

from app.main import app


@pytest.fixture
async def client():
    async with AsyncClient(
        transport=ASGITransport(app=app),
        base_url="http://test",
    ) as c:
        yield c


@pytest.fixture
def user_payload():
    return {
        "email": "test@ilt.dev",
        "password": "Secure1234",
        "full_name": "Test User",
    }


class TestRegister:
    async def test_register_success(self, client, user_payload):
        resp = await client.post("/api/v1/auth/register", json=user_payload)
        assert resp.status_code == 201
        data = resp.json()
        assert data["email"] == user_payload["email"]
        assert "hashed_password" not in data

    async def test_register_duplicate_email(self, client, user_payload):
        await client.post("/api/v1/auth/register", json=user_payload)
        resp = await client.post("/api/v1/auth/register", json=user_payload)
        assert resp.status_code == 409

    async def test_register_weak_password(self, client):
        resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "x@test.com", "password": "12345678"},
        )
        assert resp.status_code == 422

    async def test_register_invalid_email(self, client):
        resp = await client.post(
            "/api/v1/auth/register",
            json={"email": "not-an-email", "password": "Secure1234"},
        )
        assert resp.status_code == 422


class TestLogin:
    async def test_login_success(self, client, user_payload):
        await client.post("/api/v1/auth/register", json=user_payload)
        resp = await client.post(
            "/api/v1/auth/login",
            json={"email": user_payload["email"], "password": user_payload["password"]},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert "access_token" in data
        assert data["token_type"] == "bearer"
        # Cookie refresh impostato
        assert "ilt_refresh" in resp.cookies

    async def test_login_wrong_password(self, client, user_payload):
        await client.post("/api/v1/auth/register", json=user_payload)
        resp = await client.post(
            "/api/v1/auth/login",
            json={"email": user_payload["email"], "password": "wrongpassword"},
        )
        assert resp.status_code == 401

    async def test_login_unknown_email(self, client):
        resp = await client.post(
            "/api/v1/auth/login",
            json={"email": "nobody@ilt.dev", "password": "Secure1234"},
        )
        assert resp.status_code == 401


class TestMe:
    async def test_me_authenticated(self, client, user_payload):
        await client.post("/api/v1/auth/register", json=user_payload)
        login = await client.post(
            "/api/v1/auth/login",
            json={"email": user_payload["email"], "password": user_payload["password"]},
        )
        token = login.json()["access_token"]

        resp = await client.get(
            "/api/v1/auth/me",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 200
        assert resp.json()["email"] == user_payload["email"]

    async def test_me_unauthenticated(self, client):
        resp = await client.get("/api/v1/auth/me")
        assert resp.status_code == 401


class TestLogout:
    async def test_logout(self, client, user_payload):
        await client.post("/api/v1/auth/register", json=user_payload)
        login = await client.post(
            "/api/v1/auth/login",
            json={"email": user_payload["email"], "password": user_payload["password"]},
        )
        token = login.json()["access_token"]

        resp = await client.post(
            "/api/v1/auth/logout",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert resp.status_code == 204

        # Dopo logout il token è blacklistato
        me = await client.get(
            "/api/v1/auth/me",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert me.status_code == 401


class TestHealth:
    async def test_health(self, client):
        resp = await client.get("/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"
