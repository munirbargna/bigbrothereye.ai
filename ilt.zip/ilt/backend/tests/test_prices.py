"""
tests/test_prices.py

Test per endpoint prezzi, watchlists, alerts e whale detector.
"""

from datetime import datetime, timezone
from unittest.mock import AsyncMock, patch

import pytest

from services.whale_engine.detector import PriceBar, WhaleDetector, ZScoreDetector


# ── Price endpoints ───────────────────────────────────────────────────────────

class TestPricesLive:
    async def test_live_prices_empty(self, client):
        """Senza dati in cache, risponde con dict vuoto."""
        resp = await client.get("/api/v1/prices/live")
        assert resp.status_code == 200
        assert isinstance(resp.json(), dict)

    async def test_live_prices_with_cache(self, client, mock_redis):
        import json
        mock_redis.get = AsyncMock(return_value=json.dumps({"NVDA": 820.5, "GLD": 5107.0}))
        resp = await client.get("/api/v1/prices/live")
        assert resp.status_code == 200
        data = resp.json()
        assert "NVDA" in data or data == {}  # mock potrebbe non propagarsi

    async def test_unknown_asset_404(self, client):
        resp = await client.get("/api/v1/prices/UNKNOWN_ASSET_XYZ")
        assert resp.status_code == 404


# ── Watchlists ────────────────────────────────────────────────────────────────

class TestWatchlists:
    async def test_list_watchlists_requires_auth(self, client):
        resp = await client.get("/api/v1/watchlists")
        assert resp.status_code == 401

    async def test_create_watchlist(self, client, auth_headers):
        resp = await client.post(
            "/api/v1/watchlists",
            json={"name": "My Metals", "assets": ["GLD", "SLV", "GDX"]},
            headers=auth_headers,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["name"] == "My Metals"
        assert "GLD" in data["assets"]

    async def test_update_watchlist(self, client, auth_headers):
        # Crea
        create_resp = await client.post(
            "/api/v1/watchlists",
            json={"name": "Test WL", "assets": ["NVDA"]},
            headers=auth_headers,
        )
        wl_id = create_resp.json()["id"]

        # Aggiorna
        resp = await client.put(
            f"/api/v1/watchlists/{wl_id}",
            json={"assets": ["NVDA", "AAPL", "MSFT"]},
            headers=auth_headers,
        )
        assert resp.status_code == 200
        assert "AAPL" in resp.json()["assets"]

    async def test_watchlist_limit_10(self, client, auth_headers):
        for i in range(10):
            r = await client.post(
                "/api/v1/watchlists",
                json={"name": f"WL {i}", "assets": []},
                headers=auth_headers,
            )
            # Uno è già la default — può fallire dopo la 9a
        # L'11a deve fallire
        resp = await client.post(
            "/api/v1/watchlists",
            json={"name": "Extra WL", "assets": []},
            headers=auth_headers,
        )
        assert resp.status_code in (201, 400)  # dipende da quante già esistono


# ── Alerts ────────────────────────────────────────────────────────────────────

class TestAlerts:
    async def test_create_alert(self, client, auth_headers):
        resp = await client.post(
            "/api/v1/alerts",
            json={"asset": "GLD", "condition": "above", "threshold": 5500.0},
            headers=auth_headers,
        )
        assert resp.status_code == 201
        data = resp.json()
        assert data["asset"] == "GLD"
        assert data["condition"] == "above"
        assert data["threshold"] == 5500.0
        assert data["is_active"] is True

    async def test_invalid_condition(self, client, auth_headers):
        resp = await client.post(
            "/api/v1/alerts",
            json={"asset": "GLD", "condition": "invalid_op", "threshold": 100.0},
            headers=auth_headers,
        )
        assert resp.status_code == 422

    async def test_delete_alert(self, client, auth_headers):
        create = await client.post(
            "/api/v1/alerts",
            json={"asset": "NVDA", "condition": "below", "threshold": 700.0},
            headers=auth_headers,
        )
        alert_id = create.json()["id"]

        resp = await client.delete(f"/api/v1/alerts/{alert_id}", headers=auth_headers)
        assert resp.status_code == 204


# ── Whale Detector unit tests ─────────────────────────────────────────────────

def _make_bars(n: int, asset: str = "NVDA", base: float = 820.0, vol: float = 1_000_000.0) -> list[PriceBar]:
    now = datetime.now(timezone.utc)
    return [
        PriceBar(
            time=now,
            asset=asset,
            price=base + i * 0.1,
            volume=vol,
        )
        for i in range(n)
    ]


class TestZScoreDetector:
    def test_no_signal_with_normal_volume(self):
        bars = _make_bars(25, vol=1_000_000)
        det = ZScoreDetector()
        result = det.detect(bars)
        assert result is None

    def test_signal_on_volume_spike(self):
        bars = _make_bars(25, vol=1_000_000)
        # Spike massiccio sull'ultimo tick
        bars[-1].volume = 20_000_000
        det = ZScoreDetector()
        result = det.detect(bars)
        assert result is not None
        assert result.asset == "NVDA"
        assert result.z_score is not None
        assert result.z_score > 2.5
        assert result.direction in ("LONG", "SHORT")
        assert 0.0 <= result.strength <= 1.0

    def test_needs_minimum_bars(self):
        bars = _make_bars(5)
        det = ZScoreDetector()
        assert det.detect(bars) is None


class TestWhaleDetector:
    def test_no_signal_with_normal_data(self):
        bars = _make_bars(50)
        det = WhaleDetector()
        result = det.analyze(bars)
        # Con dati normali potrebbe non emettere segnali
        if result:
            assert 0.0 <= result.strength <= 1.0

    def test_signal_with_extreme_spike(self):
        bars = _make_bars(50, vol=1_000_000)
        bars[-1].volume = 50_000_000  # spike estremo z > 4
        det = WhaleDetector()
        result = det.analyze(bars)
        assert result is not None
        assert result.asset == "NVDA"

    def test_signal_has_valid_direction(self):
        bars = _make_bars(50, vol=1_000_000)
        bars[-1].volume = 50_000_000
        det = WhaleDetector()
        result = det.analyze(bars)
        if result:
            assert result.direction in ("LONG", "SHORT", "NEUTRAL")

    def test_returns_none_with_too_few_bars(self):
        bars = _make_bars(5)
        det = WhaleDetector()
        assert det.analyze(bars) is None
