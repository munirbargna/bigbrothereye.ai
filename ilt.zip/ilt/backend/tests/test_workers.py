"""
tests/test_workers.py

Test per i worker Celery in modalità unit (niente broker reale).
Verifica la logica di ingestion, mock fallback e alert evaluation.
"""

import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.workers.price_worker import _mock_tick, _check_condition_alias
from app.workers.alert_worker import _check_condition


# ── Mock tick ─────────────────────────────────────────────────────────────────

class TestMockTick:
    def test_returns_all_assets(self):
        prices = _mock_tick()
        expected = {"NVDA", "AAPL", "MSFT", "TSLA", "META", "AMZN",
                    "SPY", "QQQ", "GLD", "SLV", "GDX", "OIH", "BRENT", "WTI"}
        assert set(prices.keys()) == expected

    def test_prices_are_positive(self):
        prices = _mock_tick()
        assert all(v > 0 for v in prices.values())

    def test_gold_above_floor(self):
        for _ in range(20):
            prices = _mock_tick()
            assert prices["GLD"] >= 4800, "Gold è sceso sotto il floor"

    def test_prices_change_between_calls(self):
        p1 = _mock_tick()
        p2 = _mock_tick()
        # Con volatilità non zero, almeno un prezzo deve cambiare
        assert any(p1[k] != p2[k] for k in p1), "I prezzi non cambiano tra tick"

    def test_prices_are_rounded(self):
        prices = _mock_tick()
        for asset, price in prices.items():
            assert price == round(price, 4), f"{asset}: troppe cifre decimali"


# ── Alert condition evaluation ────────────────────────────────────────────────

class TestAlertCondition:
    def test_above_triggered(self):
        assert _check_condition("above", 5200.0, 5100.0) is True

    def test_above_not_triggered(self):
        assert _check_condition("above", 5000.0, 5100.0) is False

    def test_above_at_threshold(self):
        assert _check_condition("above", 5100.0, 5100.0) is True  # >= non >

    def test_below_triggered(self):
        assert _check_condition("below", 4900.0, 5000.0) is True

    def test_below_not_triggered(self):
        assert _check_condition("below", 5100.0, 5000.0) is False

    def test_below_at_threshold(self):
        assert _check_condition("below", 5000.0, 5000.0) is True

    def test_unknown_condition_returns_false(self):
        assert _check_condition("invalid_op", 100.0, 90.0) is False

    def test_pct_change(self):
        # condition pct_change usa threshold come soglia assoluta
        assert _check_condition("pct_change", 10.0, 5.0) is True
        assert _check_condition("pct_change", 3.0, 5.0) is False


# ── Vessel worker mock ────────────────────────────────────────────────────────

class TestVesselMock:
    def test_mock_vessels_have_required_fields(self):
        from app.workers.vessel_worker import _mock_vessel_positions
        vessels = _mock_vessel_positions()
        assert len(vessels) > 0
        for v in vessels:
            assert "mmsi" in v
            assert "latitude" in v
            assert "longitude" in v
            assert "commodity" in v
            assert isinstance(v["is_at_risk"], bool)

    def test_blocked_vessel_is_at_risk(self):
        from app.workers.vessel_worker import _mock_vessel_positions
        vessels = _mock_vessel_positions()
        blocked = [v for v in vessels if v.get("nav_status") == "moored"
                   and v.get("vessel_name") == "NITC Endeavor"]
        if blocked:
            assert blocked[0]["is_at_risk"] is True

    def test_chokepoint_detection(self):
        from app.workers.vessel_worker import _nearest_chokepoint
        # Hormuz: 26.5N 56.5E
        result = _nearest_chokepoint(26.5, 56.5)
        assert result == "hormuz"

    def test_no_chokepoint_in_open_ocean(self):
        from app.workers.vessel_worker import _nearest_chokepoint
        # Pacifico centrale: 0N 180E
        result = _nearest_chokepoint(0.0, 180.0)
        assert result is None


# ── Macro mock ────────────────────────────────────────────────────────────────

class TestMacroMock:
    def test_mock_returns_all_series(self):
        from app.workers.macro_worker import _mock_macro_data
        rows = _mock_macro_data()
        series_ids = {r["series_id"] for r in rows}
        assert "FRED.DGS10" in series_ids
        assert "FRED.VIXCLS" in series_ids
        assert "EIA.PET.RWTC.D" in series_ids

    def test_mock_values_are_realistic(self):
        from app.workers.macro_worker import _mock_macro_data
        rows = _mock_macro_data()
        by_id = {r["series_id"]: r["value"] for r in rows}
        # Fed funds: tra 0 e 10%
        assert 0 < by_id["FRED.FEDFUNDS"] < 10
        # VIX: tra 10 e 80
        assert 10 < by_id["FRED.VIXCLS"] < 80
        # WTI: tra 50 e 200 $/bbl
        assert 50 < by_id["EIA.PET.RWTC.D"] < 200
