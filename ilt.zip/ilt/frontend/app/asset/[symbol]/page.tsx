/**
 * app/asset/[symbol]/page.tsx
 * Pagina dettaglio asset: chart OHLCV + whale signals + ticks recenti.
 */

"use client";

import { useParams } from "next/navigation";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, TrendingUp, TrendingDown, Zap } from "lucide-react";
import Link from "next/link";
import { PriceChart }    from "@/components/PriceChart";
import { useLivePrices } from "@/hooks/useLivePrices";
import { pricesApi }     from "@/lib/api";
import { clsx }          from "clsx";

const TIMEFRAMES = ["1m", "1h", "1d"] as const;
type TF = typeof TIMEFRAMES[number];

export default function AssetPage() {
  const params = useParams();
  const symbol = (params.symbol as string).toUpperCase();
  const { prices, changes } = useLivePrices();

  const [tf, setTf] = useState<TF>("1h");

  const { data: bars = [], isLoading: barsLoading } = useQuery({
    queryKey: ["ohlcv", symbol, tf],
    queryFn:  () => pricesApi.ohlcv(symbol, tf, 200),
    refetchInterval: tf === "1m" ? 30_000 : 60_000,
  });

  const { data: signals = [] } = useQuery({
    queryKey: ["whale-signals", symbol],
    queryFn:  () => pricesApi.whaleSignals(7, symbol, 0.4),
    refetchInterval: 30_000,
  });

  const price     = prices[symbol];
  const changePct = changes[symbol];
  const isUp      = (changePct ?? 0) >= 0;

  return (
    <div className="min-h-screen bg-[#060a0d]">

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-[#1a2b35] bg-[#060a0d]/95 backdrop-blur">
        <div className="max-w-[1400px] mx-auto px-5 h-14 flex items-center gap-4">
          <Link href="/" className="text-slate-500 hover:text-white transition-colors">
            <ArrowLeft size={18} />
          </Link>
          <div className="flex items-baseline gap-3">
            <h1 className="font-sans font-bold text-xl text-white">{symbol}</h1>
            {price && (
              <>
                <span className="font-sans font-bold text-lg">
                  ${price.toLocaleString("en-US", { minimumFractionDigits: 2 })}
                </span>
                <span className={clsx("text-sm", isUp ? "text-emerald-400" : "text-red-400")}>
                  {isUp ? "+" : ""}{changePct?.toFixed(2) ?? "0.00"}%
                  {isUp ? <TrendingUp size={12} className="inline ml-1" /> : <TrendingDown size={12} className="inline ml-1" />}
                </span>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto px-5 py-6 space-y-5">

        {/* Chart con selector timeframe */}
        <div className="card overflow-hidden">
          <div className="card-header flex items-center justify-between">
            <span className="flex items-center gap-2">
              <TrendingUp size={10} /> {symbol} — OHLCV
            </span>
            <div className="flex gap-1">
              {TIMEFRAMES.map(t => (
                <button
                  key={t}
                  onClick={() => setTf(t)}
                  className={clsx(
                    "px-2.5 py-1 rounded text-[10px] font-bold uppercase transition-colors",
                    tf === t
                      ? "bg-emerald-400 text-black"
                      : "text-slate-500 hover:text-white"
                  )}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div className="p-4">
            {barsLoading ? (
              <div className="h-80 flex items-center justify-center text-slate-600 text-sm">
                Caricamento candele…
              </div>
            ) : (
              <PriceChart bars={bars} height={320} />
            )}
          </div>
        </div>

        {/* Whale signals */}
        <div className="card overflow-hidden">
          <div className="card-header flex items-center justify-between">
            <span className="flex items-center gap-2"><Zap size={10} /> Segnali Whale — ultimi 7 giorni</span>
            <span className="text-emerald-400">{signals.length}</span>
          </div>

          {signals.length === 0 ? (
            <div className="p-8 text-center text-slate-600 text-sm">
              Nessun segnale whale negli ultimi 7 giorni
            </div>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-[#1a2b35]">
                  {["Ora", "Direzione", "Forza", "Tipo", "Z-Score", "Nozionale"].map(h => (
                    <th key={h} className="px-4 py-2 text-left text-[9px] tracking-widest text-slate-600 uppercase">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a2b35]">
                {signals.map(s => (
                  <tr key={s.signal_id} className="hover:bg-white/[0.02] transition-colors">
                    <td className="px-4 py-2.5 text-slate-500">
                      {new Date(s.time).toLocaleString("it-IT", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    </td>
                    <td className="px-4 py-2.5">
                      <span className={clsx(
                        "px-1.5 py-0.5 rounded text-[10px] font-bold",
                        s.direction === "LONG"
                          ? "bg-emerald-900/50 text-emerald-400"
                          : "bg-red-900/50 text-red-400"
                      )}>
                        {s.direction}
                      </span>
                    </td>
                    <td className="px-4 py-2.5">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className={clsx("h-full rounded-full", s.direction === "LONG" ? "bg-emerald-400" : "bg-red-400")}
                            style={{ width: `${s.strength * 100}%` }}
                          />
                        </div>
                        <span className="text-white">{(s.strength * 100).toFixed(0)}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-2.5 text-slate-400 font-mono">{s.signal_type}</td>
                    <td className="px-4 py-2.5 text-slate-400">
                      {s.z_score != null ? s.z_score.toFixed(2) : "—"}
                    </td>
                    <td className="px-4 py-2.5 text-slate-400">
                      {s.notional_usd != null
                        ? `$${(s.notional_usd / 1_000_000).toFixed(1)}M`
                        : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

      </main>
    </div>
  );
}

// useState import mancante — Next.js 14 lo richiede esplicito in client components
import { useState } from "react";
