import type { Metadata } from "next";
import { Space_Mono, Syne } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";
import { Sidebar }   from "@/components/Sidebar";
import { MacroBar }  from "@/components/MacroBar";

const spaceMono = Space_Mono({
  subsets: ["latin"], weight: ["400", "700"], variable: "--font-mono",
});
const syne = Syne({
  subsets: ["latin"], weight: ["400", "600", "700", "800"], variable: "--font-sans",
});

export const metadata: Metadata = {
  title: "ILT Market Intelligence",
  description: "Real-time market intelligence: prices, whale signals, vessel tracking",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="it" className="dark">
      <body className={`${spaceMono.variable} ${syne.variable} bg-[#060a0d] text-slate-300 font-mono antialiased`}>
        <Providers>
          <div className="flex h-screen">
            {/* Sidebar */}
            <Sidebar />

            {/* Main */}
            <div className="flex-1 ml-56 flex flex-col min-h-screen overflow-hidden">
              <MacroBar />
              <main className="flex-1 overflow-y-auto px-5 py-5">
                {children}
              </main>
            </div>
          </div>
        </Providers>
      </body>
    </html>
  );
}
