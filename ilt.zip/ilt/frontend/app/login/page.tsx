/**
 * app/login/page.tsx
 * Pagina di login con redirect automatico se già autenticato.
 */

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, LogIn } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function LoginPage() {
  const router    = useRouter();
  const { login, loading, error, clearError } = useAuth();

  const [email,    setEmail]    = useState("");
  const [password, setPassword] = useState("");
  const [showPwd,  setShowPwd]  = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    try {
      await login(email, password);
      router.replace("/");
    } catch {
      // errore già in store
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#060a0d] px-4">
      <div className="w-full max-w-sm">

        {/* Logo */}
        <div className="flex items-center gap-2 mb-8 justify-center">
          <div className="w-8 h-8 rounded bg-emerald-400 flex items-center justify-center text-black text-sm font-bold font-sans">
            ILT
          </div>
          <span className="font-sans font-bold text-xl">
            <span className="text-emerald-400">ILT</span> Market Intelligence
          </span>
        </div>

        {/* Card */}
        <div className="card p-6">
          <h1 className="font-sans font-bold text-lg text-white mb-6">Accedi</h1>

          {error && (
            <div className="mb-4 px-3 py-2 rounded bg-red-950/50 border border-red-800/60 text-red-400 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[10px] tracking-widest text-slate-500 uppercase mb-1.5">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
                autoComplete="email"
                className="w-full bg-[#060a0d] border border-[#1a2b35] rounded px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-emerald-600 transition-colors"
                placeholder="you@example.com"
              />
            </div>

            <div>
              <label className="block text-[10px] tracking-widest text-slate-500 uppercase mb-1.5">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPwd ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                  autoComplete="current-password"
                  className="w-full bg-[#060a0d] border border-[#1a2b35] rounded px-3 py-2 pr-10 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-emerald-600 transition-colors"
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPwd(v => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                >
                  {showPwd ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-black font-sans font-bold py-2.5 rounded transition-colors text-sm"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
              ) : (
                <LogIn size={15} />
              )}
              {loading ? "Accesso in corso…" : "Accedi"}
            </button>
          </form>

          <p className="mt-4 text-center text-xs text-slate-600">
            Demo: <span className="text-slate-400">demo@ilt.dev</span> /{" "}
            <span className="text-slate-400">Demo1234</span>
          </p>
        </div>
      </div>
    </div>
  );
}
