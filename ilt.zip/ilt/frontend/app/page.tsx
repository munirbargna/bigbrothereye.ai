/**
 * app/page.tsx
 * Dashboard principale — Overview live.
 */

"use client";

import { useQuery } from "@tanstack/react-query";
import { Activity, TrendingUp, Ship, Zap } from "lucide-react";
import { PriceBoard }        from "@/components/PriceBoard";
import { WhaleAlertFeed }    from "@/components/WhaleAlertFeed";
import { PriceChart }        from "@/components/PriceChart";
import { ConnectionStatus }  from "@/components/ConnectionStatus";
import { useLivePrices }     from "@/hooks/useLivePrices";
import { pricesApi, macroApi } from "@/lib/api";

export default function DashboardPage() {
  const { prices, changes, whaleAlerts, status, lastUpdate } = useLivePrices();

  const { data: spyBars = [] } = useQuery({
    queryKey: ["ohlcv", "SPY", "1h"],
    queryFn: () => pricesApi.ohlcv("SPY", "1h", 96),
    refetchInterval: 60_000,
  });

  const { data: gldBars = [] } = useQuery({
    queryKey: ["ohlcv", "GLD", "1h"],
    queryFn: () => pricesApi.ohlcv("GLD", "1h", 96),
    refetchInterval: 60_000,
  });

  const { data: macro } = useQuery({
    queryKey: ["macro"],
    queryFn:  macroApi.latest,
    refetchInterval: 300_000,
  });

  const { data: vessels = [] } = useQuery({
    queryKey: ["vessels"],
    queryFn:  () => pricesApi.vessels(),
    refetchInterval: 300_000,
  });

  const atRisk = vessels.filter(v => v.is_at_risk).length;

  return (
    <div className="min-h-screen" style={{ background: "var(--bg)" }}>

      {/* ── Header ── */}
      <header className="sticky top-0 z-50 border-b border-[#1a2b35] bg-[#060a0d]/95 backdrop-blur">
        <div className="max-w-[1400px] mx-auto px-5 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded bg-emerald-400 flex items-center justify-center text-black text-[11px] font-bold">
              ILT
            </div>
            <span className="font-sans font-bold text-lg">
              <span className="text-emerald-400">ILT</span> Market Intelligence
            </span>
          </div>
          <ConnectionStatus status={status} lastUpdate={lastUpdate} />
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto px-5 py-6 space-y-5">

        {/* ── Macro KPI strip ── */}
        {macro && (
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-[11px]">
            {[
              { label: "Fed Funds", value: macro["FRED.FEDFUNDS"]?.toFixed(2) + "%", color: "text-amber-400" },
              { label: "US 10Y",    value: macro["FRED.DGS10"]?.toFixed(2) + "%",    color: "text-blue-400" },
              { label: "VIX",       value: macro["FRED.VIXCLS"]?.toFixed(2),          color: macro["FRED.VIXCLS"] > 25 ? "text-red-400" : "text-emerald-400" },
              { label: "DXY",       value: macro["FRED.DTWEXBGS"]?.toFixed(2),        color: "text-slate-300" },
              { label: "WTI Spot",  value: "$" + macro["EIA.PET.RWTC.D"]?.toFixed(2), color: "text-orange-400" },
            ].map(({ label, value, color }) => (
              <div key={label} className="card px-4 py-3">
                <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">{label}</div>
                <div className={`font-sans font-bold text-lg ${color}`}>{value ?? "—"}</div>
              </div>
            ))}
          </div>
        )}

        {/* ── Price board ── */}
        <section>
          <h2 className="text-[10px] text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Activity size={12} /> Prezzi live
          </h2>
          <PriceBoard prices={prices} changes={changes} />
        </section>

        {/* ── Charts + Whale feed ── */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">

          {/* SPY chart */}
          <div className="lg:col-span-1 card overflow-hidden">
            <div className="card-header flex items-center gap-2">
              <TrendingUp size={10} /> SPY — 1H candele
            </div>
            <div className="p-3">
              <PriceChart bars={spyBars} height={220} />
            </div>
          </div>

          {/* GLD chart */}
          <div className="lg:col-span-1 card overflow-hidden">
            <div className="card-header flex items-center gap-2">
              <TrendingUp size={10} /> GLD — 1H candele
            </div>
            <div className="p-3">
              <PriceChart bars={gldBars} height={220} />
            </div>
          </div>

          {/* Whale feed */}
          <div className="lg:col-span-1 card overflow-hidden">
            <div className="card-header flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Zap size={10} /> Whale Signals
              </span>
              <span className="text-emerald-400">{whaleAlerts.length}</span>
            </div>
            <WhaleAlertFeed alerts={whaleAlerts} />
          </div>
        </div>

        {/* ── Vessel risk bar ── */}
        {vessels.length > 0 && (
          <div className={`card px-4 py-3 flex items-center gap-4 text-sm ${atRisk > 0 ? "border-red-800/60" : ""}`}>
            <Ship size={16} className={atRisk > 0 ? "text-red-400" : "text-slate-500"} />
            <div>
              <span className="text-white font-semibold">{vessels.length} navi tracciate</span>
              {atRisk > 0 ? (
                <span className="ml-3 text-red-400 font-bold">
                  ⚠ {atRisk} a rischio — chokepoint attivo
                </span>
              ) : (
                <span className="ml-3 text-slate-500">Nessun alert chokepoint</span>
              )}
            </div>
          </div>
        )}

      </main>
    </div>
  );
}
