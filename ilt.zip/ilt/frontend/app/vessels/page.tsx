/**
 * app/vessels/page.tsx
 * Vessel tracking — mappa live + tabella dettagli.
 */

"use client";

import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { clsx } from "clsx";
import { Ship, AlertTriangle, Filter } from "lucide-react";
import { VesselMap }    from "@/components/VesselMap";
import { pricesApi, type VesselPosition } from "@/lib/api";

const COMMODITIES = ["all", "oil", "gold", "silver", "lng", "grain"];

export default function VesselsPage() {
  const [filter, setFilter] = useState("all");

  const { data: vessels = [], isLoading } = useQuery<VesselPosition[]>({
    queryKey: ["vessels", filter],
    queryFn:  () => pricesApi.vessels(filter === "all" ? undefined : filter),
    refetchInterval: 300_000,  // ogni 5 minuti
  });

  const atRisk  = vessels.filter(v => v.is_at_risk);
  const filtered = filter === "all" ? vessels : vessels.filter(v => v.commodity === filter);

  return (
    <div className="space-y-5">

      {/* KPI */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="card px-4 py-3">
          <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Navi tracciate</div>
          <div className="font-sans font-bold text-xl text-white">{vessels.length}</div>
        </div>
        <div className={clsx("card px-4 py-3", atRisk.length > 0 && "border-red-800/60")}>
          <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">A rischio</div>
          <div className={clsx("font-sans font-bold text-xl", atRisk.length > 0 ? "text-red-400" : "text-emerald-400")}>
            {atRisk.length}
          </div>
        </div>
        <div className="card px-4 py-3">
          <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Oil tankers</div>
          <div className="font-sans font-bold text-xl text-orange-400">
            {vessels.filter(v => v.commodity === "oil").length}
          </div>
        </div>
        <div className="card px-4 py-3">
          <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Gold cargo</div>
          <div className="font-sans font-bold text-xl text-yellow-400">
            {vessels.filter(v => v.commodity === "gold").length}
          </div>
        </div>
      </div>

      {/* Hormuz alert se presenti navi bloccate */}
      {atRisk.length > 0 && (
        <div className="border-l-4 border-red-500 bg-red-950/20 px-4 py-3 rounded-r-lg text-sm flex items-start gap-3">
          <AlertTriangle size={16} className="text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <strong className="text-red-400">Alert chokepoint attivo</strong> — {atRisk.length}{" "}
            {atRisk.length === 1 ? "nave" : "navi"} a rischio:{" "}
            {atRisk.map(v => v.vessel_name ?? v.mmsi).join(", ")}
          </div>
        </div>
      )}

      {/* Filter bar */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter size={12} className="text-slate-500" />
        {COMMODITIES.map(c => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={clsx(
              "px-3 py-1 rounded text-xs border transition-colors capitalize",
              filter === c
                ? "bg-emerald-950/60 text-emerald-400 border-emerald-700/60"
                : "text-slate-500 border-[#1a2b35] hover:text-slate-300"
            )}
          >
            {c === "all" ? "Tutti" : c}
          </button>
        ))}
      </div>

      {/* Map */}
      <div className="card p-4">
        <div className="card-header -mx-4 -mt-4 mb-4 flex items-center gap-2">
          <Ship size={11} /> Tracking navi — posizioni live (aggiornate ogni 5 min)
        </div>
        {isLoading ? (
          <div className="flex items-center justify-center h-64 text-sm text-slate-600">
            Caricamento posizioni…
          </div>
        ) : (
          <VesselMap vessels={filtered} height={420} />
        )}
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="card-header">Dettaglio flotta</div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#1a2b35]">
                {["Nave", "MMSI", "Tipo", "Commodity", "Velocità", "Dest.", "Chokepoint", "Stato"].map(h => (
                  <th key={h} className="px-3 py-2 text-left text-[9px] text-slate-500 uppercase tracking-wider font-normal">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a2b35]">
              {filtered.map(v => (
                <tr key={v.mmsi} className="hover:bg-white/[0.02]">
                  <td className="px-3 py-2 font-bold text-white whitespace-nowrap">
                    {v.vessel_name ?? "—"}
                  </td>
                  <td className="px-3 py-2 text-slate-500 font-mono text-xs">{v.mmsi}</td>
                  <td className="px-3 py-2 text-slate-400 capitalize text-xs">{v.vessel_type ?? "—"}</td>
                  <td className="px-3 py-2">
                    <span className="text-xs px-2 py-0.5 rounded bg-white/5 border border-[#1a2b35]">
                      {v.commodity ?? "—"}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-slate-400">{v.speed?.toFixed(1) ?? "—"} kt</td>
                  <td className="px-3 py-2 text-slate-400 max-w-[120px] truncate text-xs">{v.destination ?? "—"}</td>
                  <td className="px-3 py-2">
                    {v.near_chokepoint ? (
                      <span className="text-xs text-amber-400">{v.near_chokepoint}</span>
                    ) : <span className="text-slate-600">—</span>}
                  </td>
                  <td className="px-3 py-2">
                    {v.is_at_risk
                      ? <span className="text-xs text-red-400 font-bold">⚠ RISCHIO</span>
                      : <span className="text-xs text-emerald-400">OK</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="py-8 text-center text-sm text-slate-600">Nessuna nave per questo filtro</div>
          )}
        </div>
      </div>

    </div>
  );
}
