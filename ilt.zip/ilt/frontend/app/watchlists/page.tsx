/**
 * app/watchlists/page.tsx
 * Gestione watchlists e price alert dell'utente.
 */

"use client";

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { clsx } from "clsx";
import { Plus, Trash2, Bell, BellOff, X, BookMarked } from "lucide-react";
import { watchlistsApi, alertsApi, type WatchlistResponse, type AlertResponse } from "@/lib/api";
import { useLivePrices } from "@/hooks/useLivePrices";

const TRACKED_ASSETS = ["NVDA","AAPL","MSFT","TSLA","META","AMZN","SPY","QQQ","GLD","SLV","GDX","OIH","BRENT","WTI"];

export default function WatchlistsPage() {
  const qc = useQueryClient();
  const { prices } = useLivePrices();

  const [newWlName,  setNewWlName]  = useState("");
  const [showNewWl,  setShowNewWl]  = useState(false);
  const [newAlertAsset, setNewAlertAsset] = useState("GLD");
  const [newAlertCond,  setNewAlertCond]  = useState<"above"|"below">("above");
  const [newAlertThreshold, setNewAlertThreshold] = useState("");
  const [showNewAlert, setShowNewAlert] = useState(false);

  const { data: watchlists = [] } = useQuery<WatchlistResponse[]>({
    queryKey: ["watchlists"],
    queryFn:  watchlistsApi.list,
  });

  const { data: alerts = [] } = useQuery<AlertResponse[]>({
    queryKey: ["alerts"],
    queryFn:  alertsApi.list,
  });

  const createWl = useMutation({
    mutationFn: () => watchlistsApi.create(newWlName, []),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["watchlists"] }); setNewWlName(""); setShowNewWl(false); },
  });

  const deleteWl = useMutation({
    mutationFn: (id: string) => watchlistsApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["watchlists"] }),
  });

  const toggleAsset = useMutation({
    mutationFn: ({ id, assets }: { id: string; assets: string[] }) =>
      watchlistsApi.update(id, { assets }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["watchlists"] }),
  });

  const createAlert = useMutation({
    mutationFn: () => alertsApi.create(newAlertAsset, newAlertCond, parseFloat(newAlertThreshold)),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["alerts"] });
      setNewAlertThreshold(""); setShowNewAlert(false);
    },
  });

  const deleteAlert = useMutation({
    mutationFn: (id: string) => alertsApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["alerts"] }),
  });

  return (
    <div className="space-y-6">

      {/* ── Watchlists ─────────────────────────────────────────────────── */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <BookMarked size={12} /> Le mie watchlists
          </h2>
          <button onClick={() => setShowNewWl(v => !v)}
            className="flex items-center gap-1.5 text-xs text-emerald-400 border border-emerald-700/50 px-3 py-1.5 rounded hover:bg-emerald-950/30 transition-colors">
            <Plus size={12} /> Nuova
          </button>
        </div>

        {showNewWl && (
          <div className="card px-4 py-3 mb-3 flex items-center gap-3">
            <input
              value={newWlName}
              onChange={e => setNewWlName(e.target.value)}
              placeholder="Nome watchlist…"
              className="flex-1 bg-transparent border border-[#1a2b35] rounded px-3 py-1.5 text-sm text-white placeholder:text-slate-600 focus:outline-none focus:border-emerald-700"
              onKeyDown={e => e.key === "Enter" && newWlName && createWl.mutate()}
            />
            <button onClick={() => newWlName && createWl.mutate()}
              className="text-xs px-3 py-1.5 bg-emerald-400 text-black rounded font-bold">
              Crea
            </button>
            <button onClick={() => setShowNewWl(false)} className="text-slate-500 hover:text-white">
              <X size={14} />
            </button>
          </div>
        )}

        <div className="space-y-3">
          {watchlists.map(wl => (
            <div key={wl.id} className="card overflow-hidden">
              <div className="px-4 py-3 border-b border-[#1a2b35] flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white text-sm">{wl.name}</span>
                  {wl.is_default && <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-900/40 text-emerald-400 border border-emerald-800/50">DEFAULT</span>}
                  <span className="text-[10px] text-slate-500">{wl.assets.length} asset</span>
                </div>
                {!wl.is_default && (
                  <button onClick={() => deleteWl.mutate(wl.id)} className="text-slate-600 hover:text-red-400 transition-colors">
                    <Trash2 size={13} />
                  </button>
                )}
              </div>

              {/* Asset grid */}
              <div className="p-3 flex flex-wrap gap-2">
                {TRACKED_ASSETS.map(asset => {
                  const inList = wl.assets.includes(asset);
                  const price  = prices[asset];
                  return (
                    <button
                      key={asset}
                      onClick={() => {
                        const next = inList
                          ? wl.assets.filter(a => a !== asset)
                          : [...wl.assets, asset];
                        toggleAsset.mutate({ id: wl.id, assets: next });
                      }}
                      className={clsx(
                        "px-2.5 py-1.5 rounded border text-xs transition-colors",
                        inList
                          ? "bg-emerald-950/40 text-emerald-400 border-emerald-700/60"
                          : "text-slate-500 border-[#1a2b35] hover:border-slate-500"
                      )}
                    >
                      <span className="font-bold">{asset}</span>
                      {price && inList && (
                        <span className="ml-1.5 text-[10px] text-slate-400">
                          ${price.toFixed(price > 100 ? 0 : 2)}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Price alerts ────────────────────────────────────────────────── */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-[10px] text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <Bell size={12} /> Price alerts
          </h2>
          <button onClick={() => setShowNewAlert(v => !v)}
            className="flex items-center gap-1.5 text-xs text-amber-400 border border-amber-700/50 px-3 py-1.5 rounded hover:bg-amber-950/30 transition-colors">
            <Plus size={12} /> Nuovo alert
          </button>
        </div>

        {showNewAlert && (
          <div className="card px-4 py-4 mb-3">
            <div className="flex flex-wrap gap-3 items-end">
              <div>
                <label className="text-[9px] text-slate-500 uppercase tracking-widest block mb-1">Asset</label>
                <select value={newAlertAsset} onChange={e => setNewAlertAsset(e.target.value)}
                  className="bg-[#0c1318] border border-[#1a2b35] rounded px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-700">
                  {TRACKED_ASSETS.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[9px] text-slate-500 uppercase tracking-widest block mb-1">Condizione</label>
                <select value={newAlertCond} onChange={e => setNewAlertCond(e.target.value as any)}
                  className="bg-[#0c1318] border border-[#1a2b35] rounded px-3 py-1.5 text-sm text-white focus:outline-none focus:border-amber-700">
                  <option value="above">Sopra</option>
                  <option value="below">Sotto</option>
                </select>
              </div>
              <div>
                <label className="text-[9px] text-slate-500 uppercase tracking-widest block mb-1">Soglia ($)</label>
                <input
                  type="number" value={newAlertThreshold} onChange={e => setNewAlertThreshold(e.target.value)}
                  placeholder="es. 5500"
                  className="bg-[#0c1318] border border-[#1a2b35] rounded px-3 py-1.5 text-sm text-white w-32 focus:outline-none focus:border-amber-700 placeholder:text-slate-600"
                />
              </div>
              <button
                onClick={() => newAlertThreshold && createAlert.mutate()}
                disabled={!newAlertThreshold}
                className="px-4 py-1.5 bg-amber-400 text-black text-xs font-bold rounded disabled:opacity-40">
                Crea
              </button>
              <button onClick={() => setShowNewAlert(false)} className="text-slate-500 hover:text-white pb-0.5">
                <X size={14} />
              </button>
            </div>
          </div>
        )}

        <div className="card overflow-hidden">
          {alerts.length === 0 ? (
            <div className="px-4 py-8 text-center text-sm text-slate-600 flex flex-col items-center gap-2">
              <BellOff size={20} className="text-slate-700" />
              Nessun alert attivo — creane uno sopra
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#1a2b35]">
                  {["Asset", "Condizione", "Soglia", "Prezzo live", "Stato", ""].map(h => (
                    <th key={h} className="px-4 py-2 text-left text-[9px] text-slate-500 uppercase tracking-wider font-normal">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a2b35]">
                {alerts.map(alert => {
                  const live = prices[alert.asset];
                  const triggered = alert.triggered_at !== null;
                  const wouldTrigger = live !== undefined && (
                    (alert.condition === "above" && live >= alert.threshold) ||
                    (alert.condition === "below" && live <= alert.threshold)
                  );
                  return (
                    <tr key={alert.id} className={clsx("hover:bg-white/[0.02]", triggered && "opacity-60")}>
                      <td className="px-4 py-3 font-bold text-white">{alert.asset}</td>
                      <td className="px-4 py-3 text-slate-400 capitalize">{alert.condition === "above" ? "Sopra" : "Sotto"}</td>
                      <td className="px-4 py-3 font-mono text-white">${alert.threshold.toLocaleString()}</td>
                      <td className="px-4 py-3">
                        {live ? (
                          <span className={clsx("font-mono", wouldTrigger ? "text-amber-400 font-bold" : "text-slate-400")}>
                            ${live.toFixed(live > 100 ? 0 : 2)}
                          </span>
                        ) : <span className="text-slate-600">—</span>}
                      </td>
                      <td className="px-4 py-3">
                        {triggered
                          ? <span className="text-[10px] text-slate-500">Triggerato</span>
                          : wouldTrigger
                            ? <span className="text-[10px] text-amber-400 font-bold animate-pulse">⚡ Vicino</span>
                            : <span className="text-[10px] text-emerald-400">Attivo</span>}
                      </td>
                      <td className="px-4 py-3">
                        <button onClick={() => deleteAlert.mutate(alert.id)}
                          className="text-slate-600 hover:text-red-400 transition-colors">
                          <X size={13} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
}
