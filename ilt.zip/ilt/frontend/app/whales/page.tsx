/**
 * app/whales/page.tsx
 * Whale Emulator — profili istituzionali + feed trade live + portafoglio.
 */

"use client";

import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { clsx } from "clsx";
import { TrendingUp, TrendingDown, Zap, Trophy, Copy, X } from "lucide-react";
import { pricesApi, type WhaleSignal } from "@/lib/api";
import { useLivePrices } from "@/hooks/useLivePrices";

// ── Whale profiles (statici — in prod vengono dal DB) ─────────────────────────

const WHALES = [
  { id: "BW", name: "Blackwater Capital", style: "Momentum / Macro",   wr: 78, aum: "$42B", color: "#ff3d5a",  bias: "LONG"  },
  { id: "QH", name: "QuantHorizon Fund",  style: "Quant / Systematic", wr: 71, aum: "$28B", color: "#29b6f6",  bias: "MIXED" },
  { id: "AM", name: "Atlas Macro",        style: "Global Macro / FX",  wr: 65, aum: "$19B", color: "#ffd54f",  bias: "SHORT" },
  { id: "NX", name: "Nexus Algorithmic",  style: "HFT / Arb",          wr: 83, aum: "$8B",  color: "#b39ddb",  bias: "MIXED" },
  { id: "DW", name: "Deep Water Inv.",    style: "Value / Contrarian",  wr: 60, aum: "$14B", color: "#00e5a0",  bias: "LONG"  },
  { id: "ST", name: "Stormlight Macro",   style: "Options / Vol",      wr: 69, aum: "$6B",  color: "#f5a623",  bias: "SHORT" },
];

interface PortfolioPosition {
  id:        string;
  asset:     string;
  direction: "LONG" | "SHORT";
  entry:     number;
  current:   number;
  whaleName: string;
  whaleColor: string;
  pnlK:      number;
  pnlPct:    number;
}

export default function WhalesPage() {
  const { prices } = useLivePrices();
  const [following,  setFollowing]  = useState<Set<string>>(new Set());
  const [portfolio,  setPortfolio]  = useState<PortfolioPosition[]>([]);
  const [realizedPnl, setRealized]  = useState(0);
  const [closedLog,  setClosedLog]  = useState<any[]>([]);

  const { data: signals = [] } = useQuery<WhaleSignal[]>({
    queryKey: ["whale-signals"],
    queryFn:  () => pricesApi.whaleSignals(2, undefined, 0.4),
    refetchInterval: 10_000,
  });

  // Aggiorna PnL posizioni aperte quando arrivano nuovi prezzi
  useEffect(() => {
    if (!Object.keys(prices).length) return;
    setPortfolio(prev => prev.map(pos => {
      const curr = prices[pos.asset] ?? pos.current;
      const raw  = (curr - pos.entry) / pos.entry;
      const sign = pos.direction === "LONG" ? 1 : -1;
      return {
        ...pos,
        current: curr,
        pnlK:    +(raw * sign * 100).toFixed(2),
        pnlPct:  +(raw * sign * 100).toFixed(2),
      };
    }));
  }, [prices]);

  const copySignal = (sig: WhaleSignal, whaleName: string, whaleColor: string) => {
    const price = prices[sig.asset] ?? 0;
    if (!price) return;
    setPortfolio(prev => {
      if (prev.find(p => p.id === sig.signal_id)) return prev;
      return [{
        id: sig.signal_id, asset: sig.asset,
        direction: sig.direction as "LONG" | "SHORT",
        entry: price, current: price,
        whaleName, whaleColor, pnlK: 0, pnlPct: 0,
      }, ...prev];
    });
  };

  const closePosition = (id: string) => {
    const pos = portfolio.find(p => p.id === id);
    if (!pos) return;
    setRealized(r => r + pos.pnlK);
    setClosedLog(l => [{ ...pos, closeTime: new Date().toLocaleTimeString("it-IT") }, ...l].slice(0, 30));
    setPortfolio(prev => prev.filter(p => p.id !== id));
  };

  const totalPnl = realizedPnl + portfolio.reduce((a, p) => a + p.pnlK, 0);

  return (
    <div className="space-y-5">

      {/* KPI */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="card px-4 py-3">
          <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Win rate medio</div>
          <div className="font-sans font-bold text-xl text-emerald-400">
            {(WHALES.reduce((a, w) => a + w.wr, 0) / WHALES.length).toFixed(1)}%
          </div>
        </div>
        <div className="card px-4 py-3">
          <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Segnali 48h</div>
          <div className="font-sans font-bold text-xl text-amber-400">{signals.length}</div>
        </div>
        <div className={clsx("card px-4 py-3", totalPnl >= 0 ? "border-emerald-800/50" : "border-red-800/50")}>
          <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Il mio P&L</div>
          <div className={clsx("font-sans font-bold text-xl", totalPnl >= 0 ? "text-emerald-400" : "text-red-400")}>
            {totalPnl >= 0 ? "+" : ""}{totalPnl.toFixed(1)}K
          </div>
        </div>
        <div className="card px-4 py-3">
          <div className="text-[9px] text-slate-500 uppercase tracking-widest mb-1">Posizioni aperte</div>
          <div className="font-sans font-bold text-xl text-blue-400">{portfolio.length}</div>
        </div>
      </div>

      {/* Whale cards */}
      <div>
        <h2 className="text-[10px] text-slate-500 uppercase tracking-widest mb-3 flex items-center gap-2">
          <Zap size={12} /> Profili Whale — Win Rate Live
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {WHALES.map(w => {
            const isFollowing = following.has(w.id);
            const wSignals = signals.filter(s => s.strength > 0.6).slice(0, 3);
            return (
              <div key={w.id} className={clsx("card overflow-hidden transition-colors",
                isFollowing && "border-emerald-700/60")}>
                <div className="px-4 py-3 border-b border-[#1a2b35] flex items-start justify-between">
                  <div>
                    <div className="font-sans font-bold text-white text-sm">{w.name}</div>
                    <div className="text-[9px] text-slate-500 uppercase tracking-widest mt-0.5">{w.style}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-sans font-bold text-lg" style={{ color: w.color }}>{w.wr}%</div>
                    <div className="text-[9px] text-slate-500">win rate</div>
                  </div>
                </div>
                <div className="px-4 py-3">
                  {/* WR bar */}
                  <div className="h-1.5 bg-slate-800 rounded-full overflow-hidden mb-3">
                    <div className="h-full rounded-full" style={{ width: `${w.wr}%`, background: w.color }} />
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500 mb-3">
                    <span>AUM: {w.aum}</span>
                    <span>Bias: {w.bias}</span>
                  </div>
                  <button
                    onClick={() => setFollowing(prev => {
                      const next = new Set(prev);
                      next.has(w.id) ? next.delete(w.id) : next.add(w.id);
                      return next;
                    })}
                    className={clsx(
                      "w-full py-1.5 rounded text-xs font-bold tracking-wide transition-colors border",
                      isFollowing
                        ? "bg-emerald-400 text-black border-emerald-400"
                        : "bg-transparent text-emerald-400 border-emerald-700/50 hover:border-emerald-400"
                    )}
                  >
                    {isFollowing ? "✓ Seguendo" : "Copia segnali"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">

        {/* Signal feed */}
        <div className="card overflow-hidden">
          <div className="card-header flex items-center justify-between">
            <span>Feed segnali recenti</span>
            <span className="text-emerald-400">{signals.length}</span>
          </div>
          <div className="divide-y divide-[#1a2b35] max-h-96 overflow-y-auto">
            {signals.length === 0 && (
              <div className="px-4 py-8 text-center text-sm text-slate-600">Nessun segnale recente</div>
            )}
            {signals.map(sig => {
              const whale = WHALES[Math.abs(sig.signal_id.charCodeAt(0)) % WHALES.length];
              const isLong = sig.direction === "LONG";
              const currentPrice = prices[sig.asset];
              return (
                <div key={sig.signal_id} className="flex items-center gap-3 px-3 py-2.5 text-sm">
                  <div className={clsx("w-7 h-7 rounded flex items-center justify-center flex-shrink-0",
                    isLong ? "bg-emerald-900/50 text-emerald-400" : "bg-red-900/50 text-red-400")}>
                    {isLong ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{sig.asset}</span>
                      <span className={clsx("text-[9px] px-1.5 py-0.5 rounded border",
                        isLong ? "text-emerald-400 border-emerald-800/60 bg-emerald-900/30" : "text-red-400 border-red-800/60 bg-red-900/30"
                      )}>{sig.direction}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      {sig.signal_type} · strength {Math.round(sig.strength * 100)}%
                      {sig.z_score && ` · z=${sig.z_score.toFixed(1)}`}
                    </div>
                  </div>
                  <button
                    onClick={() => copySignal(sig, whale.name, whale.color)}
                    className="text-[10px] px-2 py-1 border border-emerald-700/50 text-emerald-400 rounded hover:bg-emerald-950/30 transition-colors flex items-center gap-1"
                  >
                    <Copy size={10} /> COPIA
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Portfolio */}
        <div className="card overflow-hidden">
          <div className="card-header flex items-center justify-between">
            <span>Il mio portafoglio emulato</span>
            <button onClick={() => {
              portfolio.forEach(p => closePosition(p.id));
            }} className="text-[10px] text-red-400 border border-red-800/50 px-2 py-0.5 rounded hover:bg-red-950/20">
              CHIUDI TUTTO
            </button>
          </div>
          {portfolio.length === 0 ? (
            <div className="px-4 py-8 text-center text-sm text-slate-600">
              Nessuna posizione — clicca COPIA su un segnale
            </div>
          ) : (
            <div className="divide-y divide-[#1a2b35]">
              {portfolio.map(pos => (
                <div key={pos.id} className="flex items-center gap-3 px-3 py-2.5 text-sm">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{pos.asset}</span>
                      <span className={clsx("text-[9px] px-1 py-0.5 rounded border",
                        pos.direction === "LONG"
                          ? "text-emerald-400 border-emerald-800/60"
                          : "text-red-400 border-red-800/60"
                      )}>{pos.direction}</span>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      Entry ${pos.entry.toFixed(2)} → ${pos.current.toFixed(2)}
                    </div>
                  </div>
                  <div className={clsx("font-bold text-sm", pos.pnlK >= 0 ? "text-emerald-400" : "text-red-400")}>
                    {pos.pnlK >= 0 ? "+" : ""}{pos.pnlK.toFixed(1)}K
                  </div>
                  <button onClick={() => closePosition(pos.id)}
                    className="text-red-400 hover:text-red-300 p-1">
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="px-3 py-2 bg-[#060a0d] border-t border-[#1a2b35] flex justify-between text-xs text-slate-500">
            <span>Realizzato: <span className={realizedPnl >= 0 ? "text-emerald-400" : "text-red-400"}>
              {realizedPnl >= 0 ? "+" : ""}{realizedPnl.toFixed(1)}K
            </span></span>
            <span>Totale: <span className={totalPnl >= 0 ? "text-emerald-400 font-bold" : "text-red-400 font-bold"}>
              {totalPnl >= 0 ? "+" : ""}{totalPnl.toFixed(1)}K
            </span></span>
          </div>
        </div>
      </div>

      {/* Leaderboard */}
      <div className="card overflow-hidden">
        <div className="card-header flex items-center gap-2">
          <Trophy size={11} /> Leaderboard — Win Rate
        </div>
        <div className="divide-y divide-[#1a2b35]">
          {[...WHALES].sort((a, b) => b.wr - a.wr).map((w, i) => (
            <div key={w.id} className="flex items-center gap-4 px-4 py-3 text-sm">
              <span className={clsx("font-sans font-bold text-lg w-6",
                i === 0 ? "text-yellow-400" : i === 1 ? "text-slate-400" : i === 2 ? "text-amber-700" : "text-slate-600"
              )}>{i + 1}</span>
              <div className="flex-1">
                <div className="font-bold text-white text-sm">{w.name}</div>
                <div className="text-[10px] text-slate-500">{w.style} · {w.aum}</div>
              </div>
              <div className="w-24">
                <div className="font-sans font-bold" style={{ color: w.color }}>{w.wr}%</div>
                <div className="h-1 bg-slate-800 rounded-full mt-1 overflow-hidden">
                  <div className="h-full rounded-full" style={{ width: `${w.wr}%`, background: w.color }} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
