/**
 * components/ConnectionStatus.tsx
 * Pill stato connessione WebSocket mostrato nell'header.
 */

"use client";

import { clsx } from "clsx";
import { type ConnectionStatus } from "@/hooks/useLivePrices";

const LABELS: Record<ConnectionStatus, string> = {
  connecting:   "Connessione…",
  connected:    "LIVE",
  disconnected: "Disconnesso",
  error:        "Errore WS",
};

interface Props {
  status:     ConnectionStatus;
  lastUpdate: Date | null;
}

export function ConnectionStatus({ status, lastUpdate }: Props) {
  return (
    <div className="flex items-center gap-3 text-[10px]">
      <div className={clsx(
        "flex items-center gap-1.5 px-2.5 py-1 rounded-full border",
        status === "connected"    && "bg-emerald-950/50 border-emerald-700/40 text-emerald-400",
        status === "connecting"   && "bg-slate-800/50 border-slate-600/40 text-slate-400",
        status === "disconnected" && "bg-slate-800/50 border-slate-600/40 text-slate-500",
        status === "error"        && "bg-red-950/50 border-red-700/40 text-red-400",
      )}>
        <span className={clsx(
          "w-1.5 h-1.5 rounded-full",
          status === "connected"  && "bg-emerald-400 animate-pulse",
          status === "connecting" && "bg-amber-400 animate-pulse",
          status === "error"      && "bg-red-400",
          status === "disconnected" && "bg-slate-500",
        )} />
        {LABELS[status]}
      </div>
      {lastUpdate && status === "connected" && (
        <span className="text-slate-600">
          {lastUpdate.toLocaleTimeString("it-IT")}
        </span>
      )}
    </div>
  );
}
