/**
 * components/MacroBar.tsx
 * Strip orizzontale con i dati macro chiave.
 * Aggiornata ogni 5 minuti tramite TanStack Query.
 */

"use client";

import { useQuery } from "@tanstack/react-query";
import { clsx } from "clsx";
import { macroApi } from "@/lib/api";

interface MacroTileProps {
  label:     string;
  value:     number | undefined;
  unit?:     string;
  decimals?: number;
  colorFn?:  (v: number) => string;
}

function MacroTile({ label, value, unit = "", decimals = 2, colorFn }: MacroTileProps) {
  const color = value !== undefined && colorFn ? colorFn(value) : "text-slate-300";
  return (
    <div className="flex flex-col items-center px-4 py-2 border-r border-[#1a2b35] last:border-r-0 min-w-[90px]">
      <span className="text-[9px] text-slate-500 uppercase tracking-widest mb-0.5">{label}</span>
      <span className={clsx("font-sans font-bold text-sm", color)}>
        {value !== undefined ? `${value.toFixed(decimals)}${unit}` : "—"}
      </span>
    </div>
  );
}

export function MacroBar() {
  const { data } = useQuery({
    queryKey: ["macro"],
    queryFn:  macroApi.latest,
    refetchInterval: 300_000,
    staleTime: 60_000,
  });

  const vix      = data?.["FRED.VIXCLS"];
  const t10      = data?.["FRED.DGS10"];
  const t2       = data?.["FRED.DGS2"];
  const fed      = data?.["FRED.FEDFUNDS"];
  const dxy      = data?.["FRED.DTWEXBGS"];
  const wti      = data?.["EIA.PET.RWTC.D"];
  const spread   = t10 !== undefined && t2 !== undefined ? +(t10 - t2).toFixed(2) : undefined;

  return (
    <div className="flex overflow-x-auto bg-[#0c1318] border-b border-[#1a2b35] text-xs">
      <MacroTile
        label="VIX"
        value={vix}
        decimals={2}
        colorFn={v => v > 30 ? "text-red-400" : v > 20 ? "text-amber-400" : "text-emerald-400"}
      />
      <MacroTile
        label="Fed Rate"
        value={fed}
        unit="%"
        colorFn={v => v > 5 ? "text-amber-400" : "text-slate-300"}
      />
      <MacroTile
        label="US 10Y"
        value={t10}
        unit="%"
        colorFn={v => v > 4.5 ? "text-amber-400" : "text-blue-400"}
      />
      <MacroTile
        label="10Y-2Y"
        value={spread}
        unit="%"
        decimals={2}
        colorFn={v => v < 0 ? "text-red-400" : "text-emerald-400"}
      />
      <MacroTile
        label="DXY"
        value={dxy}
        decimals={2}
        colorFn={v => v > 103 ? "text-amber-400" : "text-slate-300"}
      />
      <MacroTile
        label="WTI"
        value={wti}
        unit="$"
        colorFn={v => v > 100 ? "text-red-400" : v > 80 ? "text-amber-400" : "text-slate-300"}
      />
    </div>
  );
}
