/**
 * components/PriceBoard.tsx
 * Griglia di KPI prezzi live con flash su variazione.
 */

"use client";

import { useEffect, useRef, useState } from "react";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { clsx } from "clsx";

interface PriceTileProps {
  asset:     string;
  price:     number;
  changePct: number | undefined;
  prefix?:   string;
  decimals?: number;
}

function PriceTile({ asset, price, changePct, prefix = "", decimals = 2 }: PriceTileProps) {
  const prevRef  = useRef<number>(price);
  const [flash, setFlash] = useState<"up" | "dn" | null>(null);

  useEffect(() => {
    if (prevRef.current === price) return;
    setFlash(price > prevRef.current ? "up" : "dn");
    prevRef.current = price;
    const t = setTimeout(() => setFlash(null), 600);
    return () => clearTimeout(t);
  }, [price]);

  const up  = (changePct ?? 0) >= 0;
  const Icon = changePct === undefined ? Minus : up ? TrendingUp : TrendingDown;

  return (
    <div className={clsx(
      "rounded-lg border p-4 transition-colors duration-200",
      "bg-[#0c1318] border-[#1a2b35]",
      flash === "up" && "bg-emerald-950/40 border-emerald-700/60",
      flash === "dn" && "bg-red-950/40 border-red-700/60",
    )}>
      <div className="text-[10px] tracking-widest text-slate-500 uppercase mb-1">{asset}</div>
      <div className={clsx(
        "font-bold text-2xl font-sans transition-colors duration-300",
        flash === "up" ? "text-emerald-400" : flash === "dn" ? "text-red-400" : "text-white"
      )}>
        {prefix}{price.toLocaleString("en-US", {
          minimumFractionDigits: decimals,
          maximumFractionDigits: decimals,
        })}
      </div>
      {changePct !== undefined && (
        <div className={clsx(
          "flex items-center gap-1 text-xs mt-1",
          up ? "text-emerald-400" : "text-red-400"
        )}>
          <Icon size={12} />
          {up ? "+" : ""}{changePct.toFixed(2)}%
        </div>
      )}
    </div>
  );
}

// ── Board ──────────────────────────────────────────────────────────────────────

const BOARD_CONFIG: { asset: string; prefix?: string; decimals?: number }[] = [
  { asset: "SPY",   prefix: "$", decimals: 2 },
  { asset: "QQQ",   prefix: "$", decimals: 2 },
  { asset: "NVDA",  prefix: "$", decimals: 2 },
  { asset: "GLD",   prefix: "$", decimals: 1 },
  { asset: "SLV",   prefix: "$", decimals: 2 },
  { asset: "BRENT", prefix: "$", decimals: 2 },
  { asset: "WTI",   prefix: "$", decimals: 2 },
  { asset: "GDX",   prefix: "$", decimals: 2 },
];

interface PriceBoardProps {
  prices:  Record<string, number>;
  changes: Record<string, number>;
}

export function PriceBoard({ prices, changes }: PriceBoardProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {BOARD_CONFIG.map(({ asset, prefix, decimals }) => {
        const price = prices[asset];
        if (!price) return null;
        return (
          <PriceTile
            key={asset}
            asset={asset}
            price={price}
            changePct={changes[asset]}
            prefix={prefix}
            decimals={decimals}
          />
        );
      })}
    </div>
  );
}
