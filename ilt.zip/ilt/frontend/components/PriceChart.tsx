/**
 * components/PriceChart.tsx
 * Wrapper TradingView Lightweight Charts v4 per candele OHLCV.
 */

"use client";

import { useEffect, useRef } from "react";
import {
  createChart,
  ColorType,
  CandlestickSeries,
  type IChartApi,
  type ISeriesApi,
  type CandlestickData,
} from "lightweight-charts";
import { type OHLCVBar } from "@/lib/api";

interface Props {
  bars:      OHLCVBar[];
  height?:   number;
  className?: string;
}

function toChartData(bar: OHLCVBar): CandlestickData {
  const d = new Date(bar.time);
  const ts = Math.floor(d.getTime() / 1000) as any;
  return { time: ts, open: bar.open, high: bar.high, low: bar.low, close: bar.close };
}

export function PriceChart({ bars, height = 300, className }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef     = useRef<IChartApi | null>(null);
  const seriesRef    = useRef<ISeriesApi<"Candlestick"> | null>(null);

  // Crea chart
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;

    const chart = createChart(el, {
      layout: {
        background: { type: ColorType.Solid, color: "transparent" },
        textColor: "#6e8ea0",
        fontFamily: "'Space Mono', monospace",
        fontSize: 11,
      },
      grid: {
        vertLines: { color: "#1a2b35" },
        horzLines: { color: "#1a2b35" },
      },
      rightPriceScale: { borderColor: "#1a2b35" },
      timeScale: { borderColor: "#1a2b35", timeVisible: true },
      crosshair: { mode: 1 },
      height,
    });

    const series = chart.addSeries(CandlestickSeries, {
      upColor:       "#00e5a0",
      downColor:     "#ff3d5a",
      borderUpColor: "#00e5a0",
      borderDownColor: "#ff3d5a",
      wickUpColor:   "#00e5a0",
      wickDownColor: "#ff3d5a",
    });

    chartRef.current = chart;
    seriesRef.current = series;

    // Resize observer
    const ro = new ResizeObserver(() => {
      chart.applyOptions({ width: el.clientWidth });
    });
    ro.observe(el);

    return () => {
      ro.disconnect();
      chart.remove();
    };
  }, [height]);

  // Aggiorna dati
  useEffect(() => {
    if (!seriesRef.current || bars.length === 0) return;
    const data = bars
      .map(toChartData)
      .sort((a, b) => (a.time as number) - (b.time as number));
    seriesRef.current.setData(data);
    chartRef.current?.timeScale().fitContent();
  }, [bars]);

  return <div ref={containerRef} className={className} style={{ height }} />;
}
