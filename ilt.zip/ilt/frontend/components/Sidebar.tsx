/**
 * components/Sidebar.tsx
 * Navigazione laterale con stato attivo basato su pathname.
 */

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { clsx } from "clsx";
import {
  LayoutDashboard, TrendingUp, Ship, Zap,
  BookMarked, Settings, LogOut, BarChart2,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

const NAV = [
  { href: "/",           label: "Overview",   icon: LayoutDashboard },
  { href: "/whales",     label: "Whales",     icon: Zap             },
  { href: "/vessels",    label: "Vessels",    icon: Ship            },
  { href: "/watchlists", label: "Watchlists", icon: BookMarked      },
];

export function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();

  return (
    <aside className="fixed left-0 top-0 h-full w-56 border-r border-[#1a2b35] bg-[#060a0d] flex flex-col z-40">

      {/* Logo */}
      <div className="px-4 py-4 border-b border-[#1a2b35]">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded bg-emerald-400 flex items-center justify-center text-black text-[11px] font-bold flex-shrink-0">
            ILT
          </div>
          <span className="font-sans font-bold text-sm">
            <span className="text-emerald-400">ILT</span> Market
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto">
        {NAV.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || (href !== "/" && pathname.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
                active
                  ? "bg-emerald-950/60 text-emerald-400 border border-emerald-800/50"
                  : "text-slate-400 hover:text-white hover:bg-white/5"
              )}
            >
              <Icon size={15} className="flex-shrink-0" />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* User section */}
      <div className="px-2 py-3 border-t border-[#1a2b35] space-y-0.5">
        {user ? (
          <>
            <div className="px-3 py-2 text-xs text-slate-500 truncate">
              {user.email}
            </div>
            <button
              onClick={logout}
              className="flex w-full items-center gap-3 px-3 py-2 rounded-md text-sm text-slate-400 hover:text-red-400 hover:bg-red-950/20 transition-colors"
            >
              <LogOut size={15} />
              Logout
            </button>
          </>
        ) : (
          <Link
            href="/login"
            className="flex items-center gap-3 px-3 py-2 rounded-md text-sm text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          >
            <Settings size={15} />
            Login
          </Link>
        )}
      </div>
    </aside>
  );
}
