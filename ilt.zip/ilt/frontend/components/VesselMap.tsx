/**
 * components/VesselMap.tsx
 * Canvas map delle navi cargo con posizioni live.
 * Proiezione equirettangolare semplificata — stessa logica del prototipo HTML originale.
 */

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { clsx } from "clsx";
import { type VesselPosition } from "@/lib/api";

interface Props {
  vessels:   VesselPosition[];
  height?:   number;
  className?: string;
}

interface Chokepoint {
  name:   string;
  lat:    number;
  lon:    number;
  status: "BLOCKED" | "RISKY" | "NORMAL";
  radius: number;
}

const CHOKEPOINTS: Chokepoint[] = [
  { name: "Hormuz",   lat: 26.5, lon: 56.5, status: "BLOCKED", radius: 14 },
  { name: "Suez",     lat: 30.5, lon: 32.3, status: "RISKY",   radius: 10 },
  { name: "Malacca",  lat: 1.2,  lon: 103.8,status: "NORMAL",  radius:  8 },
  { name: "Gibraltar",lat: 35.9, lon: -5.4, status: "NORMAL",  radius:  7 },
  { name: "C.Buona Speranza", lat: -34.4, lon: 18.5, status: "RISKY", radius: 10 },
];

const COMMODITY_COLORS: Record<string, string> = {
  oil:    "#ef6c00",
  gold:   "#ffd54f",
  silver: "#b0bec5",
  lng:    "#29b6f6",
  grain:  "#8bc34a",
};

function project(lat: number, lon: number, W: number, H: number): [number, number] {
  return [(lon + 180) / 360 * W, (90 - lat) / 180 * H];
}

export function VesselMap({ vessels, height = 380, className }: Props) {
  const canvasRef   = useRef<HTMLCanvasElement>(null);
  const [hovered, setHovered] = useState<VesselPosition | null>(null);
  const [tooltip, setTooltip] = useState({ x: 0, y: 0 });

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    // Ocean background
    ctx.fillStyle = "#07121a";
    ctx.fillRect(0, 0, W, H);

    // Grid lines
    ctx.strokeStyle = "rgba(20,42,55,0.9)";
    ctx.lineWidth = 0.4;
    for (let lon = -150; lon <= 180; lon += 30) {
      const [x0, y0] = project(85, lon, W, H);
      const [x1, y1] = project(-85, lon, W, H);
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    }
    for (let lat = 60; lat >= -60; lat -= 30) {
      const [x0, y0] = project(lat, -180, W, H);
      const [x1, y1] = project(lat, 180, W, H);
      ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
    }

    // Chokepoints
    for (const cp of CHOKEPOINTS) {
      const [cx, cy] = project(cp.lat, cp.lon, W, H);
      const color = cp.status === "BLOCKED" ? "#ff3d5a" : cp.status === "RISKY" ? "#f5a623" : "#334e5e";

      if (cp.status !== "NORMAL") {
        ctx.beginPath();
        ctx.arc(cx, cy, cp.radius + 5, 0, Math.PI * 2);
        ctx.fillStyle = color + "15";
        ctx.fill();
      }

      ctx.beginPath();
      ctx.arc(cx, cy, cp.radius, 0, Math.PI * 2);
      ctx.fillStyle = color + "25";
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1;
      ctx.setLineDash([3, 3]);
      ctx.stroke();
      ctx.setLineDash([]);

      if (cp.status !== "NORMAL") {
        ctx.fillStyle = color;
        ctx.font = "bold 9px monospace";
        ctx.textAlign = "center";
        ctx.fillText(cp.name, cx, cy - cp.radius - 5);
      }
    }

    // Vessels
    for (const v of vessels) {
      const [vx, vy] = project(v.latitude, v.longitude, W, H);
      const isHovered = hovered?.mmsi === v.mmsi;
      const color = COMMODITY_COLORS[v.commodity ?? ""] ?? "#888";
      const r = isHovered ? 7 : 5;

      if (v.is_at_risk) {
        ctx.beginPath();
        ctx.arc(vx, vy, r + 6, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(255,61,90,0.15)";
        ctx.fill();
      }

      // Ship triangle
      ctx.beginPath();
      ctx.moveTo(vx, vy - r);
      ctx.lineTo(vx + r * 0.75, vy + r * 0.6);
      ctx.lineTo(vx - r * 0.75, vy + r * 0.6);
      ctx.closePath();
      ctx.fillStyle = v.is_at_risk ? "#ff3d5a" : color;
      ctx.fill();
      if (isHovered) {
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 1;
        ctx.stroke();
      }
    }

    // Continents (simplified landmasses — solo outline)
    ctx.fillStyle = "#1a2e3b";
    ctx.strokeStyle = "rgba(40,80,100,0.5)";
    ctx.lineWidth = 0.5;

    const lands: [number, number][][] = [
      // North America
      [[-168,72],[-95,72],[-65,70],[-52,47],[-67,44],[-75,35],[-80,25],[-92,20],[-97,26],[-117,32],[-124,49],[-130,55],[-168,65]],
      // South America
      [[-78,12],[-50,5],[-35,-12],[-40,-22],[-50,-30],[-65,-55],[-72,-40],[-75,-14],[-80,-2],[-80,8]],
      // Europe
      [[28,71],[32,65],[28,60],[8,55],[-2,50],[-9,39],[-5,36],[15,38],[22,38],[30,40],[40,42],[40,68]],
      // Africa
      [[-6,35],[25,35],[37,20],[43,12],[50,8],[44,4],[36,-8],[18,-34],[0,4],[-16,12],[-6,35]],
      // Asia (simplified)
      [[40,42],[60,46],[80,44],[88,48],[100,52],[120,52],[140,54],[150,60],[170,55],[145,44],[130,32],[115,24],[100,4],[98,6],[68,24],[58,28],[58,36],[40,42]],
      // Australia
      [[114,-22],[130,-14],[138,-15],[150,-22],[151,-34],[128,-34],[114,-30]],
    ];

    for (const pts of lands) {
      ctx.beginPath();
      const [sx, sy] = project(pts[0][1], pts[0][0], W, H);
      ctx.moveTo(sx, sy);
      for (let i = 1; i < pts.length; i++) {
        const [px, py] = project(pts[i][1], pts[i][0], W, H);
        ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }
  }, [vessels, hovered]);

  // Canvas sizing
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio ?? 1;
    const W   = canvas.parentElement?.clientWidth ?? 800;
    canvas.width  = W * dpr;
    canvas.height = height * dpr;
    canvas.style.width  = `${W}px`;
    canvas.style.height = `${height}px`;
    const ctx = canvas.getContext("2d");
    ctx?.scale(dpr, dpr);
    draw();
  }, [height]);

  useEffect(() => { draw(); }, [draw]);

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const mx   = (e.clientX - rect.left) / rect.width;
    const my   = (e.clientY - rect.top) / rect.height;

    const found = vessels.find(v => {
      const [vx, vy] = project(v.latitude, v.longitude, 1, 1);
      return Math.abs(vx - mx) < 0.025 && Math.abs(vy - my) < 0.025;
    }) ?? null;

    setHovered(found);
    if (found) setTooltip({ x: e.clientX - rect.left + 12, y: e.clientY - rect.top - 10 });
  };

  return (
    <div className={clsx("relative", className)}>
      <canvas
        ref={canvasRef}
        style={{ height, display: "block", width: "100%", cursor: "crosshair" }}
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setHovered(null)}
      />
      {hovered && (
        <div
          className="absolute z-10 bg-[#152229] border border-[#223545] rounded-md px-3 py-2 text-xs text-slate-300 pointer-events-none max-w-[200px]"
          style={{ left: tooltip.x, top: tooltip.y }}
        >
          <div className="font-bold text-white mb-1">{hovered.vessel_name ?? hovered.mmsi}</div>
          <div className="text-[10px] space-y-0.5">
            <div>Type: <span className="text-slate-400">{hovered.vessel_type ?? "—"}</span></div>
            <div>Cargo: <span className="text-slate-400">{hovered.commodity ?? "—"}</span></div>
            <div>Dest: <span className="text-slate-400">{hovered.destination ?? "—"}</span></div>
            {hovered.near_chokepoint && (
              <div className="text-amber-400">⚠ Near {hovered.near_chokepoint}</div>
            )}
            {hovered.is_at_risk && <div className="text-red-400 font-bold">🔴 AT RISK</div>}
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="flex flex-wrap gap-4 mt-2 text-[10px] text-slate-500">
        {Object.entries(COMMODITY_COLORS).map(([k, v]) => (
          <span key={k} className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: v }} />
            {k}
          </span>
        ))}
        <span className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0" />
          at risk
        </span>
      </div>
    </div>
  );
}
