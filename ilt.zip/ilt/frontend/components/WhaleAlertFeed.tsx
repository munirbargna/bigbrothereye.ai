/**
 * components/WhaleAlertFeed.tsx
 * Feed real-time segnali whale con animazione ingresso.
 */

"use client";

import { clsx } from "clsx";
import { TrendingUp, TrendingDown, Zap } from "lucide-react";
import { type WhaleAlert } from "@/hooks/useLivePrices";

interface Props {
  alerts: WhaleAlert[];
}

const SIGNAL_LABELS: Record<string, string> = {
  dark_pool_block:  "Dark Pool",
  vwap_deviation:   "VWAP Dev.",
  isolation_forest: "AI Anomaly",
  options_flow:     "Options Flow",
};

export function WhaleAlertFeed({ alerts }: Props) {
  if (alerts.length === 0) {
    return (
      <div className="flex items-center justify-center h-32 text-sm text-slate-600">
        In attesa di segnali whale…
      </div>
    );
  }

  return (
    <div className="divide-y divide-[#1a2b35]">
      {alerts.map((a, i) => {
        const isLong   = a.direction === "LONG";
        const strength = Math.round(a.strength * 100);

        return (
          <div
            key={a.id}
            className={clsx(
              "flex items-center gap-3 px-3 py-2.5 text-sm",
              i === 0 && "animate-in fade-in slide-in-from-top-2 duration-300"
            )}
          >
            {/* Direction icon */}
            <div className={clsx(
              "flex items-center justify-center w-7 h-7 rounded flex-shrink-0",
              isLong ? "bg-emerald-900/50 text-emerald-400" : "bg-red-900/50 text-red-400"
            )}>
              {isLong ? <TrendingUp size={14} /> : <TrendingDown size={14} />}
            </div>

            {/* Asset + type */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white">{a.asset}</span>
                <span className={clsx(
                  "text-[10px] px-1.5 py-0.5 rounded font-medium",
                  isLong
                    ? "bg-emerald-900/40 text-emerald-400 border border-emerald-800/60"
                    : "bg-red-900/40 text-red-400 border border-red-800/60"
                )}>
                  {a.direction}
                </span>
              </div>
              <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
                <Zap size={10} />
                {SIGNAL_LABELS[a.signal_type] ?? a.signal_type}
              </div>
            </div>

            {/* Strength bar */}
            <div className="flex flex-col items-end gap-1 w-16 flex-shrink-0">
              <span className={clsx(
                "text-xs font-bold",
                strength >= 80 ? "text-amber-400"
                  : strength >= 60 ? "text-emerald-400"
                  : "text-slate-400"
              )}>
                {strength}%
              </span>
              <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={clsx(
                    "h-full rounded-full transition-all duration-500",
                    strength >= 80 ? "bg-amber-400" : isLong ? "bg-emerald-400" : "bg-red-400"
                  )}
                  style={{ width: `${strength}%` }}
                />
              </div>
            </div>

            {/* Time */}
            <div className="text-[10px] text-slate-600 w-12 text-right flex-shrink-0">
              {new Date(a.ts).toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
