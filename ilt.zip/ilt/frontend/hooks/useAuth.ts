/**
 * hooks/useAuth.ts
 * Zustand store per stato di autenticazione.
 */

"use client";

import { create } from "zustand";
import { authApi, setAccessToken, type UserResponse } from "@/lib/api";

interface AuthState {
  user:       UserResponse | null;
  loading:    boolean;
  error:      string | null;
  login:      (email: string, password: string) => Promise<void>;
  logout:     () => Promise<void>;
  loadUser:   () => Promise<void>;
  clearError: () => void;
}

export const useAuth = create<AuthState>((set) => ({
  user:    null,
  loading: false,
  error:   null,

  login: async (email, password) => {
    set({ loading: true, error: null });
    try {
      const user = await authApi.login(email, password);
      set({ user, loading: false });
    } catch (e: any) {
      const msg = e?.response?.data?.detail ?? "Credenziali non valide";
      set({ error: msg, loading: false });
      throw e;
    }
  },

  logout: async () => {
    try { await authApi.logout(); } catch { /* ignora */ }
    setAccessToken(null);
    set({ user: null });
  },

  loadUser: async () => {
    set({ loading: true });
    try {
      const user = await authApi.me();
      set({ user, loading: false });
    } catch {
      set({ user: null, loading: false });
    }
  },

  clearError: () => set({ error: null }),
}));
