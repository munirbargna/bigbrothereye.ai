/**
 * hooks/useLivePrices.ts
 *
 * Hook React per il feed prezzi live via WebSocket.
 * Gestisce: connessione, reconnect esponenziale, snapshot iniziale,
 * aggiornamenti diff e whale alerts.
 *
 * Uso:
 *   const { prices, changes, whaleAlerts, status } = useLivePrices();
 */

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { createLiveWS, type LivePriceMessage } from "@/lib/api";

export type ConnectionStatus = "connecting" | "connected" | "disconnected" | "error";

export interface WhaleAlert {
  id:          string;
  asset:       string;
  direction:   "LONG" | "SHORT";
  strength:    number;
  signal_type: string;
  ts:          string;
}

interface UseLivePricesReturn {
  prices:      Record<string, number>;
  changes:     Record<string, number>;   // variazione % vs tick precedente
  whaleAlerts: WhaleAlert[];
  status:      ConnectionStatus;
  lastUpdate:  Date | null;
}

const MAX_RECONNECT_DELAY = 30_000;
const MAX_WHALE_ALERTS    = 20;

export function useLivePrices(): UseLivePricesReturn {
  const [prices,      setPrices]      = useState<Record<string, number>>({});
  const [changes,     setChanges]     = useState<Record<string, number>>({});
  const [whaleAlerts, setWhaleAlerts] = useState<WhaleAlert[]>([]);
  const [status,      setStatus]      = useState<ConnectionStatus>("connecting");
  const [lastUpdate,  setLastUpdate]  = useState<Date | null>(null);

  const wsRef           = useRef<WebSocket | null>(null);
  const reconnectDelay  = useRef(1_000);
  const reconnectTimer  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const mountedRef      = useRef(true);

  const connect = useCallback(() => {
    if (!mountedRef.current) return;
    setStatus("connecting");

    const ws = createLiveWS(
      (msg: LivePriceMessage) => {
        if (!mountedRef.current) return;

        if (msg.type === "snapshot" || msg.type === "price_update") {
          if (msg.prices && Object.keys(msg.prices).length > 0) {
            setPrices(prev => ({ ...prev, ...msg.prices }));
            setLastUpdate(new Date());
          }
          if (msg.changes) {
            setChanges(prev => ({ ...prev, ...msg.changes }));
          }
        }

        if (msg.type === "whale_alert") {
          const raw = msg as any;
          const alert: WhaleAlert = {
            id:          crypto.randomUUID(),
            asset:       raw.asset,
            direction:   raw.direction,
            strength:    raw.strength,
            signal_type: raw.signal_type,
            ts:          raw.ts ?? new Date().toISOString(),
          };
          setWhaleAlerts(prev => [alert, ...prev].slice(0, MAX_WHALE_ALERTS));
        }
      },
      () => {
        if (!mountedRef.current) return;
        setStatus("error");
        scheduleReconnect();
      }
    );

    ws.onopen = () => {
      if (!mountedRef.current) return;
      setStatus("connected");
      reconnectDelay.current = 1_000;  // reset delay su connessione riuscita
    };

    ws.onclose = () => {
      if (!mountedRef.current) return;
      setStatus("disconnected");
      scheduleReconnect();
    };

    wsRef.current = ws;
  }, []);

  const scheduleReconnect = useCallback(() => {
    if (!mountedRef.current) return;
    if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
    reconnectTimer.current = setTimeout(() => {
      reconnectDelay.current = Math.min(reconnectDelay.current * 2, MAX_RECONNECT_DELAY);
      connect();
    }, reconnectDelay.current);
  }, [connect]);

  useEffect(() => {
    mountedRef.current = true;
    connect();
    return () => {
      mountedRef.current = false;
      if (reconnectTimer.current) clearTimeout(reconnectTimer.current);
      wsRef.current?.close();
    };
  }, [connect]);

  return { prices, changes, whaleAlerts, status, lastUpdate };
}
