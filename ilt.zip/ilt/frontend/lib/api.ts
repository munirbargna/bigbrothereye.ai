/**
 * lib/api.ts
 * Client HTTP centralizzato. Tutte le chiamate al backend passano da qui.
 * Gestisce: base URL, JWT header, refresh automatico su 401, errori.
 */

import axios, { AxiosError, AxiosInstance, InternalAxiosRequestConfig } from "axios";

const BASE_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000/api/v1";
const WS_URL   = process.env.NEXT_PUBLIC_WS_URL  ?? "ws://localhost:8000/api/v1";

// ── Tipi ──────────────────────────────────────────────────────────────────────

export interface TokenResponse {
  access_token: string;
  token_type:   string;
  expires_in:   number;
}

export interface UserResponse {
  id:           string;
  email:        string;
  full_name:    string | null;
  is_active:    boolean;
  is_superuser: boolean;
  created_at:   string;
}

export interface PriceTickResponse {
  time:   string;
  asset:  string;
  price:  number;
  volume: number | null;
  source: string;
}

export interface OHLCVBar {
  time:        string;
  asset:       string;
  timeframe:   string;
  open:        number;
  high:        number;
  low:         number;
  close:       number;
  volume:      number | null;
}

export interface AssetSnapshot {
  asset:            string;
  price:            number;
  change_pct_24h:   number | null;
  change_pct_7d:    number | null;
  ohlcv_1h:         OHLCVBar[];
  whale_signals:    WhaleSignal[];
  last_updated:     string;
}

export interface WhaleSignal {
  time:                string;
  signal_id:           string;
  asset:               string;
  direction:           "LONG" | "SHORT" | "NEUTRAL";
  strength:            number;
  signal_type:         string;
  z_score:             number | null;
  notional_usd:        number | null;
  vwap_deviation_pct:  number | null;
  whale_profile_id:    string | null;
}

export interface VesselPosition {
  time:             string;
  mmsi:             string;
  vessel_name:      string | null;
  vessel_type:      string | null;
  latitude:         number;
  longitude:        number;
  speed:            number | null;
  commodity:        string | null;
  destination:      string | null;
  near_chokepoint:  string | null;
  is_at_risk:       boolean;
}

export interface WatchlistResponse {
  id:         string;
  name:       string;
  assets:     string[];
  is_default: boolean;
  created_at: string;
}

export interface AlertResponse {
  id:          string;
  asset:       string;
  condition:   string;
  threshold:   number;
  is_active:   boolean;
  triggered_at: string | null;
  created_at:  string;
}

export interface LivePriceMessage {
  type:    "price_update" | "snapshot" | "whale_alert" | "pong";
  ts:      string;
  prices:  Record<string, number>;
  changes: Record<string, number>;
}

// ── Token store (in-memory — non localStorage per sicurezza) ──────────────────

let _accessToken: string | null = null;
let _refreshPromise: Promise<string | null> | null = null;

export function setAccessToken(token: string | null) { _accessToken = token; }
export function getAccessToken() { return _accessToken; }

// ── Axios instance ────────────────────────────────────────────────────────────

export const api: AxiosInstance = axios.create({
  baseURL:         BASE_URL,
  withCredentials: true,   // invia cookie refresh automaticamente
  headers:         { "Content-Type": "application/json" },
  timeout:         15_000,
});

// Inietta Bearer token
api.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  if (_accessToken) {
    config.headers.Authorization = `Bearer ${_accessToken}`;
  }
  return config;
});

// Refresh automatico su 401
api.interceptors.response.use(
  (res) => res,
  async (error: AxiosError) => {
    const original = error.config as InternalAxiosRequestConfig & { _retry?: boolean };
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      // Evita refresh paralleli multipli
      if (!_refreshPromise) {
        _refreshPromise = _refreshToken().finally(() => { _refreshPromise = null; });
      }
      const newToken = await _refreshPromise;
      if (newToken) {
        original.headers.Authorization = `Bearer ${newToken}`;
        return api(original);
      }
    }
    return Promise.reject(error);
  }
);

async function _refreshToken(): Promise<string | null> {
  try {
    const res = await axios.post<TokenResponse>(
      `${BASE_URL}/auth/refresh`,
      {},
      { withCredentials: true }
    );
    setAccessToken(res.data.access_token);
    return res.data.access_token;
  } catch {
    setAccessToken(null);
    return null;
  }
}

// ── Auth API ──────────────────────────────────────────────────────────────────

export const authApi = {
  register: (email: string, password: string, full_name?: string) =>
    api.post<UserResponse>("/auth/register", { email, password, full_name }),

  login: async (email: string, password: string): Promise<UserResponse> => {
    const res = await api.post<TokenResponse>("/auth/login", { email, password });
    setAccessToken(res.data.access_token);
    const me = await api.get<UserResponse>("/auth/me");
    return me.data;
  },

  logout: () => api.post("/auth/logout").finally(() => setAccessToken(null)),

  me: () => api.get<UserResponse>("/auth/me").then(r => r.data),
};

// ── Prices API ────────────────────────────────────────────────────────────────

export const pricesApi = {
  live: () =>
    api.get<Record<string, number>>("/prices/live").then(r => r.data),

  snapshot: (asset: string) =>
    api.get<AssetSnapshot>(`/prices/${asset}`).then(r => r.data),

  ohlcv: (asset: string, timeframe: "1m" | "1h" | "1d" = "1h", limit = 200) =>
    api.get<OHLCVBar[]>(`/prices/${asset}/ohlcv`, { params: { timeframe, limit } }).then(r => r.data),

  whaleSignals: (days = 2, asset?: string, min_strength = 0.5) =>
    api.get<WhaleSignal[]>("/prices/whale-signals/recent", {
      params: { days, asset, min_strength }
    }).then(r => r.data),

  vessels: (commodity?: string) =>
    api.get<VesselPosition[]>("/prices/vessels/latest", { params: { commodity } }).then(r => r.data),
};

// ── Watchlists API ────────────────────────────────────────────────────────────

export const watchlistsApi = {
  list: () =>
    api.get<WatchlistResponse[]>("/watchlists").then(r => r.data),

  create: (name: string, assets: string[]) =>
    api.post<WatchlistResponse>("/watchlists", { name, assets }).then(r => r.data),

  update: (id: string, data: { name?: string; assets?: string[] }) =>
    api.put<WatchlistResponse>(`/watchlists/${id}`, data).then(r => r.data),

  delete: (id: string) => api.delete(`/watchlists/${id}`),
};

// ── Alerts API ────────────────────────────────────────────────────────────────

export const alertsApi = {
  list: () =>
    api.get<AlertResponse[]>("/alerts").then(r => r.data),

  create: (asset: string, condition: string, threshold: number) =>
    api.post<AlertResponse>("/alerts", { asset, condition, threshold }).then(r => r.data),

  delete: (id: string) => api.delete(`/alerts/${id}`),
};

// ── Macro API ─────────────────────────────────────────────────────────────────

export const macroApi = {
  latest: () =>
    api.get<Record<string, number>>("/macro/latest").then(r => r.data),
};

// ── WebSocket ─────────────────────────────────────────────────────────────────

export function createLiveWS(
  onMessage: (msg: LivePriceMessage) => void,
  onError?: (e: Event) => void
): WebSocket {
  const token = _accessToken;
  const url = token
    ? `${WS_URL}/prices/ws/live?token=${token}`
    : `${WS_URL}/prices/ws/live`;

  const ws = new WebSocket(url);

  ws.onmessage = (e) => {
    try { onMessage(JSON.parse(e.data)); } catch { /* ignore malformed */ }
  };

  ws.onerror = onError ?? (() => {});

  // Keepalive ping ogni 25s
  const ping = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "ping" }));
    }
  }, 25_000);

  ws.onclose = () => clearInterval(ping);

  return ws;
}
