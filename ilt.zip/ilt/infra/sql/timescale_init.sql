-- infra/sql/timescale_init.sql
-- Eseguito automaticamente al primo avvio del container TimescaleDB.
-- Abilita le extension necessarie prima che Alembic crei le tabelle.

CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Aumenta il work_mem per query analitiche
ALTER SYSTEM SET work_mem = '256MB';
ALTER SYSTEM SET max_parallel_workers_per_gather = 4;
ALTER SYSTEM SET timescaledb.max_background_workers = 8;
SELECT pg_reload_conf();
