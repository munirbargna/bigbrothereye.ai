"""
services/whale_engine/detector.py

Algoritmi di rilevamento segnali istituzionali.

Tre metodi combinati:
1. Z-score sul volume: spike anomali vs media mobile 20-period
2. VWAP deviation: prezzo si discosta significativamente dal VWAP
3. Isolation Forest: anomalie multivariate su (price, volume, bid-ask spread)

Un segnale viene emesso quando almeno 2 metodi su 3 concordano
oppure quando uno dei metodi supera la soglia critica (z > 4.0).
"""

from dataclasses import dataclass, field
from datetime import datetime
import uuid

import numpy as np
from sklearn.ensemble import IsolationForest


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class PriceBar:
    time: datetime
    asset: str
    price: float
    volume: float
    bid: float | None = None
    ask: float | None = None

    @property
    def spread(self) -> float:
        if self.bid and self.ask and self.bid > 0:
            return (self.ask - self.bid) / self.bid
        return 0.0


@dataclass
class WhaleSignalResult:
    asset: str
    direction: str          # LONG | SHORT | NEUTRAL
    strength: float         # 0.0 – 1.0
    signal_type: str        # options_flow | dark_pool_block | vwap_deviation | isolation_forest
    z_score: float | None = None
    vwap_deviation_pct: float | None = None
    notional_usd: float | None = None
    metadata: dict = field(default_factory=dict)

    @property
    def signal_id(self) -> str:
        return str(uuid.uuid4())


# ── Z-Score detector ──────────────────────────────────────────────────────────

class ZScoreDetector:
    """
    Rileva spike di volume anomali usando z-score rolling.
    Finestra: 20 tick. Soglia: z > 2.5 (warning), z > 4.0 (critical).
    """

    WINDOW = 20
    THRESHOLD_WARN = 2.5
    THRESHOLD_CRITICAL = 4.0

    def detect(self, bars: list[PriceBar]) -> WhaleSignalResult | None:
        if len(bars) < self.WINDOW + 1:
            return None

        volumes = np.array([b.volume for b in bars])
        current_vol = volumes[-1]

        # Rolling window esclude il tick corrente
        window_vols = volumes[-(self.WINDOW + 1):-1]
        mean = np.mean(window_vols)
        std = np.std(window_vols)

        if std < 1e-9:
            return None

        z = (current_vol - mean) / std

        if abs(z) < self.THRESHOLD_WARN:
            return None

        # Direzione: se il prezzo sale con volume anomalo → LONG spike (accumulo)
        # Se scende → SHORT spike (distribuzione)
        price_change = bars[-1].price - bars[-2].price
        direction = "LONG" if price_change >= 0 else "SHORT"
        strength = min(1.0, (abs(z) - self.THRESHOLD_WARN) / (self.THRESHOLD_CRITICAL - self.THRESHOLD_WARN))

        return WhaleSignalResult(
            asset=bars[-1].asset,
            direction=direction,
            strength=round(strength, 3),
            signal_type="dark_pool_block",
            z_score=round(float(z), 3),
            notional_usd=current_vol * bars[-1].price,
            metadata={"volume": current_vol, "mean_vol": float(mean), "std_vol": float(std)},
        )


# ── VWAP Deviation detector ────────────────────────────────────────────────────

class VWAPDeviationDetector:
    """
    Rileva quando il prezzo si discosta significativamente dal VWAP.
    Un'istituzione che compra "above VWAP" con urgenza è un segnale LONG.
    Sopra VWAP + 0.5% = segnale. Soglia critica: 1.5%.
    """

    THRESHOLD_PCT = 0.5
    CRITICAL_PCT = 1.5

    def detect(self, bars: list[PriceBar]) -> WhaleSignalResult | None:
        if len(bars) < 5:
            return None

        # VWAP = sum(price * volume) / sum(volume) su finestra
        prices = np.array([b.price for b in bars])
        volumes = np.array([b.volume for b in bars])

        total_vol = np.sum(volumes)
        if total_vol < 1e-9:
            return None

        vwap = float(np.sum(prices * volumes) / total_vol)
        current_price = bars[-1].price
        deviation_pct = (current_price - vwap) / vwap * 100

        if abs(deviation_pct) < self.THRESHOLD_PCT:
            return None

        direction = "LONG" if deviation_pct > 0 else "SHORT"
        strength = min(1.0, abs(deviation_pct) / self.CRITICAL_PCT)

        return WhaleSignalResult(
            asset=bars[-1].asset,
            direction=direction,
            strength=round(strength, 3),
            signal_type="vwap_deviation",
            vwap_deviation_pct=round(deviation_pct, 4),
            metadata={"vwap": round(vwap, 4), "price": current_price},
        )


# ── Isolation Forest detector ─────────────────────────────────────────────────

class IsolationForestDetector:
    """
    Anomaly detection multivariata su (prezzo normalizzato, volume, spread).
    Modello ri-addestrato ogni N campioni con sliding window.
    contamination=0.05 → considera anomalo il 5% più estremo.
    """

    MIN_SAMPLES = 50
    RETRAIN_EVERY = 100
    _model: IsolationForest | None = None
    _sample_count: int = 0

    def _build_features(self, bars: list[PriceBar]) -> np.ndarray:
        """Feature matrix: [price_ret, log_volume, spread]"""
        prices = np.array([b.price for b in bars])
        volumes = np.array([b.volume for b in bars])
        spreads = np.array([b.spread for b in bars])

        # Returns normalizzati
        rets = np.diff(prices) / (prices[:-1] + 1e-9)
        log_vols = np.log1p(volumes[1:])
        sp = spreads[1:]

        return np.column_stack([rets, log_vols, sp])

    def fit(self, bars: list[PriceBar]) -> None:
        if len(bars) < self.MIN_SAMPLES:
            return
        X = self._build_features(bars)
        self._model = IsolationForest(
            n_estimators=100,
            contamination=0.05,
            random_state=42,
            n_jobs=-1,
        )
        self._model.fit(X)
        self._sample_count = 0

    def detect(self, bars: list[PriceBar]) -> WhaleSignalResult | None:
        if len(bars) < self.MIN_SAMPLES:
            return None

        self._sample_count += 1
        if self._model is None or self._sample_count >= self.RETRAIN_EVERY:
            self.fit(bars)

        if self._model is None:
            return None

        X = self._build_features(bars[-2:])  # solo ultimo punto
        if len(X) < 1:
            return None

        score = float(self._model.score_samples(X[-1:].reshape(1, -1))[0])
        prediction = int(self._model.predict(X[-1:].reshape(1, -1))[0])

        if prediction != -1:  # -1 = anomalia
            return None

        # Score Isolation Forest: più negativo = più anomalo. Range tipico: -0.7 a -0.4
        strength = min(1.0, max(0.0, (-score - 0.4) / 0.3))

        price_change = bars[-1].price - bars[-2].price
        direction = "LONG" if price_change >= 0 else "SHORT"

        return WhaleSignalResult(
            asset=bars[-1].asset,
            direction=direction,
            strength=round(strength, 3),
            signal_type="isolation_forest",
            metadata={"if_score": round(score, 4)},
        )


# ── Combined detector ─────────────────────────────────────────────────────────

class WhaleDetector:
    """
    Combina i tre detector. Emette segnale se:
    - z-score critico (z > 4.0) — da solo sufficiente
    - almeno 2/3 detector concordano nella stessa direzione
    """

    def __init__(self) -> None:
        self.zscore = ZScoreDetector()
        self.vwap = VWAPDeviationDetector()
        self.iforest = IsolationForestDetector()

    def analyze(self, bars: list[PriceBar]) -> WhaleSignalResult | None:
        if not bars:
            return None

        results: list[WhaleSignalResult] = []

        z_res = self.zscore.detect(bars)
        v_res = self.vwap.detect(bars)
        if_res = self.iforest.detect(bars)

        # Z-score critico da solo basta
        if z_res and z_res.z_score and abs(z_res.z_score) >= ZScoreDetector.THRESHOLD_CRITICAL:
            return z_res

        for r in [z_res, v_res, if_res]:
            if r is not None:
                results.append(r)

        if len(results) < 2:
            return None

        # Verifica concordanza direzione
        directions = [r.direction for r in results]
        long_count = directions.count("LONG")
        short_count = directions.count("SHORT")

        if long_count < 2 and short_count < 2:
            return None  # non concordano

        dominant = "LONG" if long_count >= short_count else "SHORT"
        avg_strength = float(np.mean([r.strength for r in results]))

        # Usa il tipo del segnale più forte
        best = max(results, key=lambda r: r.strength)

        return WhaleSignalResult(
            asset=bars[-1].asset,
            direction=dominant,
            strength=round(avg_strength, 3),
            signal_type=best.signal_type,
            z_score=z_res.z_score if z_res else None,
            vwap_deviation_pct=v_res.vwap_deviation_pct if v_res else None,
            metadata={
                "detectors_triggered": len(results),
                "long_votes": long_count,
                "short_votes": short_count,
                **(best.metadata or {}),
            },
        )
