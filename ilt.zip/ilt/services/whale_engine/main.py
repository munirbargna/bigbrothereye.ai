"""
services/whale_engine/main.py

Entry point del Whale Engine.

Architettura:
    Redis Stream "prices" (prodotto da price_worker)
        ↓  XREADGROUP (at-least-once)
    WhaleDetector.analyze()
        ↓  segnale rilevato
    INSERT whale_signals (TimescaleDB)
    PUBLISH whale:broadcast (Redis → WebSocket fan-out)
    XACK (conferma consegna)

Il consumer group "whale-engine" garantisce che ogni messaggio
venga processato esattamente una volta anche con più repliche.
"""

import asyncio
import json
import os
import sys
import uuid
from collections import defaultdict
from datetime import datetime, timezone

import structlog

# ── Path setup (necessario come microservizio standalone) ─────────────────────
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from services.whale_engine.detector import PriceBar, WhaleDetector

log = structlog.get_logger("whale_engine")

STREAM_KEY = "stream:prices"
CONSUMER_GROUP = "whale-engine"
CONSUMER_NAME = f"whale-{os.getpid()}"
BLOCK_MS = 5000          # attende fino a 5s per nuovi messaggi
MAX_PENDING_BEFORE_CLAIM = 30_000  # rivendica messaggi stuck dopo 30s


class WhaleEngineRunner:
    def __init__(self) -> None:
        self.detector = WhaleDetector()
        # Sliding window di PriceBars per asset: asset → [PriceBar, ...]
        self._bars: defaultdict[str, list[PriceBar]] = defaultdict(list)
        self._window_size = 100  # mantieni gli ultimi 100 tick per asset

        self._redis = None
        self._ts_session_factory = None

    async def setup(self) -> None:
        """Inizializza connessioni Redis e TimescaleDB."""
        from app.core.config import settings
        from app.core.logging import setup_logging
        from app.db.session import TimescaleSessionMaker

        setup_logging()

        import redis.asyncio as aioredis
        self._redis = aioredis.from_url(
            settings.redis_url_str,
            encoding="utf-8",
            decode_responses=True,
        )
        await self._redis.ping()

        self._ts_session_factory = TimescaleSessionMaker

        # Crea consumer group se non esiste
        try:
            await self._redis.xgroup_create(
                STREAM_KEY, CONSUMER_GROUP, id="0", mkstream=True
            )
            log.info("whale.consumer_group_created", group=CONSUMER_GROUP)
        except Exception as e:
            if "BUSYGROUP" in str(e):
                log.info("whale.consumer_group_exists", group=CONSUMER_GROUP)
            else:
                raise

        log.info("whale.ready", consumer=CONSUMER_NAME, stream=STREAM_KEY)

    async def run(self) -> None:
        """Loop principale: legge dal stream, analizza, emette segnali."""
        log.info("whale.starting_main_loop")
        try:
            while True:
                await self._process_batch()
                await self._reclaim_pending()
        except asyncio.CancelledError:
            log.info("whale.shutdown")
        except Exception as e:
            log.error("whale.fatal_error", error=str(e))
            raise

    async def _process_batch(self) -> None:
        """Legge un batch di messaggi dallo stream e li processa."""
        messages = await self._redis.xreadgroup(
            groupname=CONSUMER_GROUP,
            consumername=CONSUMER_NAME,
            streams={STREAM_KEY: ">"},  # ">" = solo nuovi messaggi
            count=50,
            block=BLOCK_MS,
        )

        if not messages:
            return

        for _stream, entries in messages:
            for msg_id, fields in entries:
                try:
                    await self._handle_message(fields)
                    await self._redis.xack(STREAM_KEY, CONSUMER_GROUP, msg_id)
                except Exception as e:
                    log.error("whale.message_failed", msg_id=msg_id, error=str(e))

    async def _handle_message(self, fields: dict) -> None:
        """
        Processa un singolo tick price_update.
        Formato atteso: {"type": "price_update", "prices": "{...}", "ts": "..."}
        """
        msg_type = fields.get("type", "")
        if msg_type != "price_update":
            return

        try:
            prices: dict[str, float] = json.loads(fields.get("prices", "{}"))
            ts_str = fields.get("ts", "")
            ts = datetime.fromisoformat(ts_str) if ts_str else datetime.now(timezone.utc)
        except (json.JSONDecodeError, ValueError):
            return

        signals_to_save = []

        for asset, price in prices.items():
            # Aggiorna sliding window
            bar = PriceBar(
                time=ts,
                asset=asset,
                price=price,
                volume=float(fields.get(f"vol_{asset}", 1000.0)),
            )
            window = self._bars[asset]
            window.append(bar)
            if len(window) > self._window_size:
                window.pop(0)

            # Analizza
            if len(window) >= 20:
                signal = self.detector.analyze(window)
                if signal:
                    signals_to_save.append((ts, signal))
                    log.info(
                        "whale.signal_detected",
                        asset=asset,
                        direction=signal.direction,
                        strength=signal.strength,
                        type=signal.signal_type,
                    )

        if signals_to_save:
            await self._persist_signals(signals_to_save)

    async def _persist_signals(self, signals: list[tuple[datetime, any]]) -> None:
        """Salva i segnali su TimescaleDB e pubblica su Redis."""
        from app.models.market import WhaleSignal
        from sqlalchemy import insert

        rows = []
        for ts, sig in signals:
            rows.append({
                "time":               ts,
                "signal_id":          sig.signal_id,
                "asset":              sig.asset,
                "direction":          sig.direction,
                "strength":           sig.strength,
                "signal_type":        sig.signal_type,
                "z_score":            sig.z_score,
                "notional_usd":       sig.notional_usd,
                "vwap_deviation_pct": sig.vwap_deviation_pct,
                "metadata":           sig.metadata or {},
                "whale_profile_id":   None,
            })

        async with self._ts_session_factory() as session:
            await session.execute(
                insert(WhaleSignal)
                .values(rows)
                .on_conflict_do_nothing(index_elements=["time", "signal_id"])
            )
            await session.commit()

        # Pubblica alert su WebSocket
        for _, sig in signals:
            payload = json.dumps({
                "type":        "whale_alert",
                "asset":       sig.asset,
                "direction":   sig.direction,
                "strength":    sig.strength,
                "signal_type": sig.signal_type,
                "z_score":     sig.z_score,
                "ts":          datetime.now(timezone.utc).isoformat(),
            })
            await self._redis.publish("whale:broadcast", payload)

    async def _reclaim_pending(self) -> None:
        """
        Rivendica messaggi pending da altri consumer che sono morti.
        Eseguito ogni 100 iterazioni circa.
        """
        try:
            pending = await self._redis.xpending(STREAM_KEY, CONSUMER_GROUP)
            if pending.get("pending", 0) > 0:
                idle_msgs = await self._redis.xautoclaim(
                    STREAM_KEY, CONSUMER_GROUP, CONSUMER_NAME,
                    min_idle_time=MAX_PENDING_BEFORE_CLAIM,
                    start_id="0-0",
                    count=10,
                )
                if idle_msgs and idle_msgs[1]:
                    log.warning("whale.reclaimed_messages", count=len(idle_msgs[1]))
        except Exception:
            pass  # xautoclaim richiede Redis 7+ — non critico


# ── Entry point ───────────────────────────────────────────────────────────────

async def main() -> None:
    runner = WhaleEngineRunner()
    await runner.setup()
    await runner.run()


if __name__ == "__main__":
    asyncio.run(main())
