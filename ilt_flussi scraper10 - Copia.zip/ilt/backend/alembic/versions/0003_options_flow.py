"""
options_flow_hypertable

Revision ID: 0003
Revises: 0002
Create Date: 2026-03-15 00:00:00

Crea la hypertable options_flow su TimescaleDB per i dati
provenienti dal Blackbox Scraper.

Schema:
    timestamp    — quando è arrivato il flow
    symbol       — ticker (es: NVDA, SPY)
    strike       — strike price
    expiration   — data scadenza opzione
    option_type  — CALL | PUT
    premium      — valore totale del premio in USD
    flow_type    — SWEEP | BLOCK | SPLIT
    sentiment    — BULLISH | BEARISH | NEUTRAL
    size         — numero di contratti
    open_interest — OI al momento del flow
    implied_vol  — IV dell'opzione
    underlying_price — prezzo sottostante al momento del flow
    source       — "blackbox" | "manual"
    raw_data     — payload JSON grezzo per audit

Policies:
    Compression: chunk > 7 giorni
    Retention:   1 anno (options data ha valore tattico breve)
"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0003"
down_revision: Union[str, None] = "0002"
branch_labels: Union[str, Sequence[str], None] = ("timescale",)
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    # ── OPTIONS FLOW ──────────────────────────────────────────────────────
    op.create_table(
        "options_flow",
        sa.Column("timestamp",        sa.DateTime(timezone=True), nullable=False),
        sa.Column("flow_id",          sa.String(36),  nullable=False),
        sa.Column("symbol",           sa.String(20),  nullable=False),
        sa.Column("strike",           sa.Numeric(precision=12, scale=2), nullable=False),
        sa.Column("expiration",       sa.Date(), nullable=False),
        sa.Column("option_type",      sa.String(4),   nullable=False,
                  comment="CALL | PUT"),
        sa.Column("premium",          sa.Numeric(precision=18, scale=2), nullable=False,
                  comment="Valore totale premio in USD"),
        sa.Column("flow_type",        sa.String(10),  nullable=False,
                  comment="SWEEP | BLOCK | SPLIT"),
        sa.Column("sentiment",        sa.String(10),  nullable=False,
                  comment="BULLISH | BEARISH | NEUTRAL"),
        sa.Column("size",             sa.Integer(), nullable=True,
                  comment="Numero contratti"),
        sa.Column("open_interest",    sa.Integer(), nullable=True),
        sa.Column("implied_vol",      sa.Float(),   nullable=True,
                  comment="Implied volatility 0.0–5.0"),
        sa.Column("underlying_price", sa.Numeric(precision=18, scale=4), nullable=True),
        sa.Column("days_to_expiry",   sa.SmallInteger(), nullable=True,
                  comment="0 = 0DTE, 1 = 1DTE, etc."),
        sa.Column("is_otm",           sa.Boolean(), server_default="false",
                  comment="Out of the money al momento del flow"),
        sa.Column("source",           sa.String(20), nullable=False,
                  server_default="blackbox"),
        sa.Column("correlated_signal_id", sa.String(36), nullable=True,
                  comment="Se correlato a un whale_signal esistente"),
        sa.Column("strength_boost",   sa.Float(), nullable=True,
                  comment="Incremento strength applicato se correlato"),
        sa.Column("raw_data",         postgresql.JSONB(), nullable=False,
                  server_default="{}",
                  comment="Payload grezzo per audit e replay"),
        sa.Column("discord_sent",     sa.Boolean(), server_default="false",
                  comment="True se notifica Discord già inviata"),
        sa.PrimaryKeyConstraint("timestamp", "flow_id"),
    )

    # ── Converti in hypertable ────────────────────────────────────────────
    op.execute("""
        SELECT create_hypertable(
            'options_flow', 'timestamp',
            chunk_time_interval => INTERVAL '1 day',
            if_not_exists => TRUE
        )
    """)

    # ── Indici strategici ─────────────────────────────────────────────────
    # Query comune: "tutti i flow BULLISH di NVDA nelle ultime 24h"
    op.execute("""
        CREATE INDEX ix_options_flow_symbol_ts
        ON options_flow (symbol, timestamp DESC)
    """)
    # Query per alert Discord pending
    op.execute("""
        CREATE INDEX ix_options_flow_discord_pending
        ON options_flow (discord_sent, timestamp DESC)
        WHERE discord_sent = false
    """)
    # Query per "Correct Flows" (premium alto + sweep + short-term)
    op.execute("""
        CREATE INDEX ix_options_flow_premium
        ON options_flow (premium DESC, timestamp DESC)
        WHERE premium >= 100000
    """)

    # ── Compression policy (dopo 7 giorni) ────────────────────────────────
    op.execute("""
        ALTER TABLE options_flow SET (
            timescaledb.compress,
            timescaledb.compress_segmentby = 'symbol',
            timescaledb.compress_orderby   = 'timestamp DESC'
        )
    """)
    op.execute("""
        SELECT add_compression_policy('options_flow', INTERVAL '7 days')
    """)

    # ── Retention policy (1 anno) ─────────────────────────────────────────
    op.execute("""
        SELECT add_retention_policy('options_flow', INTERVAL '1 year')
    """)

    # ── Continuous Aggregate: flow summary giornaliero per simbolo ─────────
    # Utile per Grafana: "quanti sweep bullish per simbolo oggi?"
    op.execute("""
        CREATE MATERIALIZED VIEW options_flow_daily
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 day', timestamp)  AS bucket,
            symbol,
            option_type,
            sentiment,
            flow_type,
            count(*)                          AS flow_count,
            sum(premium)                      AS total_premium,
            avg(premium)                      AS avg_premium,
            max(premium)                      AS max_premium,
            avg(implied_vol)                  AS avg_iv
        FROM options_flow
        GROUP BY bucket, symbol, option_type, sentiment, flow_type
        WITH NO DATA
    """)
    op.execute("""
        SELECT add_continuous_aggregate_policy('options_flow_daily',
            start_offset    => INTERVAL '3 days',
            end_offset      => INTERVAL '1 hour',
            schedule_interval => INTERVAL '1 hour'
        )
    """)


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS options_flow_daily CASCADE")
    op.execute("DROP TABLE IF EXISTS options_flow CASCADE")
