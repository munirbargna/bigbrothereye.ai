"""
0003_options_flow_hypertable

Revision ID: 0003
Revises: 0002
Create Date: 2026-03-15

Hypertable options_flow su TimescaleDB.
Nomi campi allineati al modello ORM market.py::OptionsFlow.
"""

from typing import Sequence, Union
import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0003"
down_revision: Union[str, None] = "0002"
branch_labels: Union[str, Sequence[str], None] = ("timescale",)
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:

    op.create_table(
        "options_flow",

        # ── PK ────────────────────────────────────────────────────────────
        sa.Column("timestamp",    sa.DateTime(timezone=True), nullable=False),
        sa.Column("flow_id",      sa.String(36),              nullable=False),

        # ── Strumento ─────────────────────────────────────────────────────
        sa.Column("symbol",       sa.String(20),  nullable=False),
        sa.Column("strike",       sa.Numeric(12, 2), nullable=False),
        sa.Column("expiration",   sa.DateTime(timezone=True), nullable=False),
        sa.Column("option_type",  sa.String(4),   nullable=False,
                  comment="CALL | PUT"),

        # ── Dati finanziari ───────────────────────────────────────────────
        sa.Column("premium",          sa.Numeric(18, 2), nullable=False),
        sa.Column("flow_type",        sa.String(10),  nullable=False,
                  comment="SWEEP | BLOCK | SPLIT"),
        sa.Column("sentiment",        sa.String(10),  nullable=False,
                  comment="BULLISH | BEARISH | NEUTRAL"),
        sa.Column("size",             sa.Integer,     nullable=True),
        sa.Column("open_interest",    sa.Integer,     nullable=True),
        sa.Column("implied_vol",      sa.Float,       nullable=True),
        sa.Column("underlying_price", sa.Numeric(18, 4), nullable=True),
        sa.Column("days_to_expiry",   sa.SmallInteger, nullable=True),
        sa.Column("is_otm",           sa.Boolean,     nullable=False,
                  server_default="false"),

        # ── Correlazione ──────────────────────────────────────────────────
        sa.Column("source",               sa.String(20),  nullable=False,
                  server_default="'blackbox'"),
        sa.Column("correlated_signal_id", sa.String(36),  nullable=True),
        sa.Column("strength_boost",       sa.Float,       nullable=True),
        sa.Column("raw_data",             postgresql.JSONB(), nullable=False,
                  server_default="'{}'"),

        # ── Stato notifica ────────────────────────────────────────────────
        sa.Column("discord_sent", sa.Boolean, nullable=False,
                  server_default="false"),

        sa.PrimaryKeyConstraint("timestamp", "flow_id"),
    )

    # ── Hypertable ────────────────────────────────────────────────────────
    op.execute("""
        SELECT create_hypertable(
            'options_flow', 'timestamp',
            chunk_time_interval => INTERVAL '1 day',
            if_not_exists       => TRUE
        )
    """)

    # ── Indici ────────────────────────────────────────────────────────────
    op.execute("""
        CREATE INDEX ix_options_flow_symbol_ts
        ON options_flow (symbol, timestamp DESC)
    """)
    op.execute("""
        CREATE INDEX ix_options_flow_premium
        ON options_flow (premium DESC, timestamp DESC)
    """)
    op.execute("""
        CREATE INDEX ix_options_flow_correct
        ON options_flow (discord_sent, timestamp DESC)
        WHERE discord_sent = false
          AND premium >= 100000
    """)

    # ── Compression (stesso pattern di price_ticks) ───────────────────────
    op.execute("""
        ALTER TABLE options_flow SET (
            timescaledb.compress,
            timescaledb.compress_segmentby = 'symbol',
            timescaledb.compress_orderby   = 'timestamp DESC'
        )
    """)
    op.execute("""
        SELECT add_compression_policy('options_flow', INTERVAL '7 days')
    """)

    # ── Retention 1 anno ──────────────────────────────────────────────────
    op.execute("""
        SELECT add_retention_policy('options_flow', INTERVAL '1 year')
    """)

    # ── Continuous aggregate: riepilogo orario per symbol ─────────────────
    op.execute("""
        CREATE MATERIALIZED VIEW options_flow_1h
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 hour', timestamp)   AS bucket,
            symbol,
            option_type,
            sentiment,
            count(*)                           AS flow_count,
            sum(premium)                       AS total_premium,
            avg(implied_vol)                   AS avg_iv,
            count(*) FILTER (WHERE premium >= 100000
                              AND flow_type = 'SWEEP'
                              AND days_to_expiry <= 1) AS correct_count
        FROM options_flow
        GROUP BY bucket, symbol, option_type, sentiment
        WITH NO DATA
    """)
    op.execute("""
        SELECT add_continuous_aggregate_policy('options_flow_1h',
            start_offset      => INTERVAL '2 hours',
            end_offset        => INTERVAL '1 hour',
            schedule_interval => INTERVAL '30 minutes'
        )
    """)


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS options_flow_1h CASCADE")
    op.execute("DROP TABLE IF EXISTS options_flow CASCADE")
