"""
app/api/v1/endpoints/flows.py

Endpoint per options flow e notifiche Discord:
    GET  /flows/options              Flow recenti (con filtro Correct)
    GET  /flows/options/{symbol}     Flow per simbolo
    POST /flows/test-discord         Invia test embed Discord (solo superuser)
    GET  /flows/stats                Statistiche aggregate per simbolo/giorno
"""

from datetime import datetime, timedelta, timezone

import structlog
from fastapi import APIRouter, HTTPException, Query, status
from pydantic import BaseModel
from sqlalchemy import func, select, text

from app.api.v1.deps import AppSession, CurrentSuperuser, TimescaleSession
from app.models.market import OptionsFlow

log = structlog.get_logger(__name__)
router = APIRouter(prefix="/flows", tags=["options flow"])


# ── Schemas ───────────────────────────────────────────────────────────────────

class OptionsFlowResponse(BaseModel):
    model_config = {"from_attributes": True}
    timestamp:            datetime
    flow_id:              str
    symbol:               str
    strike:               float
    expiration:           datetime
    option_type:          str
    premium:              float
    flow_type:            str
    sentiment:            str
    size:                 int | None
    implied_vol:          float | None
    underlying_price:     float | None
    days_to_expiry:       int | None
    is_otm:               bool
    correlated_signal_id: str | None
    strength_boost:       float | None
    discord_sent:         bool


class DiscordTestPayload(BaseModel):
    message: str = "Test notifica da ILT Market Intelligence"
    level:   str = "info"  # info | warning | error


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/options", response_model=list[OptionsFlowResponse])
async def list_options_flows(
    ts: TimescaleSession,
    hours:       int   = Query(default=24,  ge=1,  le=168),
    correct_only: bool = Query(default=False, description="Solo Correct Flows (premium≥100k + SWEEP + 0/1DTE)"),
    symbol:      str | None = Query(default=None),
    sentiment:   str | None = Query(default=None, pattern="^(BULLISH|BEARISH|NEUTRAL)$"),
    limit:       int  = Query(default=50,  ge=1,  le=500),
) -> list[OptionsFlow]:
    since = datetime.now(timezone.utc) - timedelta(hours=hours)

    q = (
        select(OptionsFlow)
        .where(OptionsFlow.timestamp >= since)
        .order_by(OptionsFlow.timestamp.desc())
        .limit(limit)
    )

    if symbol:
        q = q.where(OptionsFlow.symbol == symbol.upper())
    if sentiment:
        q = q.where(OptionsFlow.sentiment == sentiment.upper())
    if correct_only:
        q = q.where(
            OptionsFlow.premium  >= 100_000,
            OptionsFlow.flow_type == "SWEEP",
            OptionsFlow.days_to_expiry.in_([0, 1]),
        )

    result = await ts.execute(q)
    return list(result.scalars().all())


@router.get("/options/{symbol}", response_model=list[OptionsFlowResponse])
async def flows_by_symbol(
    symbol: str,
    ts:     TimescaleSession,
    days:   int = Query(default=7, ge=1, le=30),
    limit:  int = Query(default=100, ge=1, le=500),
) -> list[OptionsFlow]:
    since = datetime.now(timezone.utc) - timedelta(days=days)
    result = await ts.execute(
        select(OptionsFlow)
        .where(OptionsFlow.symbol == symbol.upper(), OptionsFlow.timestamp >= since)
        .order_by(OptionsFlow.timestamp.desc())
        .limit(limit)
    )
    return list(result.scalars().all())


@router.get("/stats", summary="Aggregati giornalieri per simbolo")
async def flow_stats(
    ts:    TimescaleSession,
    days:  int = Query(default=7, ge=1, le=30),
) -> list[dict]:
    """Legge dalla continuous aggregate options_flow_1h."""
    since = datetime.now(timezone.utc) - timedelta(days=days)
    result = await ts.execute(text("""
        SELECT
            bucket::date AS date,
            symbol,
            option_type,
            sentiment,
            flow_type,
            flow_count,
            total_premium,
            avg_premium,
            max_premium,
            avg_iv
        FROM options_flow_1h
        WHERE bucket >= :since
        ORDER BY bucket DESC, total_premium DESC
        LIMIT 200
    """), {"since": since})
    return [dict(r) for r in result.mappings().all()]


@router.post(
    "/test-discord",
    status_code=status.HTTP_200_OK,
    summary="Invia messaggio di test a Discord (solo superuser)",
)
async def test_discord(
    body: DiscordTestPayload,
    _: CurrentSuperuser,
) -> dict:
    from app.services.discord_service import send_system_alert

    sent = await send_system_alert(
        title="Test ILT Market Intelligence",
        message=body.message,
        level=body.level,
    )

    if not sent:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Discord webhook non raggiungibile. "
                   "Verifica DISCORD_WEBHOOK_URL nel .env",
        )

    return {"sent": True, "message": body.message}
