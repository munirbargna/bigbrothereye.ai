"""
app/services/discord_service.py

Service per notifiche Discord via Incoming Webhook.
Usa Rich Embeds con colori semantici e link diretti alla dashboard.

Flusso:
    WhaleEngine rileva Correct Flow
        ↓
    discord_service.send_options_flow_alert(flow, signal?)
        ↓
    POST https://discord.com/api/webhooks/{id}/{token}
        ↓
    Aggiorna options_flow.discord_sent = True

Formato embed:
    ┌─────────────────────────────────────┐
    │ 🟢 BULLISH SWEEP · NVDA             │  ← colore verde/rosso
    │ ────────────────────────────────── │
    │ Strike: $900 | Exp: 15 Mar (0DTE)  │
    │ Premium: $420,000 · Size: 1,200    │
    │ IV: 82% | Underlying: $887.40      │
    │ ──────────────────────────────────  │
    │ Whale strength: 0.89 ████████░░    │
    │ Type: dark_pool_block + SWEEP corr │
    │ 🔗 View NVDA on ILT Dashboard      │
    └─────────────────────────────────────┘
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING

import httpx
import structlog

from app.core.config import settings

if TYPE_CHECKING:
    from app.models.market import OptionsFlow
    from app.schemas.market import WhaleSignalResponse

log = structlog.get_logger(__name__)

# ── Colori Discord (intero decimale) ──────────────────────────────────────────
_COLOR_BULLISH = 0x00E5A0   # verde accent
_COLOR_BEARISH = 0xFF3D5A   # rosso
_COLOR_NEUTRAL = 0xF5A623   # amber


def _sentiment_color(sentiment: str) -> int:
    return {
        "BULLISH": _COLOR_BULLISH,
        "BEARISH": _COLOR_BEARISH,
    }.get(sentiment.upper(), _COLOR_NEUTRAL)


def _sentiment_emoji(sentiment: str) -> str:
    return {"BULLISH": "🟢", "BEARISH": "🔴"}.get(sentiment.upper(), "🟡")


def _dte_label(days: int | None) -> str:
    if days is None:
        return "—"
    if days == 0:
        return "0DTE ⚡"
    if days == 1:
        return "1DTE"
    return f"{days}d"


def _strength_bar(strength: float, length: int = 10) -> str:
    """Restituisce una barra ASCII tipo ████████░░ (0.0–1.0)."""
    filled = round(strength * length)
    return "█" * filled + "░" * (length - filled)


# ── Embed builder ─────────────────────────────────────────────────────────────

def build_options_flow_embed(
    flow: "OptionsFlow",
    signal: "WhaleSignalResponse | None" = None,
) -> dict:
    """
    Costruisce il payload JSON per un Discord Rich Embed.

    Args:
        flow:   OptionsFlow ORM instance (Correct Flow già validato)
        signal: WhaleSignalResponse opzionale se correlato al detector
    """
    sentiment = flow.sentiment.upper()
    emoji     = _sentiment_emoji(sentiment)
    color     = _sentiment_color(sentiment)

    premium_fmt = f"${float(flow.premium):,.0f}"
    strike_fmt  = f"${float(flow.strike):,.2f}"
    exp_fmt     = flow.expiration.strftime("%d %b %Y") if hasattr(flow.expiration, "strftime") else str(flow.expiration)
    dte_label   = _dte_label(flow.days_to_expiry)
    underlying  = f"${float(flow.underlying_price):,.2f}" if flow.underlying_price else "—"
    iv_fmt      = f"{float(flow.implied_vol)*100:.1f}%" if flow.implied_vol else "—"
    size_fmt    = f"{flow.size:,}" if flow.size else "—"

    dashboard_url = f"{settings.FRONTEND_BASE_URL}/asset/{flow.symbol}"

    # Campi embed
    fields = [
        {"name": "Symbol",    "value": f"**{flow.symbol}**",       "inline": True},
        {"name": "Type",      "value": f"{flow.option_type} · {flow.flow_type}", "inline": True},
        {"name": "Sentiment", "value": f"{emoji} {sentiment}",     "inline": True},
        {"name": "Strike",    "value": strike_fmt,                  "inline": True},
        {"name": "Expiry",    "value": f"{exp_fmt} ({dte_label})", "inline": True},
        {"name": "Premium",   "value": f"**{premium_fmt}**",        "inline": True},
        {"name": "Size",      "value": size_fmt,                    "inline": True},
        {"name": "IV",        "value": iv_fmt,                      "inline": True},
        {"name": "Underlying","value": underlying,                   "inline": True},
    ]

    # Sezione correlazione whale signal (se presente)
    if signal:
        strength_bar = _strength_bar(signal.strength)
        boost_txt    = (
            f" (+{flow.strength_boost:.2f} boost)" if flow.strength_boost else ""
        )
        fields.append({
            "name": "🐋 Whale Signal Correlation",
            "value": (
                f"`{strength_bar}` **{signal.strength:.2f}**{boost_txt}\n"
                f"Type: `{signal.signal_type}`"
                + (f" · Z-score: `{signal.z_score:.2f}`" if signal.z_score else "")
            ),
            "inline": False,
        })

    title = f"{emoji} {sentiment} {flow.option_type} — {flow.symbol}"

    return {
        "embeds": [{
            "title":       title,
            "color":       color,
            "fields":      fields,
            "url":         dashboard_url,
            "footer": {
                "text": f"ILT Market Intelligence · {datetime.now(timezone.utc).strftime('%H:%M:%S UTC')}",
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }],
        # Mention opzionale: decommentare per pingare un ruolo Discord
        # "content": "<@&ROLE_ID> Correct Flow rilevato!",
    }


# ── HTTP client singleton ─────────────────────────────────────────────────────

_http_client: httpx.AsyncClient | None = None


def _get_client() -> httpx.AsyncClient:
    global _http_client
    if _http_client is None or _http_client.is_closed:
        _http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(10.0),
            headers={"Content-Type": "application/json"},
        )
    return _http_client


# ── Public API ────────────────────────────────────────────────────────────────

async def send_options_flow_alert(
    flow: "OptionsFlow",
    signal: "WhaleSignalResponse | None" = None,
) -> bool:
    """
    Invia notifica Discord per un Correct Flow.

    Returns:
        True se inviato con successo, False altrimenti.
        Non solleva eccezioni — il chiamante non deve crashare per Discord.
    """
    if not settings.DISCORD_WEBHOOK_URL:
        log.debug("discord.skipped", reason="DISCORD_WEBHOOK_URL non configurato")
        return False

    payload = build_options_flow_embed(flow, signal)

    try:
        client = _get_client()
        resp = await client.post(settings.DISCORD_WEBHOOK_URL, json=payload)

        if resp.status_code in (200, 204):
            log.info(
                "discord.sent",
                symbol=flow.symbol,
                option_type=flow.option_type,
                premium=float(flow.premium),
                sentiment=flow.sentiment,
            )
            return True

        # Discord rate limit: 429
        if resp.status_code == 429:
            retry_after = resp.json().get("retry_after", 1.0)
            log.warning("discord.rate_limited", retry_after=retry_after)
            import asyncio
            await asyncio.sleep(float(retry_after))
            # Riprova una volta
            resp2 = await client.post(settings.DISCORD_WEBHOOK_URL, json=payload)
            return resp2.status_code in (200, 204)

        log.error(
            "discord.send_failed",
            status=resp.status_code,
            body=resp.text[:200],
        )
        return False

    except httpx.TimeoutException:
        log.warning("discord.timeout", symbol=flow.symbol)
        return False
    except Exception as e:
        log.error("discord.error", error=str(e), symbol=flow.symbol)
        return False


async def send_system_alert(title: str, message: str, level: str = "info") -> bool:
    """
    Notifica sistema generica (es: whale engine down, DB lag).
    Usata dall'admin endpoint e dai worker per alert operativi.
    """
    if not settings.DISCORD_WEBHOOK_URL:
        return False

    color_map = {"info": 0x29B6F6, "warning": 0xF5A623, "error": 0xFF3D5A}
    color = color_map.get(level, 0x29B6F6)

    payload = {
        "embeds": [{
            "title":     f"⚙️ {title}",
            "description": message,
            "color":     color,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "footer":    {"text": "ILT Market Intelligence · System Alert"},
        }]
    }

    try:
        client = _get_client()
        resp = await client.post(settings.DISCORD_WEBHOOK_URL, json=payload)
        return resp.status_code in (200, 204)
    except Exception as e:
        log.error("discord.system_alert_failed", error=str(e))
        return False


async def close_discord_client() -> None:
    """Chiudi il client HTTP — chiamare nello shutdown FastAPI."""
    global _http_client
    if _http_client and not _http_client.is_closed:
        await _http_client.aclose()
        _http_client = None
