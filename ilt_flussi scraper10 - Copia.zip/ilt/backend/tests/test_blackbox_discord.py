"""
tests/test_blackbox_discord.py

Test per:
  - validate_correct_flow() — logica filtro segnali ad alta confidenza
  - BlackboxFlowRow — validazione Pydantic scraper data
  - DiscordService — build embed + send (mock HTTP)
  - Flows API endpoint — lista e filtro options flow
"""

from datetime import date, datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


# ── validate_correct_flow ─────────────────────────────────────────────────────

class TestCorrectFlowValidation:
    """
    Un Correct Flow deve soddisfare TUTTI e TRE i criteri:
        1. premium >= $100,000
        2. flow_type == SWEEP
        3. dte <= 1  (0DTE o 1DTE)
    """

    def _fields(self, premium=150_000, flow_type="SWEEP", dte=0):
        return {
            "premium":   str(premium),
            "flow_type": flow_type,
            "dte":       str(dte),
        }

    def test_all_criteria_met(self):
        from services.whale_engine.main import validate_correct_flow
        assert validate_correct_flow(self._fields()) is True

    def test_premium_too_low(self):
        from services.whale_engine.main import validate_correct_flow
        assert validate_correct_flow(self._fields(premium=50_000)) is False

    def test_premium_at_boundary(self):
        from services.whale_engine.main import validate_correct_flow
        # Esattamente $100k → valido (>=)
        assert validate_correct_flow(self._fields(premium=100_000)) is True

    def test_not_a_sweep(self):
        from services.whale_engine.main import validate_correct_flow
        assert validate_correct_flow(self._fields(flow_type="BLOCK")) is False
        assert validate_correct_flow(self._fields(flow_type="SPLIT")) is False

    def test_dte_0_valid(self):
        from services.whale_engine.main import validate_correct_flow
        assert validate_correct_flow(self._fields(dte=0)) is True

    def test_dte_1_valid(self):
        from services.whale_engine.main import validate_correct_flow
        assert validate_correct_flow(self._fields(dte=1)) is True

    def test_dte_2_invalid(self):
        from services.whale_engine.main import validate_correct_flow
        assert validate_correct_flow(self._fields(dte=2)) is False

    def test_dte_30_invalid(self):
        from services.whale_engine.main import validate_correct_flow
        assert validate_correct_flow(self._fields(dte=30)) is False

    def test_missing_premium_is_false(self):
        from services.whale_engine.main import validate_correct_flow
        assert validate_correct_flow({"flow_type": "SWEEP", "dte": "0"}) is False

    def test_malformed_values_dont_crash(self):
        from services.whale_engine.main import validate_correct_flow
        result = validate_correct_flow({
            "premium":   "not_a_number",
            "flow_type": "SWEEP",
            "dte":       "zero",
        })
        assert result is False  # non solleva eccezione

    def test_uppercase_normalization(self):
        from services.whale_engine.main import validate_correct_flow
        # flow_type deve essere uppercase nel validator
        assert validate_correct_flow(self._fields(flow_type="sweep")) is False
        assert validate_correct_flow(self._fields(flow_type="SWEEP")) is True


# ── BlackboxFlowRow Pydantic validation ───────────────────────────────────────

class TestBlackboxFlowRow:

    def _valid(self, **kwargs):
        defaults = {
            "flow_id":     "abc123def456",
            "timestamp":   datetime.now(timezone.utc),
            "symbol":      "NVDA",
            "strike":      900.0,
            "expiration":  date.today(),
            "option_type": "CALL",
            "premium":     420_000.0,
            "flow_type":   "SWEEP",
            "sentiment":   "BULLISH",
            "dte":         0,
        }
        defaults.update(kwargs)
        from services.blackbox_scraper.scraper import BlackboxFlowRow
        return BlackboxFlowRow(**defaults)

    def test_valid_call(self):
        row = self._valid()
        assert row.symbol == "NVDA"
        assert row.option_type == "CALL"
        assert row.flow_type == "SWEEP"
        assert row.sentiment == "BULLISH"

    def test_symbol_uppercased(self):
        row = self._valid(symbol="nvda")
        assert row.symbol == "NVDA"

    def test_option_type_normalizes_c(self):
        row = self._valid(option_type="C")
        assert row.option_type == "CALL"

    def test_option_type_normalizes_p(self):
        row = self._valid(option_type="p")
        assert row.option_type == "PUT"

    def test_invalid_option_type_raises(self):
        import pytest
        from pydantic import ValidationError
        with pytest.raises(ValidationError):
            self._valid(option_type="FORWARD")

    def test_flow_type_normalizes_lowercase(self):
        row = self._valid(flow_type="sweep")
        assert row.flow_type == "SWEEP"

    def test_unknown_flow_type_defaults_to_block(self):
        row = self._valid(flow_type="UNKNOWN_TYPE")
        assert row.flow_type == "BLOCK"

    def test_sentiment_bullish_variants(self):
        for v in ["Bullish", "BULLISH", "bull", "VERY BULLISH"]:
            row = self._valid(sentiment=v)
            assert row.sentiment == "BULLISH"

    def test_sentiment_bearish_variants(self):
        for v in ["Bearish", "BEARISH", "VERY BEARISH"]:
            row = self._valid(sentiment=v)
            assert row.sentiment == "BEARISH"

    def test_neutral_fallback(self):
        row = self._valid(sentiment="unknown")
        assert row.sentiment == "NEUTRAL"

    def test_flow_id_deterministic(self):
        from services.blackbox_scraper.scraper import BlackboxFlowRow
        ts  = datetime(2026, 3, 15, 10, 30, tzinfo=timezone.utc)
        exp = date(2026, 3, 15)
        id1 = BlackboxFlowRow.compute_flow_id("NVDA", 900.0, exp, "CALL", ts, 420_000)
        id2 = BlackboxFlowRow.compute_flow_id("NVDA", 900.0, exp, "CALL", ts, 420_000)
        assert id1 == id2

    def test_flow_id_unique_for_different_inputs(self):
        from services.blackbox_scraper.scraper import BlackboxFlowRow
        ts  = datetime(2026, 3, 15, 10, 30, tzinfo=timezone.utc)
        exp = date(2026, 3, 15)
        id1 = BlackboxFlowRow.compute_flow_id("NVDA", 900.0, exp, "CALL", ts, 420_000)
        id2 = BlackboxFlowRow.compute_flow_id("AAPL", 200.0, exp, "PUT",  ts, 120_000)
        assert id1 != id2


# ── Discord embed builder ─────────────────────────────────────────────────────

class TestDiscordEmbedBuilder:

    def _mock_flow(self, sentiment="BULLISH", dte=0, premium=420_000.0,
                   flow_type="SWEEP", opt_type="CALL", symbol="NVDA"):
        flow = MagicMock()
        flow.symbol          = symbol
        flow.option_type     = opt_type
        flow.strike          = 900.0
        flow.expiration      = MagicMock()
        flow.expiration.strftime = lambda fmt: "15 Mar 2026"
        flow.premium         = premium
        flow.flow_type       = flow_type
        flow.sentiment       = sentiment
        flow.size            = 1200
        flow.implied_vol     = 0.82
        flow.underlying_price = 887.40
        flow.days_to_expiry  = dte
        flow.strength_boost  = None
        return flow

    def test_bullish_embed_color(self):
        from app.services.discord_service import build_options_flow_embed, _COLOR_BULLISH
        flow = self._mock_flow(sentiment="BULLISH")
        embed = build_options_flow_embed(flow)
        assert embed["embeds"][0]["color"] == _COLOR_BULLISH

    def test_bearish_embed_color(self):
        from app.services.discord_service import build_options_flow_embed, _COLOR_BEARISH
        flow = self._mock_flow(sentiment="BEARISH")
        embed = build_options_flow_embed(flow)
        assert embed["embeds"][0]["color"] == _COLOR_BEARISH

    def test_embed_title_contains_symbol(self):
        from app.services.discord_service import build_options_flow_embed
        flow = self._mock_flow(symbol="AAPL", sentiment="BEARISH", opt_type="PUT")
        embed = build_options_flow_embed(flow)
        title = embed["embeds"][0]["title"]
        assert "AAPL" in title
        assert "PUT" in title

    def test_embed_url_points_to_dashboard(self):
        from app.services.discord_service import build_options_flow_embed
        flow = self._mock_flow(symbol="NVDA")
        embed = build_options_flow_embed(flow)
        url = embed["embeds"][0]["url"]
        assert "/asset/NVDA" in url

    def test_0dte_label(self):
        from app.services.discord_service import _dte_label
        assert _dte_label(0) == "0DTE ⚡"
        assert _dte_label(1) == "1DTE"
        assert _dte_label(30) == "30d"
        assert _dte_label(None) == "—"

    def test_strength_bar_full(self):
        from app.services.discord_service import _strength_bar
        bar = _strength_bar(1.0)
        assert "░" not in bar
        assert bar == "█" * 10

    def test_strength_bar_empty(self):
        from app.services.discord_service import _strength_bar
        bar = _strength_bar(0.0)
        assert "█" not in bar

    def test_strength_bar_half(self):
        from app.services.discord_service import _strength_bar
        bar = _strength_bar(0.5)
        assert bar.count("█") == 5
        assert bar.count("░") == 5

    def test_embed_has_premium_field(self):
        from app.services.discord_service import build_options_flow_embed
        flow = self._mock_flow(premium=420_000)
        embed = build_options_flow_embed(flow)
        fields = embed["embeds"][0]["fields"]
        premium_field = next((f for f in fields if f["name"] == "Premium"), None)
        assert premium_field is not None
        assert "420,000" in premium_field["value"]

    def test_embed_with_whale_signal_adds_correlation(self):
        from app.services.discord_service import build_options_flow_embed
        flow   = self._mock_flow()
        signal = MagicMock()
        signal.strength    = 0.89
        signal.signal_type = "dark_pool_block"
        signal.z_score     = 4.2
        embed  = build_options_flow_embed(flow, signal)
        field_names = [f["name"] for f in embed["embeds"][0]["fields"]]
        assert any("Whale" in n for n in field_names)


# ── Discord send (mock HTTP) ──────────────────────────────────────────────────

class TestDiscordSend:

    @pytest.mark.asyncio
    async def test_send_returns_true_on_200(self):
        from app.services.discord_service import send_options_flow_alert

        mock_resp = MagicMock()
        mock_resp.status_code = 200

        flow = MagicMock()
        flow.symbol = "NVDA"; flow.option_type = "CALL"
        flow.strike = 900.0; flow.premium = 420_000
        flow.expiration = MagicMock()
        flow.expiration.strftime = lambda fmt: "15 Mar 2026"
        flow.flow_type = "SWEEP"; flow.sentiment = "BULLISH"
        flow.size = 1200; flow.implied_vol = 0.82
        flow.underlying_price = 887.40; flow.days_to_expiry = 0
        flow.strength_boost = None

        with patch("app.services.discord_service.settings") as mock_settings, \
             patch("app.services.discord_service._get_client") as mock_client:

            mock_settings.DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/test"
            mock_settings.FRONTEND_BASE_URL   = "http://localhost:3000"
            mock_client.return_value.post = AsyncMock(return_value=mock_resp)

            result = await send_options_flow_alert(flow)
            assert result is True

    @pytest.mark.asyncio
    async def test_send_returns_false_without_webhook(self):
        from app.services.discord_service import send_options_flow_alert

        with patch("app.services.discord_service.settings") as mock_settings:
            mock_settings.DISCORD_WEBHOOK_URL = ""
            result = await send_options_flow_alert(MagicMock())
            assert result is False

    @pytest.mark.asyncio
    async def test_send_does_not_raise_on_network_error(self):
        """Il chiamante non deve crashare se Discord è irraggiungibile."""
        import httpx
        from app.services.discord_service import send_options_flow_alert

        flow = MagicMock()
        flow.symbol = "NVDA"; flow.option_type = "CALL"
        flow.strike = 900.0; flow.premium = 420_000
        flow.expiration = MagicMock()
        flow.expiration.strftime = lambda fmt: "15 Mar 2026"
        flow.flow_type = "SWEEP"; flow.sentiment = "BULLISH"
        flow.size = 1200; flow.implied_vol = None
        flow.underlying_price = None; flow.days_to_expiry = 0
        flow.strength_boost = None

        with patch("app.services.discord_service.settings") as mock_settings, \
             patch("app.services.discord_service._get_client") as mock_client:

            mock_settings.DISCORD_WEBHOOK_URL = "https://discord.com/api/webhooks/test"
            mock_settings.FRONTEND_BASE_URL   = "http://localhost:3000"
            mock_client.return_value.post = AsyncMock(
                side_effect=httpx.TimeoutException("timeout")
            )

            result = await send_options_flow_alert(flow)
            assert result is False  # non solleva, ritorna False


# ── Flows API endpoint ────────────────────────────────────────────────────────

class TestFlowsEndpoint:

    async def test_list_flows_requires_no_auth(self, client):
        """L'endpoint flows è pubblico (read-only market data)."""
        resp = await client.get("/api/v1/flows/options")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    async def test_list_flows_correct_only_filter(self, client):
        resp = await client.get("/api/v1/flows/options?correct_only=true&limit=10")
        assert resp.status_code == 200

    async def test_flows_by_symbol(self, client):
        resp = await client.get("/api/v1/flows/options/NVDA")
        assert resp.status_code == 200

    async def test_test_discord_requires_superuser(self, client):
        """POST /flows/test-discord richiede superuser."""
        resp = await client.post(
            "/api/v1/flows/test-discord",
            json={"message": "test", "level": "info"},
        )
        assert resp.status_code == 401

    async def test_flow_stats(self, client):
        resp = await client.get("/api/v1/flows/stats?days=7")
        assert resp.status_code == 200
