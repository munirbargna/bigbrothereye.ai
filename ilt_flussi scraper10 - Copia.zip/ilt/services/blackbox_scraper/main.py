"""
services/blackbox_scraper/main.py

Entry point del Blackbox Scraper.

Architettura:
    Playwright → tabella Flow Blackbox Stocks
        ↓  ogni BLACKBOX_POLL_INTERVAL secondi
    Normalizza + valida "Correct Flows"
        ↓
    XADD Redis Stream "stream:blackbox_raw"
        ↓  (consumato dal Whale Engine)
    Whale Engine correla con segnali volume anomali
        ↓
    INSERT options_flow (TimescaleDB)
    PUBLISH whale:broadcast (Discord + WebSocket)

Design decision: questo servizio NON scrive nel DB.
Pubblica su Redis Stream e lascia al Whale Engine
tutta la logica di persistenza e correlazione.
Questo mantiene il servizio stateless e riavviabile.
"""

import asyncio
import json
import os
import sys
import uuid
from datetime import datetime, timezone

import structlog

# ── Path setup ────────────────────────────────────────────────────────────────
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))

from services.blackbox_scraper.scraper import BlackboxAuthError, BlackboxScraper

log = structlog.get_logger("blackbox_scraper")

STREAM_KEY = "stream:blackbox_raw"
STREAM_MAXLEN = 5_000   # mantieni ultimi 5k flow (~1-2 giorni di dati)


def _is_correct_flow(flow: dict) -> bool:
    """
    Filtraggio "Correct Flows" — segnali ad alta confidenza.

    Criteri (AND):
        1. Premium >= $100k  (ordine istituzionale)
        2. SWEEP             (urgenza di esecuzione)
        3. 0DTE o 1DTE       (scommessa direzionale imminente)

    Questi tre criteri combinati eliminano >90% del rumore
    e lasciano solo i flow con reale interesse istituzionale.
    """
    premium    = float(flow.get("premium", 0))
    flow_type  = flow.get("flow_type", "").upper()
    dte        = flow.get("days_to_expiry")

    return (
        premium  >= 100_000
        and flow_type == "SWEEP"
        and dte is not None
        and dte <= 1
    )


class BlackboxIngestor:

    def __init__(self) -> None:
        self._redis = None
        self._scraper: BlackboxScraper | None = None
        self._stats = {
            "total_seen":    0,
            "correct_flows": 0,
            "published":     0,
            "errors":        0,
        }

    async def setup(self) -> None:
        from app.core.config import settings
        from app.core.logging import setup_logging

        setup_logging()

        if not settings.BLACKBOX_USER or not settings.BLACKBOX_PASS:
            log.error(
                "blackbox.missing_credentials",
                hint="Imposta BLACKBOX_USER e BLACKBOX_PASS nel .env"
            )
            raise SystemExit(1)

        import redis.asyncio as aioredis
        self._redis = aioredis.from_url(
            settings.redis_url_str,
            encoding="utf-8",
            decode_responses=True,
        )
        await self._redis.ping()

        self._settings = settings
        log.info(
            "blackbox_ingestor.ready",
            user=settings.BLACKBOX_USER,
            poll_interval=settings.BLACKBOX_POLL_INTERVAL,
        )

    async def run(self) -> None:
        from app.core.config import settings

        log.info("blackbox_ingestor.starting")

        async with BlackboxScraper(
            user=settings.BLACKBOX_USER,
            password=settings.BLACKBOX_PASS,
            base_url=settings.BLACKBOX_BASE_URL,
        ) as scraper:
            self._scraper = scraper

            try:
                await scraper.authenticate()
            except BlackboxAuthError as e:
                log.error("blackbox.auth_failed", error=str(e))
                raise SystemExit(1)

            async for flows in scraper.stream_flows(
                poll_interval=settings.BLACKBOX_POLL_INTERVAL
            ):
                await self._process_batch(flows)

    async def _process_batch(self, flows: list[dict]) -> None:
        """Filtra e pubblica i flow sul Redis Stream."""
        self._stats["total_seen"] += len(flows)

        correct = [f for f in flows if _is_correct_flow(f)]
        all_flows = flows  # pubblica tutti, con flag is_correct

        self._stats["correct_flows"] += len(correct)

        for flow in all_flows:
            await self._publish_flow(flow, is_correct=flow in correct)

        if correct:
            log.info(
                "blackbox.correct_flows_found",
                correct=len(correct),
                total=len(flows),
                symbols=[f["symbol"] for f in correct],
            )

    async def _publish_flow(self, flow: dict, *, is_correct: bool) -> None:
        """Pubblica un singolo flow su Redis Stream stream:blackbox_raw."""
        now = datetime.now(timezone.utc)

        payload = {
            "type":          "blackbox_flow",
            "flow_id":       flow.get("flow_id") or uuid.uuid4().hex[:16],
            "ts":            now.isoformat(),
            "is_correct":    str(is_correct).lower(),  # Redis Streams: solo stringhe
            "symbol":        flow.get("symbol", ""),
            "strike":        str(flow.get("strike", 0)),
            "expiration":    flow.get("expiration", ""),
            "option_type":   flow.get("option_type", ""),
            "premium":       str(flow.get("premium", 0)),
            "flow_type":     flow.get("flow_type", ""),
            "sentiment":     flow.get("sentiment", ""),
            "size":          str(flow.get("size") or 0),
            "implied_vol":   str(flow.get("implied_vol") or 0),
            "underlying":    str(flow.get("underlying_price") or 0),
            "dte":           str(flow.get("days_to_expiry") or -1),
            "is_otm":        str(flow.get("is_otm", False)).lower(),
            # Payload grezzo per audit e replay (JSON-encoded)
            "raw":           json.dumps({
                "raw_text": flow.get("raw_text", "")[:200],
            }),
        }

        try:
            await self._redis.xadd(
                STREAM_KEY,
                payload,
                maxlen=STREAM_MAXLEN,
                approximate=True,
            )
            self._stats["published"] += 1

            log.debug(
                "blackbox.flow_published",
                symbol=flow.get("symbol"),
                premium=flow.get("premium"),
                flow_type=flow.get("flow_type"),
                is_correct=is_correct,
            )

        except Exception as e:
            self._stats["errors"] += 1
            log.error("blackbox.publish_error", error=str(e))

    def log_stats(self) -> None:
        log.info("blackbox.stats", **self._stats)


# ── Healthcheck ───────────────────────────────────────────────────────────────
# Prometheus può fare scraping su questo endpoint se esposto via httpx server
# Per ora stampa stats ogni 5 minuti nel log (Promtail → Loki)

async def _stats_reporter(ingestor: BlackboxIngestor) -> None:
    while True:
        await asyncio.sleep(300)
        ingestor.log_stats()


# ── Entry point ───────────────────────────────────────────────────────────────

async def main() -> None:
    ingestor = BlackboxIngestor()
    await ingestor.setup()

    # Avvia reporter stats in background
    stats_task = asyncio.create_task(_stats_reporter(ingestor))
    try:
        await ingestor.run()
    finally:
        stats_task.cancel()
        try:
            await stats_task
        except asyncio.CancelledError:
            pass


if __name__ == "__main__":
    asyncio.run(main())
