"""
services/blackbox_scraper/scraper.py

Playwright scraper per Blackbox Stocks.
Gestisce autenticazione, navigazione alla tabella Flow
e estrazione dati in tempo reale.

Pattern di sicurezza:
    - Le credenziali non vengono mai loggiate
    - Il browser gira in modalità headless (no GUI)
    - I cookie di sessione vengono preservati tra i cicli
      per evitare login ripetuti (session reuse)
    - Su 401/redirect login: re-autentica automaticamente

Struttura raw flow estratto:
    {
        "symbol":    "NVDA",
        "strike":    900.0,
        "expiration": "2026-03-15",
        "option_type": "CALL",
        "premium":   420000,
        "flow_type": "SWEEP",
        "sentiment": "BULLISH",
        "size":      1200,
        "open_interest": 8500,
        "implied_vol": 0.82,
        "underlying_price": 887.40,
        "raw_text":  "...",   # testo grezzo per audit
    }
"""

import asyncio
import json
import re
from datetime import datetime, date, timezone
from typing import Any

import structlog
from playwright.async_api import (
    Browser,
    BrowserContext,
    Page,
    Playwright,
    async_playwright,
    TimeoutError as PlaywrightTimeout,
)

log = structlog.get_logger("blackbox_scraper.scraper")

# ── Selettori CSS (aggiornare se Blackbox cambia la UI) ───────────────────────
# Nota: questi selettori sono ipotetici — la struttura reale richiede
# ispezione del DOM di Blackbox in produzione.
_SEL_LOGIN_EMAIL    = "input[type='email'], input[name='email']"
_SEL_LOGIN_PASSWORD = "input[type='password'], input[name='password']"
_SEL_LOGIN_SUBMIT   = "button[type='submit'], button:has-text('Sign In')"
_SEL_FLOW_TABLE     = ".flow-table, [data-testid='flow-table'], table.options-flow"
_SEL_FLOW_ROW       = "tr.flow-row, tbody tr[data-flow-id]"
_SEL_FLOW_FILTER    = "button:has-text('Flow'), a:has-text('Options Flow')"


class BlackboxAuthError(Exception):
    """Autenticazione fallita — credenziali errate o account sospeso."""


class BlackboxSessionExpired(Exception):
    """Sessione scaduta — necessita re-login."""


class BlackboxScraper:
    """
    Gestisce il lifecycle del browser Playwright e l'estrazione dati.

    Uso:
        async with BlackboxScraper(user, password, base_url) as scraper:
            async for flows in scraper.stream_flows():
                process(flows)
    """

    def __init__(self, user: str, password: str, base_url: str) -> None:
        self._user     = user
        self._password = password
        self._base_url = base_url.rstrip("/")

        self._playwright: Playwright | None   = None
        self._browser:    Browser | None      = None
        self._context:    BrowserContext | None = None
        self._page:       Page | None         = None
        self._authenticated = False
        self._seen_flow_ids: set[str] = set()   # deduplication in-memory

    # ── Context manager ────────────────────────────────────────────────────

    async def __aenter__(self) -> "BlackboxScraper":
        self._playwright = await async_playwright().start()
        self._browser = await self._playwright.chromium.launch(
            headless=True,
            args=[
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-blink-features=AutomationControlled",
            ],
        )
        self._context = await self._browser.new_context(
            viewport={"width": 1280, "height": 800},
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            ),
            # Accetta tutti i cookie — necessario per il login
            accept_downloads=False,
        )
        self._page = await self._context.new_page()

        # Blocca risorse pesanti non necessarie (velocizza lo scraping)
        await self._page.route(
            "**/*.{png,jpg,jpeg,gif,svg,woff,woff2,mp4,webm}",
            lambda r: r.abort(),
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        try:
            if self._context:
                await self._context.close()
            if self._browser:
                await self._browser.close()
            if self._playwright:
                await self._playwright.stop()
        except Exception as e:
            log.warning("scraper.cleanup_error", error=str(e))

    # ── Autenticazione ─────────────────────────────────────────────────────

    async def authenticate(self) -> None:
        """
        Esegue il login su Blackbox Stocks.
        Preserva i cookie di sessione nel BrowserContext.
        """
        log.info("scraper.authenticating", url=self._base_url)
        assert self._page is not None

        try:
            await self._page.goto(
                f"{self._base_url}/login",
                wait_until="networkidle",
                timeout=30_000,
            )
        except PlaywrightTimeout:
            raise BlackboxAuthError("Timeout durante il caricamento della pagina di login")

        # Compila il form
        try:
            await self._page.fill(_SEL_LOGIN_EMAIL,    self._user)
            await self._page.fill(_SEL_LOGIN_PASSWORD, self._password)
            await self._page.click(_SEL_LOGIN_SUBMIT)

            # Attendi redirect post-login
            await self._page.wait_for_url(
                re.compile(r".*(dashboard|app|flow|home).*"),
                timeout=15_000,
            )
        except PlaywrightTimeout:
            # Controlla se c'è un messaggio di errore login
            error_el = await self._page.query_selector(".error, .alert-danger, [role='alert']")
            if error_el:
                error_text = await error_el.text_content()
                raise BlackboxAuthError(f"Login fallito: {error_text}")
            raise BlackboxAuthError("Timeout dopo click su submit — verifica i selettori CSS")

        self._authenticated = True
        log.info("scraper.authenticated")

    async def _ensure_authenticated(self) -> None:
        """Re-autentica se la sessione è scaduta."""
        assert self._page is not None

        current_url = self._page.url
        if "login" in current_url or "auth" in current_url:
            log.warning("scraper.session_expired", url=current_url)
            self._authenticated = False
            self._seen_flow_ids.clear()
            await self.authenticate()

        if not self._authenticated:
            await self.authenticate()

    # ── Navigazione alla tabella Flow ──────────────────────────────────────

    async def navigate_to_flow(self) -> None:
        """Naviga alla sezione Options Flow della piattaforma."""
        assert self._page is not None

        await self._ensure_authenticated()

        # Prova navigazione diretta
        try:
            await self._page.goto(
                f"{self._base_url}/flow",
                wait_until="networkidle",
                timeout=20_000,
            )
        except PlaywrightTimeout:
            # Fallback: cerca il link nel menu
            try:
                await self._page.click(_SEL_FLOW_FILTER, timeout=5_000)
                await self._page.wait_for_load_state("networkidle", timeout=15_000)
            except PlaywrightTimeout:
                log.warning("scraper.flow_nav_failed", url=self._page.url)

        log.debug("scraper.on_flow_page", url=self._page.url)

    # ── Estrazione righe ───────────────────────────────────────────────────

    async def extract_flows(self) -> list[dict]:
        """
        Estrae le righe correnti dalla tabella Flow.
        Restituisce solo le righe nuove (non viste nei cicli precedenti).
        """
        assert self._page is not None

        try:
            await self._page.wait_for_selector(_SEL_FLOW_TABLE, timeout=10_000)
        except PlaywrightTimeout:
            log.warning("scraper.table_not_found")
            return []

        rows = await self._page.query_selector_all(_SEL_FLOW_ROW)
        new_flows: list[dict] = []

        for row in rows:
            try:
                flow = await self._parse_row(row)
                if flow is None:
                    continue

                flow_id = self._compute_flow_id(flow)
                if flow_id in self._seen_flow_ids:
                    continue

                self._seen_flow_ids.add(flow_id)
                # Mantieni dedup set a max 10k entries
                if len(self._seen_flow_ids) > 10_000:
                    # Rimuovi i più vecchi (set non è ordinato — ricrea)
                    self._seen_flow_ids = set(list(self._seen_flow_ids)[-5_000:])

                flow["flow_id"] = flow_id
                new_flows.append(flow)

            except Exception as e:
                log.warning("scraper.row_parse_error", error=str(e))
                continue

        if new_flows:
            log.info("scraper.flows_extracted", count=len(new_flows))

        return new_flows

    async def _parse_row(self, row: Any) -> dict | None:
        """
        Analizza una singola riga della tabella Flow.

        La struttura delle celle varia tra le piattaforme — questo parser
        usa una combinazione di selettori CSS e regex sul testo.
        Adattare i data-attribute o class name alla struttura reale di Blackbox.
        """
        # Estrai testo completo della riga per parsing flessibile
        row_text = await row.inner_text()
        if not row_text.strip():
            return None

        # Estrai attributi data-* se presenti (API-friendly)
        flow_data = await row.evaluate("""row => {
            const cells = Array.from(row.querySelectorAll('td'));
            return {
                symbol:       row.dataset.symbol      || (cells[0]  ? cells[0].textContent.trim()  : ''),
                option_type:  row.dataset.optionType  || (cells[1]  ? cells[1].textContent.trim()  : ''),
                strike:       row.dataset.strike      || (cells[2]  ? cells[2].textContent.trim()  : ''),
                expiration:   row.dataset.expiration  || (cells[3]  ? cells[3].textContent.trim()  : ''),
                premium:      row.dataset.premium     || (cells[4]  ? cells[4].textContent.trim()  : ''),
                flow_type:    row.dataset.flowType    || (cells[5]  ? cells[5].textContent.trim()  : ''),
                sentiment:    row.dataset.sentiment   || (cells[6]  ? cells[6].textContent.trim()  : ''),
                size:         row.dataset.size        || (cells[7]  ? cells[7].textContent.trim()  : ''),
                implied_vol:  row.dataset.iv          || (cells[8]  ? cells[8].textContent.trim()  : ''),
                underlying:   row.dataset.underlying  || (cells[9]  ? cells[9].textContent.trim()  : ''),
            };
        }""")

        return self._normalize_flow(flow_data, row_text)

    def _normalize_flow(self, raw: dict, raw_text: str) -> dict | None:
        """
        Normalizza i dati grezzi estratti dalla pagina.
        Converte stringhe in tipi Python appropriati.
        """
        try:
            symbol = raw.get("symbol", "").upper().strip()
            if not symbol or len(symbol) > 10:
                return None

            # Pulisci e converti strike
            strike_str = re.sub(r"[^\d.]", "", raw.get("strike", "0"))
            strike = float(strike_str) if strike_str else 0.0

            # Pulisci e converti premium (formato: "$420,000" o "420K")
            prem_str = raw.get("premium", "0")
            prem_str = prem_str.upper().replace("$", "").replace(",", "").strip()
            if prem_str.endswith("K"):
                premium = float(prem_str[:-1]) * 1_000
            elif prem_str.endswith("M"):
                premium = float(prem_str[:-1]) * 1_000_000
            else:
                premium = float(prem_str) if prem_str else 0.0

            # Normalizza tipo opzione
            otype = raw.get("option_type", "").upper()
            if otype not in ("CALL", "PUT"):
                # Cerca nel testo
                if "call" in raw_text.lower():
                    otype = "CALL"
                elif "put" in raw_text.lower():
                    otype = "PUT"
                else:
                    return None

            # Normalizza flow type
            ftype = raw.get("flow_type", "").upper()
            if "SWEEP" in ftype:
                ftype = "SWEEP"
            elif "BLOCK" in ftype:
                ftype = "BLOCK"
            else:
                ftype = "SPLIT"

            # Normalizza sentiment
            sentiment = raw.get("sentiment", "").upper()
            if "BULL" in sentiment or "CALL" in otype:
                sentiment = "BULLISH"
            elif "BEAR" in sentiment or "PUT" in otype:
                sentiment = "BEARISH"
            else:
                sentiment = "NEUTRAL"

            # Parsing data scadenza
            exp_str = raw.get("expiration", "")
            exp_date = self._parse_expiration(exp_str)
            if exp_date is None:
                return None

            # Days to expiry
            today = datetime.now(timezone.utc).date()
            dte = (exp_date - today).days

            # IV
            iv_str = re.sub(r"[^\d.]", "", raw.get("implied_vol", "0"))
            iv = float(iv_str) / 100 if iv_str else None
            if iv and iv > 10:  # era già in % come 82 invece di 0.82
                iv = iv / 100

            # Underlying price
            und_str = re.sub(r"[^\d.]", "", raw.get("underlying", "0"))
            underlying = float(und_str) if und_str else None

            # Size
            size_str = re.sub(r"[^\d]", "", raw.get("size", "0"))
            size = int(size_str) if size_str else None

            return {
                "symbol":           symbol,
                "strike":           strike,
                "expiration":       exp_date.isoformat(),
                "option_type":      otype,
                "premium":          premium,
                "flow_type":        ftype,
                "sentiment":        sentiment,
                "size":             size,
                "implied_vol":      iv,
                "underlying_price": underlying,
                "days_to_expiry":   dte,
                "is_otm":           self._compute_otm(otype, strike, underlying),
                "raw_text":         raw_text[:500],  # tronca per audit
            }

        except (ValueError, TypeError, AttributeError) as e:
            log.debug("scraper.normalize_error", error=str(e))
            return None

    @staticmethod
    def _parse_expiration(exp_str: str) -> date | None:
        """Prova diversi formati di data scadenza."""
        exp_str = exp_str.strip()
        formats = ["%m/%d/%Y", "%Y-%m-%d", "%m/%d/%y", "%d %b %Y", "%b %d %Y"]
        for fmt in formats:
            try:
                return datetime.strptime(exp_str, fmt).date()
            except ValueError:
                continue
        return None

    @staticmethod
    def _compute_otm(otype: str, strike: float, underlying: float | None) -> bool:
        """Calcola se l'opzione è OTM al momento del flow."""
        if not underlying or underlying <= 0:
            return False
        if otype == "CALL":
            return strike > underlying
        if otype == "PUT":
            return strike < underlying
        return False

    @staticmethod
    def _compute_flow_id(flow: dict) -> str:
        """ID deterministico per deduplication: symbol+type+strike+exp+premium."""
        import hashlib
        key = f"{flow['symbol']}:{flow['option_type']}:{flow['strike']}:{flow['expiration']}:{flow['premium']}"
        return hashlib.md5(key.encode()).hexdigest()[:16]

    # ── Stream generator ───────────────────────────────────────────────────

    async def stream_flows(self, poll_interval: int = 15):
        """
        Generator asincrono — yield lista di nuovi flow ad ogni ciclo.

        Args:
            poll_interval: secondi tra ogni check della tabella
        """
        await self.navigate_to_flow()

        cycle = 0
        while True:
            try:
                # Ogni 10 cicli (~2.5 min) refresh della pagina per evitare
                # che React/Vue smetta di aggiornare il DOM
                if cycle > 0 and cycle % 10 == 0:
                    log.debug("scraper.page_refresh")
                    await self._page.reload(wait_until="networkidle", timeout=20_000)

                flows = await self.extract_flows()
                if flows:
                    yield flows

                await asyncio.sleep(poll_interval)
                cycle += 1

            except BlackboxSessionExpired:
                log.warning("scraper.session_expired_in_stream")
                await self.authenticate()
                await self.navigate_to_flow()

            except PlaywrightTimeout:
                log.warning("scraper.timeout_in_stream", cycle=cycle)
                await asyncio.sleep(5)

            except asyncio.CancelledError:
                log.info("scraper.stream_cancelled")
                return
