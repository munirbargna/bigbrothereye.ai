"""
services/whale_engine/main.py — v2 dual-stream + Blackbox correlation
"""
import asyncio, json, os, sys, uuid
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from typing import Any

import structlog

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../.."))
from services.whale_engine.detector import PriceBar, WhaleDetector

log = structlog.get_logger("whale_engine")

STREAM_PRICES   = "stream:prices"
STREAM_BLACKBOX = "stream:blackbox_raw"
CONSUMER_GROUP  = "whale-engine"
CONSUMER_NAME   = f"whale-{os.getpid()}"
BLOCK_MS        = 5_000
CORRELATION_WINDOW = timedelta(minutes=5)


def validate_correct_flow(fields: dict) -> bool:
    """Filtra Correct Flows: premium>=100k + SWEEP + 0/1DTE."""
    try:
        return (
            float(fields.get("premium", 0)) >= 100_000
            and fields.get("flow_type", "").upper() == "SWEEP"
            and 0 <= int(fields.get("dte", -1)) <= 1
        )
    except (ValueError, TypeError):
        return False


class WhaleEngineRunner:
    def __init__(self) -> None:
        self.detector = WhaleDetector()
        self._bars: defaultdict[str, list[PriceBar]] = defaultdict(list)
        self._window_size = 100
        self._recent_signals: defaultdict[str, list[tuple[datetime, str, float]]] = defaultdict(list)
        self._redis = None
        self._ts_session_factory = None
        self._settings = None

    async def setup(self) -> None:
        from app.core.config import settings
        from app.core.logging import setup_logging
        from app.db.session import TimescaleSessionMaker
        setup_logging()
        import redis.asyncio as aioredis
        self._redis = aioredis.from_url(settings.redis_url_str, encoding="utf-8", decode_responses=True)
        await self._redis.ping()
        self._ts_session_factory = TimescaleSessionMaker
        self._settings = settings
        for stream in (STREAM_PRICES, STREAM_BLACKBOX):
            try:
                await self._redis.xgroup_create(stream, CONSUMER_GROUP, id="0", mkstream=True)
                log.info("whale.group_created", stream=stream)
            except Exception as e:
                if "BUSYGROUP" not in str(e):
                    raise
        log.info("whale.ready", consumer=CONSUMER_NAME)

    async def run(self) -> None:
        log.info("whale.start")
        try:
            while True:
                await self._process_batch()
                await self._cleanup_old_signals()
        except asyncio.CancelledError:
            log.info("whale.shutdown")
        except Exception as e:
            log.error("whale.fatal", error=str(e))
            raise

    async def _process_batch(self) -> None:
        messages = await self._redis.xreadgroup(
            groupname=CONSUMER_GROUP, consumername=CONSUMER_NAME,
            streams={STREAM_PRICES: ">", STREAM_BLACKBOX: ">"},
            count=50, block=BLOCK_MS,
        )
        if not messages:
            return
        for stream_name, entries in messages:
            for msg_id, fields in entries:
                try:
                    if stream_name == STREAM_PRICES:
                        await self._handle_price(fields)
                    elif stream_name == STREAM_BLACKBOX:
                        await self._handle_blackbox(fields)
                    await self._redis.xack(stream_name, CONSUMER_GROUP, msg_id)
                except Exception as e:
                    log.error("whale.msg_error", stream=stream_name, error=str(e))

    async def _handle_price(self, fields: dict) -> None:
        if fields.get("type") != "price_update":
            return
        try:
            prices = json.loads(fields.get("prices", "{}"))
            ts = datetime.fromisoformat(fields["ts"]) if fields.get("ts") else datetime.now(timezone.utc)
        except Exception:
            return
        signals_to_save = []
        for asset, price in prices.items():
            bar = PriceBar(time=ts, asset=asset, price=price,
                           volume=float(fields.get(f"vol_{asset}", 1000.0)))
            w = self._bars[asset]
            w.append(bar)
            if len(w) > self._window_size:
                w.pop(0)
            if len(w) >= 20:
                sig = self.detector.analyze(w)
                if sig:
                    signals_to_save.append((ts, sig))
                    self._recent_signals[asset].append((ts, sig.signal_id, sig.strength))
                    log.info("whale.signal", asset=asset, dir=sig.direction, str=sig.strength)
        if signals_to_save:
            await self._persist_price_signals(signals_to_save)

    async def _handle_blackbox(self, fields: dict) -> None:
        if fields.get("type") != "blackbox_flow":
            return
        is_correct = fields.get("is_correct", "false") == "true" or validate_correct_flow(fields)
        if not is_correct:
            return
        symbol = fields.get("symbol", "")
        ts = datetime.fromisoformat(fields["ts"]) if fields.get("ts") else datetime.now(timezone.utc)

        # Correlazione con segnali volume recenti
        corr_id, boost = None, 0.0
        for sig_ts, sig_id, sig_str in self._recent_signals.get(symbol, []):
            if abs((ts - sig_ts).total_seconds()) <= CORRELATION_WINDOW.total_seconds():
                corr_id, boost = sig_id, round(0.15 * sig_str, 3)
                log.info("whale.correlated", symbol=symbol, boost=boost)
                break

        flow_obj = await self._persist_options_flow(fields, ts, corr_id, boost)

        if flow_obj:
            final_str = min(1.0, 0.75 + boost)
            if final_str >= self._settings.DISCORD_MIN_STRENGTH:
                from app.services.discord_service import send_options_flow_alert
                sent = await send_options_flow_alert(flow_obj)
                if sent:
                    await self._mark_discord_sent(flow_obj.flow_id)

    async def _persist_options_flow(self, fields: dict, ts: datetime,
                                     corr_id: str | None, boost: float) -> Any:
        from app.models.market import OptionsFlow
        from sqlalchemy import insert, select
        from datetime import date
        try:
            exp_str = fields.get("expiration", "")
            try:
                exp_date = datetime.strptime(exp_str, "%Y-%m-%d").date()
            except Exception:
                exp_date = date.today()
            row = {
                "timestamp": ts,
                "flow_id": fields.get("flow_id") or uuid.uuid4().hex[:16],
                "symbol": fields.get("symbol", "").upper(),
                "strike": float(fields.get("strike", 0)),
                "expiration": exp_date,
                "option_type": fields.get("option_type", "CALL").upper(),
                "premium": float(fields.get("premium", 0)),
                "flow_type": fields.get("flow_type", "SWEEP").upper(),
                "sentiment": fields.get("sentiment", "NEUTRAL").upper(),
                "size": int(fields.get("size", 0)) or None,
                "implied_vol": float(fields.get("implied_vol", 0)) or None,
                "underlying_price": float(fields.get("underlying", 0)) or None,
                "days_to_expiry": int(fields.get("dte", -1)),
                "is_otm": fields.get("is_otm", "false") == "true",
                "source": "blackbox",
                "correlated_signal_id": corr_id,
                "strength_boost": boost if boost > 0 else None,
                "raw_data": json.loads(fields.get("raw", "{}")),
                "discord_sent": False,
            }
            async with self._ts_session_factory() as session:
                await session.execute(
                    insert(OptionsFlow).values([row])
                    .on_conflict_do_nothing(index_elements=["timestamp", "flow_id"])
                )
                await session.commit()
                r = await session.execute(
                    select(OptionsFlow).where(OptionsFlow.flow_id == row["flow_id"]).limit(1)
                )
                return r.scalar_one_or_none()
        except Exception as e:
            log.error("whale.options_flow_error", error=str(e))
            return None

    async def _mark_discord_sent(self, flow_id: str) -> None:
        from app.models.market import OptionsFlow
        from sqlalchemy import update
        try:
            async with self._ts_session_factory() as session:
                await session.execute(
                    update(OptionsFlow).where(OptionsFlow.flow_id == flow_id)
                    .values(discord_sent=True)
                )
                await session.commit()
        except Exception as e:
            log.warning("whale.discord_mark_error", error=str(e))

    async def _persist_price_signals(self, signals: list) -> None:
        from app.models.market import WhaleSignal
        from sqlalchemy import insert
        rows = [{
            "time": ts, "signal_id": sig.signal_id, "asset": sig.asset,
            "direction": sig.direction, "strength": sig.strength,
            "signal_type": sig.signal_type, "z_score": sig.z_score,
            "notional_usd": sig.notional_usd,
            "vwap_deviation_pct": sig.vwap_deviation_pct,
            "metadata": sig.metadata or {}, "whale_profile_id": None,
        } for ts, sig in signals]
        async with self._ts_session_factory() as session:
            await session.execute(
                insert(WhaleSignal).values(rows)
                .on_conflict_do_nothing(index_elements=["time", "signal_id"])
            )
            await session.commit()
        for _, sig in signals:
            await self._redis.publish("whale:broadcast", json.dumps({
                "type": "whale_alert", "asset": sig.asset,
                "direction": sig.direction, "strength": sig.strength,
                "signal_type": sig.signal_type, "z_score": sig.z_score,
                "ts": datetime.now(timezone.utc).isoformat(),
            }))

    async def _cleanup_old_signals(self) -> None:
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=10)
        for asset in list(self._recent_signals):
            self._recent_signals[asset] = [
                x for x in self._recent_signals[asset] if x[0] > cutoff
            ]
            if not self._recent_signals[asset]:
                del self._recent_signals[asset]


async def main() -> None:
    runner = WhaleEngineRunner()
    await runner.setup()
    await runner.run()

if __name__ == "__main__":
    asyncio.run(main())
